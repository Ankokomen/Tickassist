# Removes every earlier TickAssist install it can find on this PC: the per-user
# install, C:\Program Files, Documents\TickAssist, any copy a Start-menu or
# desktop shortcut or a running TickAssist points at, plus their shortcuts and
# Settings > Apps entries.
#
# Your saved settings, lists and macros (%APPDATA%\TickAssist) are KEPT unless you
# say otherwise. A copy that holds its own data folder (an old portable copy) has
# that folder backed up to Documents\TickAssist-backup before it is deleted.
#
#   -Quiet        no questions (machine-wide copies are skipped unless already elevated)
#   -RemoveData   also delete %APPDATA%\TickAssist
#   -MachineOnly  (used internally for the administrator pass)
param(
    [switch]$Quiet,
    [switch]$RemoveData,
    [switch]$MachineOnly
)
$ErrorActionPreference = "Continue"

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
$isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$pf   = $env:ProgramFiles
$pf86 = ${env:ProgramFiles(x86)}
$docs = [Environment]::GetFolderPath("MyDocuments")
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"

function Test-Machine([string]$path) {
    foreach ($base in @($pf, $pf86)) {
        if ($base -and $path.StartsWith($base, [StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    return $false
}

# A TickAssist program folder has VERSION next to app\server.py.
function Test-Root([string]$path) {
    return ($path -and (Test-Path -LiteralPath (Join-Path $path "VERSION")) -and
            (Test-Path -LiteralPath (Join-Path $path "app\server.py")))
}

Write-Host ""
Write-Host "  Remove old TickAssist installs" -ForegroundColor Cyan
Write-Host "  ------------------------------"

# ---- 1. find program folders ------------------------------------------------
$roots = @{}
function Add-Root([string]$path, [string]$why) {
    if (-not $path) { return }
    try { $full = [IO.Path]::GetFullPath($path).TrimEnd("\") } catch { return }
    if ((Test-Root $full) -and -not $roots.ContainsKey($full.ToLower())) {
        $roots[$full.ToLower()] = @{ Path = $full; Why = $why }
    }
}

Add-Root (Join-Path $env:LOCALAPPDATA "Programs\TickAssist") "per-user install"
Add-Root (Join-Path $pf "TickAssist") "Program Files"
if ($pf86) { Add-Root (Join-Path $pf86 "TickAssist") "Program Files (x86)" }
Add-Root (Join-Path $docs "TickAssist") "Documents"

foreach ($hive in @("HKCU", "HKLM")) {
    $k = "${hive}:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TickAssist"
    if (Test-Path $k) {
        $loc = (Get-ItemProperty $k -ErrorAction SilentlyContinue).InstallLocation
        Add-Root $loc "listed in Settings > Apps"
    }
}

$shortcutDirs = @(
    [Environment]::GetFolderPath("Programs"), [Environment]::GetFolderPath("Desktop"),
    [Environment]::GetFolderPath("CommonPrograms"), [Environment]::GetFolderPath("CommonDesktopDirectory")
) | Where-Object { $_ -and (Test-Path $_) }
$shell = New-Object -ComObject WScript.Shell
$shortcuts = @()
foreach ($d in $shortcutDirs) {
    Get-ChildItem -LiteralPath $d -Filter "TickAssist*.lnk" -ErrorAction SilentlyContinue | ForEach-Object {
        $shortcuts += $_.FullName
        try { $target = $shell.CreateShortcut($_.FullName).TargetPath } catch { $target = "" }
        if ($target) { Add-Root (Split-Path -Parent $target) "a shortcut points to it" }
    }
}

Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -and $_.CommandLine -match 'app[\\/]server\.py' } |
    ForEach-Object {
        if ($_.CommandLine -match '"?([A-Za-z]:[^"]*?)[\\/]app[\\/]server\.py') { Add-Root $Matches[1] "currently running" }
    }

$todo = @($roots.Values | Where-Object { (Test-Machine $_.Path) -eq [bool]$MachineOnly })

# ---- 2. report ---------------------------------------------------------------
if (-not $todo.Count) {
    if (-not $MachineOnly) { Write-Host "  No other TickAssist program folder was found." }
} else {
    Write-Host "  Found:"
    foreach ($r in $todo) {
        $v = (Get-Content -LiteralPath (Join-Path $r.Path "VERSION") -Raw -ErrorAction SilentlyContinue)
        Write-Host ("    {0}   (version {1}, {2})" -f $r.Path, ($v -as [string]).Trim(), $r.Why)
    }
}

$machineLeft = @($roots.Values | Where-Object { Test-Machine $_.Path })

if (-not $Quiet -and -not $MachineOnly -and $todo.Count) {
    $ok = Read-Host "  Remove these? (Y/n)"
    if ($ok.Trim().ToLower() -eq "n") { Write-Host "  Cancelled."; exit 0 }
}

# ---- 3. remove ----------------------------------------------------------------
$removed = 0; $stuck = @()
foreach ($r in $todo) {
    $path = $r.Path
    # stop anything running from it
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($path, [StringComparison]::OrdinalIgnoreCase) } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -and $_.CommandLine.IndexOf($path, [StringComparison]::OrdinalIgnoreCase) -ge 0 -and $_.Name -match 'python' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Milliseconds 700

    # a copy that keeps its own data: back it up first
    $dataDir = Join-Path $path "data"
    if ((Test-Path -LiteralPath $dataDir) -and (Get-ChildItem -LiteralPath $dataDir -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1)) {
        $bak = Join-Path $docs ("TickAssist-backup\{0}-{1}" -f (Split-Path -Leaf (Split-Path -Parent $path)), $stamp)
        New-Item -ItemType Directory -Force -Path $bak | Out-Null
        Copy-Item -LiteralPath $dataDir -Destination $bak -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "  Backed up the data folder of $path to $bak" -ForegroundColor Yellow
    }

    Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path -LiteralPath $path) { $stuck += $path } else { $removed++ }
}

# shortcuts, Settings > Apps entries
if (-not $MachineOnly) {
    foreach ($s in $shortcuts | Where-Object { -not (Test-Machine $_) -and $_ -notlike "$([Environment]::GetFolderPath('CommonPrograms'))*" -and $_ -notlike "$([Environment]::GetFolderPath('CommonDesktopDirectory'))*" }) {
        Remove-Item -LiteralPath $s -Force -ErrorAction SilentlyContinue
    }
    Remove-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TickAssist" -Recurse -Force -ErrorAction SilentlyContinue
} else {
    foreach ($s in $shortcuts | Where-Object { $_ -like "$([Environment]::GetFolderPath('CommonPrograms'))*" -or $_ -like "$([Environment]::GetFolderPath('CommonDesktopDirectory'))*" }) {
        Remove-Item -LiteralPath $s -Force -ErrorAction SilentlyContinue
    }
    Remove-Item "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TickAssist" -Recurse -Force -ErrorAction SilentlyContinue
}

# Anything Windows still holds open is deleted a moment after this script ends.
foreach ($p in $stuck) {
    Start-Process -FilePath "cmd.exe" -ArgumentList "/c", ('ping 127.0.0.1 -n 4 >nul & rmdir /s /q "{0}"' -f $p) -WindowStyle Hidden
}

# ---- 4. saved settings ----------------------------------------------------------
$data = Join-Path $env:APPDATA "TickAssist"
if (-not $MachineOnly -and (Test-Path -LiteralPath $data)) {
    $wipe = [bool]$RemoveData
    if (-not $Quiet -and -not $RemoveData) {
        $a = Read-Host "  Also delete your saved settings, lists and macros in $data ? (y/N)"
        $wipe = ($a.Trim().ToLower() -eq "y")
    }
    if ($wipe) { Remove-Item -LiteralPath $data -Recurse -Force -ErrorAction SilentlyContinue; Write-Host "  Deleted $data" }
    else { Write-Host "  Kept your saved settings in $data" }
}

if ($removed) { Write-Host ("  Removed {0} install{1}." -f $removed, $(if ($removed -eq 1) { "" } else { "s" })) -ForegroundColor Green }
if ($stuck.Count) { Write-Host "  Some files were still in use; they will be deleted in a few seconds." -ForegroundColor Yellow }

# ---- 5. machine-wide copies need an administrator -----------------------------------
if (-not $MachineOnly) {
    $machineLeft = @($roots.Values | Where-Object { (Test-Machine $_.Path) -and (Test-Path -LiteralPath $_.Path) })
    $machineKeys = Test-Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TickAssist"
    if ($machineLeft.Count -or $machineKeys) {
        if ($isAdmin) {
            & $MyInvocation.MyCommand.Path -MachineOnly -Quiet:$Quiet -RemoveData:$RemoveData
        } elseif (-not $Quiet) {
            Write-Host ""
            Write-Host "  A copy installed for all users was found. Removing it needs an administrator." -ForegroundColor Yellow
            $go = Read-Host "  Ask Windows for permission now? (Y/n)"
            if ($go.Trim().ToLower() -ne "n") {
                $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$($MyInvocation.MyCommand.Path)`"", "-MachineOnly", "-Quiet")
                Start-Process -FilePath "powershell.exe" -ArgumentList $argList -Verb RunAs -Wait | Out-Null
                Write-Host "  Finished the all-users removal."
            } else { Write-Host "  Skipped the all-users copy." }
        } else {
            Write-Host "  Skipped a copy installed for all users (run this script as administrator to remove it)." -ForegroundColor Yellow
        }
    }
}
Write-Host ""
