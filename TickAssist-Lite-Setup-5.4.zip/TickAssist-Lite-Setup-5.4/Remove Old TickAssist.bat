@echo off
REM Removes every earlier TickAssist install it can find. No administrator rights
REM needed for your own copies; it asks first for any installed for all users.
setlocal
title Remove old TickAssist
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Remove Old TickAssist.ps1" %*
echo.
pause
endlocal
