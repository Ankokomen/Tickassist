# TickAssist uninstaller. Run from the install folder (or Settings > Apps).
param([switch]$Quiet, [switch]$Elevated)
$ErrorActionPreference = "Stop"
$Dir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$machine = $Dir.StartsWith($env:ProgramFiles, [StringComparison]::OrdinalIgnoreCase)

if ($machine) {
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        if ($Elevated) { throw "Administrator rights are needed to remove a Program Files install." }
        $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$($MyInvocation.MyCommand.Path)`"", "-Elevated")
        if ($Quiet) { $argList += "-Quiet" }
        $p = Start-Process -FilePath "powershell.exe" -ArgumentList $argList -Verb RunAs -Wait -PassThru
        exit $p.ExitCode
    }
}

Write-Host ""
Write-Host "  Remove TickAssist from $Dir ?" -ForegroundColor Cyan
if (-not $Quiet) {
    $ok = Read-Host "  Type Y to continue"
    if ($ok.Trim().ToLower() -ne "y") { Write-Host "  Cancelled."; exit 0 }
}

Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($Dir, [StringComparison]::OrdinalIgnoreCase) } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

if ($machine) { $startFolder = "CommonPrograms"; $deskFolder = "CommonDesktopDirectory"; $hive = "HKLM" }
else          { $startFolder = "Programs";       $deskFolder = "Desktop";                $hive = "HKCU" }
Remove-Item (Join-Path ([Environment]::GetFolderPath($startFolder)) "TickAssist.lnk") -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath($startFolder)) "TickAssist - Open MAX.lnk") -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath($deskFolder)) "TickAssist.lnk") -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath($deskFolder)) "TickAssist - Open MAX.lnk") -Force -ErrorAction SilentlyContinue
Remove-Item "${hive}:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TickAssist" -Recurse -Force -ErrorAction SilentlyContinue

$data = Join-Path $env:APPDATA "TickAssist"
if ((Test-Path $data) -and -not $Quiet) {
    $wipe = Read-Host "  Also delete your saved settings, lists and macros in $data ? (y/N)"
    if ($wipe.Trim().ToLower() -eq "y") { Remove-Item $data -Recurse -Force -ErrorAction SilentlyContinue }
}

# This script lives inside the folder it removes, so a helper deletes it after we exit.
$cmd = 'ping 127.0.0.1 -n 3 >nul & rmdir /s /q "{0}"' -f $Dir
Start-Process -FilePath "cmd.exe" -ArgumentList "/c", $cmd -WindowStyle Hidden
Write-Host "  TickAssist was removed." -ForegroundColor Green
