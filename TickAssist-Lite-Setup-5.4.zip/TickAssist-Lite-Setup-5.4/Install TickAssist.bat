@echo off
REM TickAssist setup - double-click. No administrator rights needed.
REM (To install into C:\Program Files for everyone on the PC instead, run
REM  "Install TickAssist (Program Files).bat" - it asks Windows for permission.)
setlocal
title TickAssist Setup
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
if errorlevel 1 (
    echo.
    echo  Setup did not finish. Take a screenshot of the message above and send it to the owner.
    pause
)
endlocal
