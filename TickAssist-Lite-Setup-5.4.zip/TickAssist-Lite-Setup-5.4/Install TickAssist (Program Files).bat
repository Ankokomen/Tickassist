@echo off
REM Installs TickAssist to C:\Program Files\TickAssist for everyone on this PC.
REM Windows asks for administrator permission.
setlocal
title TickAssist Setup (Program Files)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -ProgramFiles %*
if errorlevel 1 (
    echo.
    echo  Setup did not finish. Take a screenshot of the message above and send it to the owner.
    pause
)
endlocal
