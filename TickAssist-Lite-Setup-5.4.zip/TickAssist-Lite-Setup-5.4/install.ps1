# TickAssist installer. No administrator rights needed.
#   install.ps1                 installs for the current user (default)
#   install.ps1 -ProgramFiles   installs to C:\Program Files\TickAssist for everyone
#                               on the PC (asks Windows for administrator permission)
#   install.ps1 -Quiet          no questions, for scripted installs
param(
    [switch]$ProgramFiles,
    [switch]$Quiet,
    [switch]$NoDesktopShortcut,
    [switch]$Elevated
)
$ErrorActionPreference = "Stop"

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
$isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($ProgramFiles -and -not $isAdmin) {
    if ($Elevated) { throw "Administrator rights are needed to install into Program Files." }
    Write-Host ""
    Write-Host "  Installing into C:\Program Files needs permission - Windows will ask..." -ForegroundColor Yellow
    $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$($MyInvocation.MyCommand.Path)`"", "-ProgramFiles", "-Elevated")
    if ($Quiet) { $argList += "-Quiet" }
    if ($NoDesktopShortcut) { $argList += "-NoDesktopShortcut" }
    $p = Start-Process -FilePath "powershell.exe" -ArgumentList $argList -Verb RunAs -Wait -PassThru
    exit $p.ExitCode
}

$here    = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $here "payload"
if (-not (Test-Path (Join-Path $payload "VERSION"))) {
    throw "The 'payload' folder is missing. Unzip the whole setup package first, then run Install TickAssist.bat from inside it."
}
$version = (Get-Content (Join-Path $payload "VERSION") -Raw).Trim()

Write-Host ""
Write-Host "  TickAssist $version setup" -ForegroundColor Cyan
Write-Host "  ------------------------"

$userDir = Join-Path $env:LOCALAPPDATA "Programs\TickAssist"
if ($ProgramFiles) { $Dir = Join-Path $env:ProgramFiles "TickAssist" } else { $Dir = $userDir }
$data = Join-Path $env:APPDATA "TickAssist"
Write-Host ""
Write-Host "  Installing to: $Dir"
Write-Host "  Settings, lists and macros are kept in: $data"
Write-Host "  (they survive updates, reinstalls and uninstalls)"

function Stop-CopyIn([string]$folder) {
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($folder, [StringComparison]::OrdinalIgnoreCase) } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

if (Test-Path $Dir) { Stop-CopyIn $Dir; Start-Sleep -Milliseconds 800 }

# A machine-wide install replaces an older per-user copy so there is only one.
if ($ProgramFiles -and (Test-Path $userDir)) {
    Stop-CopyIn $userDir
    Remove-Item $userDir -Recurse -Force -ErrorAction SilentlyContinue
}

New-Item -ItemType Directory -Force -Path $Dir  | Out-Null
New-Item -ItemType Directory -Force -Path $data | Out-Null

# Program files. The old app folder is replaced so no stale files linger.
$appDir = Join-Path $Dir "app"
if (Test-Path $appDir) { Remove-Item $appDir -Recurse -Force }
Copy-Item -Path (Join-Path $payload "*") -Destination $Dir -Recurse -Force
Copy-Item -Path (Join-Path $here "uninstall.ps1") -Destination $Dir -Force
Set-Content -Path (Join-Path $Dir "installed.txt") -Value ("Installed {0} by setup {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm"), $version)

if ($ProgramFiles) {
    # Let every user on this PC run TickAssist's one-click update.
    & icacls.exe $Dir /grant "*S-1-5-32-545:(OI)(CI)M" /T /C /Q | Out-Null
}

$launcher = Join-Path $Dir "run.bat"
$icon     = Join-Path $Dir "app\static\favicon.ico"

$maxLauncher = Join-Path $Dir "Open MAX.bat"

function New-AppShortcut([string]$path, [string]$target = $launcher, [string]$desc = "TickAssist") {
    $shell = New-Object -ComObject WScript.Shell
    $link = $shell.CreateShortcut($path)
    $link.TargetPath = $target
    $link.WorkingDirectory = $Dir
    $link.WindowStyle = 7            # minimised: the black window stays out of the way
    $link.Description = $desc
    if (Test-Path $icon) { $link.IconLocation = $icon }
    $link.Save()
}

if ($ProgramFiles) { $startFolder = "CommonPrograms"; $deskFolder = "CommonDesktopDirectory"; $hive = "HKLM" }
else               { $startFolder = "Programs";       $deskFolder = "Desktop";                $hive = "HKCU" }
New-AppShortcut (Join-Path ([Environment]::GetFolderPath($startFolder)) "TickAssist.lnk")
New-AppShortcut (Join-Path ([Environment]::GetFolderPath($startFolder)) "TickAssist - Open MAX.lnk") $maxLauncher "Open MAX so TickAssist can read it, even minimized"
if (-not $NoDesktopShortcut) {
    New-AppShortcut (Join-Path ([Environment]::GetFolderPath($deskFolder)) "TickAssist.lnk")
    New-AppShortcut (Join-Path ([Environment]::GetFolderPath($deskFolder)) "TickAssist - Open MAX.lnk") $maxLauncher "Open MAX so TickAssist can read it, even minimized"
}

# Settings > Apps entry with an Uninstall button.
$key = "${hive}:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TickAssist"
New-Item -Path $key -Force | Out-Null
Set-ItemProperty $key DisplayName     "TickAssist"
Set-ItemProperty $key DisplayVersion  $version
Set-ItemProperty $key Publisher       "Planmeca Support"
Set-ItemProperty $key InstallLocation $Dir
if (Test-Path $icon) { Set-ItemProperty $key DisplayIcon $icon }
Set-ItemProperty $key UninstallString ('powershell.exe -NoProfile -ExecutionPolicy Bypass -File "{0}"' -f (Join-Path $Dir "uninstall.ps1"))
Set-ItemProperty $key NoModify 1 -Type DWord
Set-ItemProperty $key NoRepair 1 -Type DWord

Write-Host ""
Write-Host "  Done. TickAssist $version is installed." -ForegroundColor Green
Write-Host "  Program:  $launcher"
Write-Host "  Start it from the Start menu, the desktop shortcut, or by calling run.bat from another program."
Write-Host "  Updates: Settings > Updates inside TickAssist."

if (-not $Quiet) {
    $go = Read-Host "  Start TickAssist now? (Y/n)"
    if ($go.Trim().ToLower() -ne "n") {
        Start-Process -FilePath "explorer.exe" -ArgumentList "`"$launcher`""
    }
}
