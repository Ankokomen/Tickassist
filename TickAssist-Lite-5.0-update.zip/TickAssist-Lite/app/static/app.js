/* TickAssist frontend - vanilla JS, no dependencies. */
"use strict";

const $ = (id) => document.getElementById(id);

// Null-safe event wiring: a missing/removed element never aborts init().
function on(id, event, handler) {
  const el = $(id);
  if (el) el.addEventListener(event, handler);
}

/* ---- generic helpers ---------------------------------------------------- */
async function api(method, path, body) {
  const opts = { method, headers: {} };
  if (body !== undefined) {
    opts.headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(path, opts);
  let data = null;
  try { data = await res.json(); } catch (e) { /* no body */ }
  if (!res.ok) {
    const msg = (data && data.error) || `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

function showToast(msg, kind = "indigo") {
  const wrap = $("toast-wrap");
  const el = document.createElement("div");
  el.className = `toast ${kind}`;
  el.textContent = msg;
  wrap.appendChild(el);
  requestAnimationFrame(() => el.classList.add("show"));
  setTimeout(() => {
    el.classList.remove("show");
    setTimeout(() => el.remove(), 300);
  }, 3000);
}

let modalResolver = null;
function confirmModal(title, body, confirmLabel = "Confirm") {
  $("modal-title").textContent = title;
  $("modal-body").textContent = body;
  $("modal-confirm").textContent = confirmLabel;
  $("modal").classList.remove("hidden");
  // Focus the confirm button so Enter confirms and there's a clear focus ring.
  setTimeout(() => $("modal-confirm").focus(), 0);
  return new Promise((resolve) => { modalResolver = resolve; });
}
function closeModal(result) {
  $("modal").classList.add("hidden");
  if (modalResolver) { modalResolver(result); modalResolver = null; }
}

// D365's timeline editor is a rich-text field: pasting plain text into it
// flattens the note onto one line. Marking the same text up with <br> gives
// that editor a flavor it keeps the line breaks from. Plain-text targets are
// unaffected - they take the text/plain flavor written alongside it.
function textToHtml(text) {
  return `<div>${escapeHtml(text).replace(/\n/g, "<br>")}</div>`;
}

// `html` may be a string or a promise of one - a promise keeps the click's
// clipboard permission while the photos are still being encoded.
async function writeClipboard(text, html) {
  if (navigator.clipboard && window.isSecureContext) {
    // Both flavors at once; falls back to plain text on anything that can't.
    if (window.ClipboardItem && navigator.clipboard.write) {
      try {
        const htmlBlob = Promise.resolve(html || textToHtml(text))
          .then((h) => new Blob([h], { type: "text/html" }));
        await navigator.clipboard.write([new ClipboardItem({
          "text/plain": new Blob([text], { type: "text/plain" }),
          "text/html": htmlBlob,
        })]);
        return;
      } catch (e) {
        if (html) throw e; // with photos, plain text alone would silently drop them
      }
    }
    await navigator.clipboard.writeText(text);
  } else {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    document.body.removeChild(ta);
  }
}

/* ---- the note with its photos, for pasting into D365 -------------------- */
// D365's rich-text note editor takes pictures pasted with the text and stores
// them with the note. Each photo goes in as an inline image, scaled so the
// clipboard stays a sensible size; plain-text targets just get the text.
const NOTE_PHOTO_MAX = 1280;

async function photoDataUrl(id) {
  const res = await fetch(`/api/photos/${id}`);
  if (!res.ok) throw new Error("Photo not found");
  const blob = await res.blob();
  const bmp = await createImageBitmap(blob);
  const scale = Math.min(1, NOTE_PHOTO_MAX / Math.max(bmp.width, bmp.height));
  let out = blob;
  // Small PNGs (screenshots) and small JPEGs go in as they are - sharpest text.
  if (scale < 1 || !/^image\/(png|jpeg)$/.test(blob.type) || blob.size > 1.5 * 1048576) {
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bmp.width * scale);
    canvas.height = Math.round(bmp.height * scale);
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#fff"; // transparent PNGs would turn black as JPEG
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(bmp, 0, 0, canvas.width, canvas.height);
    out = await canvasBlob(canvas, "image/jpeg", 0.85);
  }
  bmp.close();
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result);
    fr.onerror = () => reject(fr.error);
    fr.readAsDataURL(out);
  });
}

async function noteHtmlWithPhotos(text, list) {
  const parts = [textToHtml(text)];
  for (let i = 0; i < list.length; i++) {
    const src = await photoDataUrl(list[i].id);
    parts.push(`<div><br></div><div><img src="${src}" alt="${escapeHtml(list[i].name || "Photo " + (i + 1))}"` +
               ` style="max-width:100%;height:auto;"></div>`);
  }
  return parts.join("");
}

const notePhotos = () => (featureOn("photos") ? photos : []);

async function copyNote() {
  const text = noteForClipboard(buildNote());
  const list = notePhotos();
  if (!list.length) return copyText(text, "D365 note copied!");
  try {
    await writeClipboard(text, noteHtmlWithPhotos(text, list));
    showToast(`D365 note copied with ${list.length} photo${list.length === 1 ? "" : "s"} - paste it into the note`, "green");
  } catch (err) {
    showToast("Couldn't copy the photos with the note - copy them one by one instead", "red");
  }
}

async function copyText(text, successMsg) {
  try {
    await writeClipboard(text);
    showToast(successMsg, "green");
  } catch (err) {
    showToast("Failed to copy to clipboard", "red");
  }
}

// Seed the Windows clipboard history (Win+V): items are copied oldest-first
// with a short gap so each write registers as its own history entry. The
// last item remains on the live clipboard for a direct Ctrl+V.
// Items are strings, or { photo: id } for an image (see copyPhoto).
async function copySequence(items) {
  for (let i = 0; i < items.length; i++) {
    if (i) await new Promise((resolve) => setTimeout(resolve, 200));
    if (typeof items[i] === "string") await writeClipboard(items[i]);
    else if (items[i].note !== undefined) await writeClipboard(items[i].note, items[i].html);
    else await copyPhoto(items[i].photo);
  }
}

const escapeHtml = (s) => (s || "").replace(/[&<>"']/g, (c) => (
  { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
));

// SQLite stores created_at as UTC ("YYYY-MM-DD HH:MM:SS"); show local time.
function localDateTime(ts) {
  if (!ts) return "";
  const iso = ts.includes("T") ? ts : ts.replace(" ", "T");
  const d = new Date(iso.endsWith("Z") ? iso : iso + "Z");
  if (isNaN(d)) return ts;
  return d.toLocaleString(undefined, { dateStyle: "short", timeStyle: "short" });
}

function humanAge(ms) {
  const m = Math.round(ms / 60000);
  if (m < 1) return "moments";
  if (m < 60) return `${m} min`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h`;
  return `${Math.round(h / 24)} d`;
}

/* ---- theme -------------------------------------------------------------- */
// "auto" (default) resolves against the OS light/dark setting and tracks it
// live; the other options pin an explicit theme.
const THEME_KEY = "tickassist_theme";
const THEMES = ["auto", "dark", "light", "contrast", "lcars"];
const darkMedia = window.matchMedia
  ? window.matchMedia("(prefers-color-scheme: dark)") : null;
let themePref = "auto";

function resolveTheme(pref) {
  if (pref !== "auto") return pref;
  return darkMedia && darkMedia.matches ? "dark" : "light";
}

function applyTheme(pref) {
  if (!THEMES.includes(pref)) pref = "auto";
  themePref = pref;
  document.documentElement.dataset.theme = resolveTheme(pref);
  try { localStorage.setItem(THEME_KEY, pref); } catch (e) { /* private mode */ }
  document.querySelectorAll(".theme-option").forEach((b) =>
    b.classList.toggle("active", b.dataset.theme === pref));
  lcarsThemeChanged();   // alert + call card follow the theme
}

function initTheme() {
  let pref = "auto";
  try {
    pref = new URLSearchParams(location.search).get("theme") ||
      localStorage.getItem(THEME_KEY) || "auto";
  } catch (e) {}
  applyTheme(pref);
  if (darkMedia && darkMedia.addEventListener) {
    darkMedia.addEventListener("change", () => {
      if (themePref === "auto") applyTheme("auto");
    });
  }
}

/* ---- version badge ------------------------------------------------------ */
// The badge is normally substituted into the page server-side. It only lands
// unrendered if the page came from a server that predates that substitution -
// an instance still running older code while the files on disk have moved on.
// Rather than leave "{{VERSION}}" sitting in the topbar, ask the API.
async function ensureVersionBadge() {
  const el = $("app-version");
  if (!el || !el.textContent.includes("{{")) return;
  el.textContent = "";
  try {
    const info = await api("GET", "/api/health");
    if (info && info.version) el.textContent = `v${info.version}`;
  } catch (e) { /* leave it blank - better than showing the placeholder */ }
}

/* ---- navigation --------------------------------------------------------- */
function switchPage(page) {
  document.querySelectorAll(".nav-item").forEach((b) =>
    b.classList.toggle("active", b.dataset.page === page));
  document.querySelectorAll(".page").forEach((p) =>
    p.classList.toggle("active", p.id === `page-${page}`));
  if (page === "database") loadTickets();
  if (page === "dashboard") loadDashboard();
  if (page === "settings") { loadSettings(); loadAllLists(); loadMacros(); autosizeMacroExpansion(); }
}

/* ---- call type: the standing rotation ----------------------------------- */
// A tech works one rotation for days at a time, so this is a mode, not a
// per-note field: the topbar toggle holds it, every saved note is stamped with
// it, and it survives Clear, saves, and restarts until deliberately switched.
//
// Two values are in play. `callType` is what the note currently in the
// generator will be saved as; `standingCallType` is the rotation to fall back
// to whenever the form is cleared. They differ only while a saved ticket from
// the other rotation is open for editing - which is exactly what stops an old
// Troubleshooting note from being silently retagged on update.
const FIRST_IMPRESSIONS = "First Impressions";
const TROUBLESHOOTING = "Troubleshooting";
const CALL_TYPES = [FIRST_IMPRESSIONS, TROUBLESHOOTING];
const CALL_TYPE_KEY = "tickassist_call_type_v1";
const DEFAULT_CALL_TYPE = TROUBLESHOOTING;
// Notes written before the rename carry the singular; the server rewrites them
// on save and on startup, but a value can still arrive here from a stored
// draft or a pasted note.
const LEGACY_CALL_TYPES = { "First Impression": FIRST_IMPRESSIONS };
const canonicalCallType = (v) => LEGACY_CALL_TYPES[v] || v;

let callType = DEFAULT_CALL_TYPE;
let standingCallType = DEFAULT_CALL_TYPE;

function renderCallType() {
  document.querySelectorAll("[data-call-type-group] .mode-opt").forEach((b) =>
    b.setAttribute("aria-checked", String(b.dataset.callType === callType)));
  // Tints the topbar on the First Impressions rotation (see styles.css).
  document.body.dataset.rotation =
    callType === FIRST_IMPRESSIONS ? "first-impression" : "troubleshooting";
  // The handle timer only shows on First Impressions; its visibility follows
  // every path that moves the rotation (toggle, edit, restore, import).
  renderFiTimer();
}

// setStanding=false while editing a saved ticket: retag just that note without
// moving the rotation the next blank form will start from.
function setCallType(value, setStanding = true) {
  value = canonicalCallType(value);
  const before = callType;
  callType = CALL_TYPES.includes(value) ? value : DEFAULT_CALL_TYPE;
  if (callType !== before) { document.body.dataset.fiMore = ""; fiFolded = {}; }   // each rotation starts fresh
  if (setStanding) {
    standingCallType = callType;
    try { localStorage.setItem(CALL_TYPE_KEY, callType); } catch (e) {}
  }
  renderCallType();
}

function initCallType() {
  let stored = null;
  try { stored = canonicalCallType(localStorage.getItem(CALL_TYPE_KEY)); } catch (e) {}
  standingCallType = CALL_TYPES.includes(stored) ? stored : DEFAULT_CALL_TYPE;
  callType = standingCallType;
  renderCallType();
}

// The systems worked on are check boxes (a call can involve several). os_name
// is stored as "Windows, macOS"; a single value reads exactly as before.
function getOs() {
  return [...document.querySelectorAll('input[name="os"]:checked')].map((c) => c.value).join(", ");
}
// "Windows + macOS" when several, "Windows" when one.
function getOsLabel() { return getOs().split(", ").filter(Boolean).join(" + "); }
function setOs(text, fallback = true) {
  const want = String(text || "").split(/\s*[,+]\s*/).map((s) => s.trim().toLowerCase()).filter(Boolean);
  const boxes = [...document.querySelectorAll('input[name="os"]')];
  boxes.forEach((c) => { c.checked = want.includes(c.value.toLowerCase()); });
  if (fallback && !boxes.some((c) => c.checked)) boxes[0].checked = true;
}

/* ---- generator: form <-> field map -------------------------------------- */
// Maps DB column name -> form element id (radio handled separately).
const FIELD_MAP = {
  case_number: "caseNumber", case_title: "caseTitle", contact: "contact",
  contact_type: "contactType", phone: "phone", dealer_name: "dealerName",
  os_version: "osVersion", device_type: "deviceType",
  serial_number: "serialNumber", device_firmware: "deviceFirmware",
  device_tool_version: "deviceToolVersion",
  didapi: "didapi", romexis: "romexis",
  imaging_package: "imagingPackage", reco_os: "recoOs", reco_pc: "recoPc",
  reco_firmware: "recoFirmware",
  error_info: "errorInfo", part_rec: "partRec", problem: "problem",
  workflow: "workflow", next_steps: "nextSteps", res_status: "resStatus",
  outcome: "outcome",
};

const getVal = (id) => { const el = $(id); return el ? el.value.trim() : ""; };
const getRadio = (name) => {
  const el = document.querySelector(`input[name="${name}"]:checked`);
  return el ? el.value : "";
};

function normalizeResolutionStatus(status) {
  if (!status || status === "Completed") return "Resolved";
  return status;
}

function collectTicket() {
  const data = {};
  for (const [col, id] of Object.entries(FIELD_MAP)) data[col] = getVal(id);
  data.res_status = normalizeResolutionStatus(data.res_status);
  data.os_name = getOs();
  data.call_type = callType;
  data.note_text = buildNote();
  return data;
}

// True when the generator holds anything a user could lose by overwriting it.
function isFormDirty() {
  const alwaysSet = new Set(["caseNumber", "contactType", "resStatus"]);
  for (const id of Object.values(FIELD_MAP)) {
    if (!alwaysSet.has(id) && getVal(id)) return true;
  }
  if (!editing && photos.length) return true;
  return getVal("caseNumber") !== "CAS";
}

/* ---- generator: editing a saved ticket ----------------------------------- */
// When set, "Save to Database" becomes "Update Ticket" and PUTs in place.
let editing = null; // { id, label }

function renderEditBanner() {
  // The Case Entry rotation control belongs to an open ticket, so it comes and
  // goes with the edit session.
  const caseRotation = $("case-rotation");
  if (caseRotation) caseRotation.classList.toggle("hidden", !editing);

  const banner = $("edit-banner");
  if (!banner) return;
  banner.classList.toggle("hidden", !editing);
  if (editing) $("edit-banner-label").textContent = editing.label;
  const save = $("btn-save");
  if (save) save.textContent = editing ? "Update Ticket" : "Save to Database";
}

function setEditing(state) {
  const changed = (editing && editing.id) !== (state && state.id);
  editing = state;
  renderEditBanner();
  if (changed) loadPhotos();
}

function startEditing(ticket) {
  const label = ticket.case_number && ticket.case_number !== "CAS"
    ? ticket.case_number : `#${ticket.id}`;
  setEditing({ id: ticket.id, label });
}

function loadTicketIntoForm(t) {
  for (const [col, id] of Object.entries(FIELD_MAP)) {
    const el = $(id);
    if (!el) continue;
    if (col === "res_status") el.value = normalizeResolutionStatus(t[col]);
    else el.value = t[col] || "";
  }
  // Show the rotation this note was taken on, without moving the standing one:
  // reopening an old note must not change what the next blank form defaults to.
  setCallType(t.call_type || standingCallType, false);
  revealEnvIfFilled();
  checkRepeatCaller();
  setOs(t.os_name);
  // Values a saved note already holds are not re-checked unless changed.
  loadedListed = {};
  LISTED_FIELDS.forEach(([, id]) => { loadedListed[id] = getVal(id).toLowerCase(); $(id) && $(id).classList.remove("list-invalid"); });
  sheetRow = null;
  update();
  if (getVal("imagingPackage")) sheetLookup(false, true);
}

/* ---- generator: localStorage autosave (survives unexpected reloads) ----- */
const FORM_STORAGE_KEY = "tickassist_generator_v1";
const FORM_STORAGE_TTL_MS = 96 * 60 * 60 * 1000; // 96 hours
const FORM_FIELDS_SELECTOR =
  ".form-panel input, .form-panel textarea, .form-panel select";

function saveFormState() {
  const fields = {};
  document.querySelectorAll(FORM_FIELDS_SELECTOR).forEach((el) => {
    if (el.type === "radio") { if (el.checked) fields[el.name] = el.value; }
    else if (el.type === "checkbox") { if (el.checked) fields[el.name] = fields[el.name] ? fields[el.name] + ", " + el.value : el.value; }
    else if (el.id) fields[el.id] = el.value;
  });
  // callType rides along explicitly - the toggle lives in the topbar, outside
  // the .form-panel selector that collects everything else.
  const payload = { savedAt: Date.now(), fields, editing, callType,
                    fiTimerStart, fiTimerArmed };
  try { localStorage.setItem(FORM_STORAGE_KEY, JSON.stringify(payload)); }
  catch (e) { /* quota exceeded / private mode - non-fatal */ }
}

// The live preview updates on every keystroke; batching the localStorage
// write behind a short debounce keeps typing latency at zero.
let formSaveTimer = null;
function scheduleFormSave() {
  clearTimeout(formSaveTimer);
  formSaveTimer = setTimeout(saveFormState, 250);
}

function restoreFormState() {
  let stored = null;
  try { stored = JSON.parse(localStorage.getItem(FORM_STORAGE_KEY) || "null"); }
  catch (e) { stored = null; }
  if (!stored || typeof stored !== "object") return;

  // Enforce a max recovery age; older drafts are discarded automatically.
  const hasEnvelope = Object.prototype.hasOwnProperty.call(stored, "savedAt") &&
    Object.prototype.hasOwnProperty.call(stored, "fields");
  if (!hasEnvelope || typeof stored.savedAt !== "number" || !stored.fields ||
      typeof stored.fields !== "object") {
    try { localStorage.removeItem(FORM_STORAGE_KEY); } catch (e) {}
    return;
  }
  if (Date.now() - stored.savedAt > FORM_STORAGE_TTL_MS) {
    try { localStorage.removeItem(FORM_STORAGE_KEY); } catch (e) {}
    return;
  }

  const data = stored.fields;
  document.querySelectorAll(FORM_FIELDS_SELECTOR).forEach((el) => {
    if (el.type === "radio") {
      if (data[el.name] !== undefined) el.checked = (el.value === data[el.name]);
    } else if (el.type === "checkbox") {
      if (data[el.name] !== undefined) el.checked = String(data[el.name]).split(/\s*,\s*/).includes(el.value);
    } else if (el.id && data[el.id] !== undefined) {
      el.value = el.id === "resStatus"
        ? normalizeResolutionStatus(data[el.id])
        : data[el.id];
    }
  });

  // A restored draft keeps the rotation it was written on; the standing one is
  // untouched, since the draft may have been an edit of the other rotation.
  if (stored.callType) setCallType(stored.callType, false);

  // Re-enter edit mode if the draft was an open saved ticket.
  if (stored.editing && stored.editing.id) setEditing(stored.editing);

  // The handle timer rides with the draft, so an accidental reload mid-call
  // can't zero the clock on a First Impressions note.
  if (typeof stored.fiTimerStart === "number" && stored.fiTimerStart <= Date.now()) {
    fiTimerStart = stored.fiTimerStart;
    fiTimerArmed = !!stored.fiTimerArmed;
    renderFiTimer();
  }

  if (isFormDirty()) {
    showToast(`Restored unsaved draft from ${humanAge(Date.now() - stored.savedAt)} ago`, "slate");
  }
}

// Set the timestamp field to the current local time (and persist it).
function refreshTimestamp(notify) {
  const el = $("dateTime");
  if (!el) return;
  el.value = new Date().toLocaleString();
  saveFormState();
  if (notify) showToast("Timestamp updated to current time");
}

/* ---- generator: First Impressions handle timer ---------------------------- */
// First Impressions calls are meant to stay short, so on that rotation the
// preview header shows how long the note in hand has been in progress. The
// count starts at the first entry into any field, or at an explicit
// double-click of the timestamp (which marks the start of a call before
// anything is typed); it holds at 00:00 while the note is empty, and resets
// whenever the form does (save, clear, stop-editing). From 10 minutes the
// readout takes on a faint glow, ramping steadily to full phosphor at 15 -
// a continuous build, never a blink (see .fi-timer in styles.css). The clock
// keeps running across a rotation toggle and is merely hidden on
// Troubleshooting, so flipping the toggle mid-note cannot cheat it.
const FI_GLOW_START_MS = 10 * 60 * 1000;
const FI_GLOW_FULL_MS = 15 * 60 * 1000;
const FI_PULSE_MS = 17 * 60 * 1000; // full phosphor starts gently breathing

let fiTimerStart = null;  // epoch ms the note began, or null while idle
let fiTimerArmed = false; // dbl-click start: keeps counting while still empty

function renderFiTimer() {
  const el = $("fi-timer");
  if (!el) return;
  el.classList.toggle("hidden", callType !== FIRST_IMPRESSIONS);
  const secs = fiTimerStart ? Math.max(0, Math.floor((Date.now() - fiTimerStart) / 1000)) : 0;
  el.textContent =
    `${String(Math.floor(secs / 60)).padStart(2, "0")}:${String(secs % 60).padStart(2, "0")}`;
  const glow = Math.min(1, Math.max(0,
    (secs * 1000 - FI_GLOW_START_MS) / (FI_GLOW_FULL_MS - FI_GLOW_START_MS)));
  el.style.setProperty("--fi-glow", glow.toFixed(3));
  el.classList.toggle("pulse", fiTimerStart !== null && secs * 1000 >= FI_PULSE_MS);
}

function startFiTimer(armed = false) {
  if (armed) fiTimerArmed = true;
  if (fiTimerStart !== null) return;
  if (!armed && !isFormDirty()) return;
  fiTimerStart = Date.now();
  renderFiTimer();
}

function resetFiTimer() {
  fiTimerStart = null;
  fiTimerArmed = false;
  renderFiTimer();
}

// Ride along with every field edit: begin counting once the note holds
// anything, and fall back to 00:00 if the user erases the little they typed
// (unless the start was armed explicitly via the timestamp double-click).
// Deferred a tick because sibling input handlers (autoGenerateTitle) may
// still be about to change fields this dirtiness check depends on.
function fiTimerOnInput() {
  setTimeout(() => {
    if (isFormDirty()) startFiTimer(false);
    else if (!fiTimerArmed) resetFiTimer();
  }, 0);
}

/* ---- generator: collapsible System Environment --------------------------- */
// The block is tall and often untouched for a whole shift, so it folds away to
// keep the form on one screen. Collapsing only hides it - every field keeps its
// value, still saves, and still restores - so the header carries a summary of
// what is filled in, and the section springs open if an import fills it.
const ENV_COLLAPSED_KEY = "tickassist_env_collapsed_v1";
// Order matters: this is what the collapsed summary reads out.
const ENV_SUMMARY_FIELDS = [
  "deviceType", "serialNumber", "osVersion", "deviceFirmware",
  "deviceToolVersion", "didapi", "romexis", "imagingPackage", "recoOs", "recoPc",
  "recoFirmware",
];
const ENV_SUMMARY_MAX = 3;

function setEnvCollapsed(collapsed, persist = true) {
  const section = $("env-section");
  const toggle = $("env-toggle");
  if (!section || !toggle) return;
  section.classList.toggle("collapsed", collapsed);
  toggle.setAttribute("aria-expanded", String(!collapsed));
  if (persist) {
    try { localStorage.setItem(ENV_COLLAPSED_KEY, collapsed ? "1" : "0"); }
    catch (e) {}
  }
  renderEnvSummary();
}

// "Promax 3D Mid · ABC123 · 5.2 +2 more" - enough to see the block is not empty
// without expanding it.
function renderEnvSummary() {
  const el = $("env-summary");
  if (!el) return;
  const values = ENV_SUMMARY_FIELDS.map(getVal).filter(Boolean);
  if (!values.length) {
    el.textContent = "empty";
    return;
  }
  const shown = values.slice(0, ENV_SUMMARY_MAX).join(" · ");
  const rest = values.length - ENV_SUMMARY_MAX;
  el.textContent = rest > 0 ? `${shown} +${rest} more` : shown;
}

// Called after anything fills the form for the user (an import, or opening a
// saved ticket). Values landing inside a folded section would otherwise be easy
// to miss. The stored preference is deliberately left alone - this is a reveal
// for the note in hand, not a change of mind about the default.
function revealEnvIfFilled() {
  const section = $("env-section");
  if (!section || !section.classList.contains("collapsed")) return;
  if (ENV_SUMMARY_FIELDS.some((id) => getVal(id))) setEnvCollapsed(false, false);
}

function initEnvCollapsed() {
  let stored = null;
  try { stored = localStorage.getItem(ENV_COLLAPSED_KEY); } catch (e) {}
  setEnvCollapsed(stored === "1", false);
}

/* ---- generator: repeat-caller notice ------------------------------------ */
// Knowing you are about to take a third call from the same number changes how
// the call opens, so the generator says so as the number is typed. Matched on
// digits server-side, debounced, and rendered inline: a modal would interrupt
// typing with a customer already on the line.
let repeatLookupTimer = null;
let repeatLookupToken = 0;
// Digits the notice has been dismissed for. Scoped to the number rather than
// to the session: waving it away for this caller should not blind you to the
// next one, and it comes back if you retype a different number.
let repeatDismissedDigits = "";

function clearRepeatCaller() {
  const el = $("repeat-caller");
  if (el) { el.classList.add("hidden"); el.innerHTML = ""; }
}

// "Called before - Jane Doe, \"sensor not detected\" (2 total tickets, most
// recently 8/17/26, 8:16 AM)". The name and the last thing they called about
// are what actually change how the call opens; the count and timestamp are
// supporting detail. Each part is dropped rather than faked when the earlier
// note did not record it.
const RC_ISSUE_MAX = 70;

function renderRepeatCaller(matches, phone) {
  const el = $("repeat-caller");
  if (!el) return;
  if (!matches.length) return clearRepeatCaller();

  const newest = matches[0];
  const n = matches.length;
  // The name and issue come from the most recent earlier call, which is the
  // one worth recalling - but fall back through the other matches if it did
  // not record them.
  const name = (matches.find((m) => (m.contact || "").trim()) || {}).contact || "";
  const withIssue = matches.find((m) => (m.problem || m.case_title || "").trim()) || {};
  let issue = (withIssue.problem || withIssue.case_title || "").trim().replace(/\s+/g, " ");
  if (issue.length > RC_ISSUE_MAX) issue = issue.slice(0, RC_ISSUE_MAX - 1).trimEnd() + "…";

  const bits = [];
  if (name) bits.push(`<span class="rc-name">${escapeHtml(name)}</span>`);
  if (issue) bits.push(`&ldquo;${escapeHtml(issue)}&rdquo;`);
  const lead = bits.length ? bits.join(", ") + " " : "";

  el.innerHTML =
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/></svg>` +
    `<span class="rc-text">Called before &mdash; ${lead}` +
    `<span class="rc-meta">(${n} total ${n === 1 ? "ticket" : "tickets"}, ` +
    `most recently ${escapeHtml(localDateTime(newest.created_at))})</span></span>` +
    `<button type="button" class="btn-link" data-repeat-phone="${escapeHtml(phone)}">View</button>` +
    `<button type="button" class="rc-close" data-repeat-dismiss aria-label="Dismiss this notice" title="Dismiss">` +
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>`;
  el.classList.remove("hidden");
}

function checkRepeatCaller() {
  const phone = getVal("phone");
  const digits = phone.replace(/\D/g, "");
  clearTimeout(repeatLookupTimer);
  if (knownCallerFill && knownCallerFill.digits !== digits) undoKnownCallerFill();
  if (digits.length < 7) return clearRepeatCaller();
  if (digits === repeatDismissedDigits) return clearRepeatCaller();
  const token = ++repeatLookupToken;
  repeatLookupTimer = setTimeout(async () => {
    try {
      const data = await api("GET", `/api/tickets/lookup?phone=${encodeURIComponent(phone)}`);
      // A slower earlier request must not overwrite a newer answer.
      if (token !== repeatLookupToken) return;
      // While editing a saved ticket, that ticket is not a previous call.
      const matches = (data.matches || [])
        .filter((t) => !(editing && Number(t.id) === Number(editing.id)));
      renderRepeatCaller(matches, phone);
      fillKnownCaller(matches, digits);
    } catch (e) { clearRepeatCaller(); }
  }, 350);
}

/* ---- generator: live preview -------------------------------------------- */
const hasVal = (v) => v && v.trim() !== "";

// Format a US phone number as the user types: digits only -> ###-###-####.
function formatPhone(value) {
  const d = value.replace(/\D/g, "").slice(0, 15); // E.164 caps at 15 digits
  const local = (n) => {
    if (n.length <= 3) return n;
    if (n.length <= 6) return `${n.slice(0, 3)}-${n.slice(3)}`;
    return `${n.slice(0, 3)}-${n.slice(3, 6)}-${n.slice(6)}`;
  };
  if (d.length <= 10) return local(d);
  // 11+ digits: leading digits are the country code, last 10 the local number.
  const cc = d.slice(0, d.length - 10);
  return `+${cc} ${local(d.slice(d.length - 10))}`;
}

function autoGenerateTitle() {
  const parts = [getVal("deviceType"), getVal("problem"), getVal("serialNumber")]
    .filter(Boolean);
  $("caseTitle").value = parts.join(" - ");
  update();
}

function toggle(id, hidden) { $(id).classList.toggle("hidden", hidden); }

function update() {
  const type = $("contactType").value;
  toggle("dealerContainer", type !== "Dealer");
  applyRequiredMarks();
  applySheetCheck();
  renderFiMore();

  $("prev-caseNumber").textContent = $("caseNumber").value || "CAS";
  $("prev-title").textContent = $("caseTitle").value;
  toggle("btn-copy-title", !hasVal($("caseTitle").value));

  // Always shown: the note always carries a rotation, so the preview must too.
  $("disp-callType").textContent = callType;

  const when = $("dateTime").value;
  toggle("disp-date-row", !hasVal(when));
  $("disp-date").textContent = when;

  const contact = $("contact").value;
  toggle("disp-contact-row", !hasVal(contact));
  $("disp-contact").textContent = contact;

  toggle("disp-type-row", !hasVal(type));
  $("disp-type").textContent = type;

  const phone = $("phone").value;
  toggle("disp-phone-row", !hasVal(phone));
  $("disp-phone").textContent = phone;

  const dealer = $("dealerName").value;
  const showDealer = type === "Dealer" && hasVal(dealer);
  toggle("disp-dealer-row", !showDealer);
  $("disp-dealer").textContent = dealer;

  const os = getOsLabel();
  const osVer = $("osVersion").value;
  const deviceType = $("deviceType").value;
  const deviceFw = $("deviceFirmware").value;
  const deviceTool = $("deviceToolVersion").value;
  const didapi = $("didapi").value;
  const romexis = $("romexis").value;
  const imgPkg = $("imagingPackage").value;
  const recoOs = $("recoOs").value;
  const reco = $("recoPc").value;
  const recoFw = $("recoFirmware").value;
  const serial = $("serialNumber").value;
  let hasEnv = false;

  if (hasVal(deviceType)) { toggle("disp-deviceType-row", false); $("disp-deviceType").textContent = deviceType; hasEnv = true; }
  else toggle("disp-deviceType-row", true);

  if (hasVal(osVer) || os) { toggle("disp-os-row", false); $("disp-osVersion").textContent = `${os} ${osVer}`.trim(); hasEnv = true; }
  else toggle("disp-os-row", true);

  if (hasVal(deviceFw) || hasVal(deviceTool)) { toggle("disp-devicefw-row", false); $("disp-deviceFirmware").textContent = deviceFw || "N/A"; $("disp-deviceToolVersion").textContent = deviceTool || "N/A"; hasEnv = true; }
  else toggle("disp-devicefw-row", true);

  if (hasVal(didapi) || hasVal(romexis)) { toggle("disp-versions-row", false); $("disp-didapi").textContent = didapi || "N/A"; $("disp-romexis").textContent = romexis || "N/A"; hasEnv = true; }
  else toggle("disp-versions-row", true);

  if (hasVal(imgPkg)) { toggle("disp-package-row", false); $("disp-imagingPackage").textContent = imgPkg; hasEnv = true; }
  else toggle("disp-package-row", true);

  if (hasVal(recoOs)) { toggle("disp-recoos-row", false); $("disp-recoOs").textContent = recoOs; hasEnv = true; }
  else toggle("disp-recoos-row", true);

  if (hasVal(reco) || hasVal(serial)) { toggle("disp-reco-row", false); $("disp-recoPc").textContent = reco || "N/A"; $("disp-serialNumber").textContent = serial || "N/A"; hasEnv = true; }
  else toggle("disp-reco-row", true);

  if (hasVal(recoFw)) { toggle("disp-recofw-row", false); $("disp-recoFirmware").textContent = recoFw; hasEnv = true; }
  else toggle("disp-recofw-row", true);

  toggle("env-block", !hasEnv);
  renderEnvSummary();

  const err = $("errorInfo").value;
  toggle("error-block", !hasVal(err)); $("disp-error").textContent = err;

  const part = $("partRec").value;
  toggle("part-block", !hasVal(part)); $("disp-part").textContent = part;

  const problem = $("problem").value;
  toggle("problem-block", !hasVal(problem)); $("disp-problem").textContent = problem;

  const workflow = $("workflow").value;
  toggle("workflow-block", !hasVal(workflow)); $("disp-workflow").textContent = workflow;

  const nextSteps = $("nextSteps").value;
  toggle("nextSteps-block", !hasVal(nextSteps)); $("disp-nextSteps").textContent = nextSteps;

  $("disp-res-status").textContent = normalizeResolutionStatus($("resStatus").value);

  const outcome = $("outcome").value;
  toggle("outcome-block", !hasVal(outcome)); $("disp-outcome").textContent = outcome;

  scheduleFormSave();
}

/* ---- generator: note builder -------------------------------------------- */
const NOTE_DIVIDER = "\n-------------------------------------------------\n";

function buildNote() {
  const blocks = [];
  const divider = NOTE_DIVIDER;

  const meta = [];
  const caseId = getVal("caseNumber");
  if (caseId && caseId !== "CAS") meta.push(`SERVICE NOTE: ${caseId}`);
  const title = getVal("caseTitle");
  if (title) meta.push(`TITLE: ${title}`);
  const when = getVal("dateTime");
  if (when) meta.push(`DATE: ${when}`);
  meta.push(`CALL TYPE: ${callType}`);
  if (meta.length) blocks.push(meta.join("\n"));

  const contactLines = [];
  const contact = getVal("contact");
  const contactType = $("contactType").value;
  if (contact) contactLines.push(`CONTACT: ${contact} (${contactType})`);
  else if (contactType) contactLines.push(`CONTACT TYPE: ${contactType}`);
  const phone = getVal("phone");
  if (phone) contactLines.push(`PHONE: ${phone}`);
  const dealer = getVal("dealerName");
  if (dealer && contactType === "Dealer") contactLines.push(`DEALER: ${dealer}`);
  if (contactLines.length) blocks.push(contactLines.join("\n"));

  const envLines = [];
  const deviceType = getVal("deviceType");
  const os = getOsLabel(); const osVer = getVal("osVersion");
  if (deviceType) envLines.push(`- Device Type: ${deviceType}`);
  if (os || osVer) envLines.push(getOs().includes(",") ? `- OS: ${os}${osVer ? ": " + osVer : ""}` : `- OS: ${os} ${osVer}`.trim());
  if (getVal("deviceFirmware")) envLines.push(`- Device Firmware: ${getVal("deviceFirmware")}`);
  if (getVal("deviceToolVersion")) envLines.push(`- Device Tool: ${getVal("deviceToolVersion")}`);
  if (getVal("didapi")) envLines.push(`- DIDAPI: ${getVal("didapi")}`);
  if (getVal("romexis")) envLines.push(`- Romexis: ${getVal("romexis")}`);
  if (getVal("imagingPackage")) envLines.push(`- Imaging Package: ${getVal("imagingPackage")}`);
  if (getVal("recoOs")) envLines.push(`- Reco System OS: ${getVal("recoOs")}`);
  if (getVal("recoPc")) envLines.push(`- Reco PC: ${getVal("recoPc")}`);
  if (getVal("recoFirmware")) envLines.push(`- Reco Firmware: ${getVal("recoFirmware")}`);
  if (getVal("serialNumber")) envLines.push(`- Unit Serial: ${getVal("serialNumber")}`);
  if (envLines.length) blocks.push("ENVIRONMENT:\n" + envLines.join("\n"));

  if (getVal("errorInfo")) blocks.push(`ERROR/LOG INFO:\n${getVal("errorInfo")}`);
  if (getVal("partRec")) blocks.push(`PART RECOMMENDATION:\n${getVal("partRec")}`);
  if (getVal("problem")) blocks.push(`ISSUE:\n${getVal("problem")}`);
  if (getVal("workflow")) blocks.push(`TROUBLESHOOTING:\n${getVal("workflow")}`);
  if (getVal("nextSteps")) blocks.push(`NEXT STEPS:\n${getVal("nextSteps")}`);

  const outcome = getVal("outcome");
  if (outcome) {
    blocks.push(`RESOLUTION STATUS: ${normalizeResolutionStatus($("resStatus").value)}\nRESOLUTION:\n${outcome}`);
  }

  return blocks.join(divider) + "\n_________________________________________________";
}

// Clipboard copies omit the TITLE and DATE meta lines - D365 supplies both
// itself - and the CALL TYPE line, which is our own rotation bookkeeping and
// means nothing in a customer-facing case. All three stay in the saved note,
// so the repository and Import keep them. Only the header block (before the
// first divider) is filtered, so body text that happens to start a line with
// "DATE:" is never touched.
function noteForClipboard(noteText) {
  const text = noteText || "";
  const idx = text.indexOf(NOTE_DIVIDER);
  const head = (idx === -1 ? text : text.slice(0, idx))
    .split(/\r?\n/)
    .filter((line) => !/^(?:TITLE|DATE|CALL TYPE):/.test(line))
    .join("\n");
  const rest = idx === -1 ? "" : text.slice(idx);
  // If the whole header was meta, drop the now-leading divider too.
  return head ? head + rest : rest.replace(NOTE_DIVIDER, "");
}

/* ---- generator: bullet normalization ------------------------------------ */
// Frontend twin of llm._normalize_bullets: force each "* " bullet onto its own
// line. AI Polish normalizes server-side, but text that is TYPED or IMPORTED
// never passes through polish - this catches those paths (Troubleshooting /
// Next Steps) so "a* b* c" doesn't survive as one jammed line.
function normalizeBullets(text) {
  if (!text || !text.trim()) return "";
  let s = text.replace(/\r\n?/g, "\n").trim();
  if (!s.includes("*")) return s;          // plain prose - leave it be
  s = s.replace(/\s*\*+\s*/g, "\n* ");      // each bullet -> newline + "* "
  return s.replace(/\n{2,}/g, "\n").replace(/^\n+|\n+$/g, "");
}

// Reflow a textarea's bullets in place (no-op when nothing changes).
function normalizeBulletField(id) {
  const el = $(id);
  if (!el) return;
  const fixed = normalizeBullets(el.value);
  if (fixed !== el.value) el.value = fixed;
}

/* ---- generator: import (parse a copied note back into the form) --------- */
// The inverse of buildNote(): recognizes the labeled blocks a service note is
// made of and returns { <form-field-id>: value, osName } for the fields found.
// Tolerant of the two shapes a note ships in - the full saved note (with TITLE
// / DATE meta) and the clipboard copy (which strips those lines).
const OS_NAMES = ["Windows Server", "Windows", "macOS"]; // longest-match first
const IMPORT_FIELD_IDS = [
  "caseNumber", "caseTitle", "dateTime", "contact", "contactType", "phone",
  "dealerName", "osVersion", "deviceType", "serialNumber", "deviceFirmware",
  "deviceToolVersion", "didapi", "romexis", "imagingPackage", "recoOs", "recoPc",
  "recoFirmware", "errorInfo", "partRec", "problem", "workflow",
  "nextSteps", "resStatus", "outcome",
];
// The case number heads the note, but not always as our own "SERVICE NOTE:"
// line: a note that comes back from D365 (or off the preview panel) can carry
// it as "Case Number: ...", "Case #: ...", or "Technical Note: ...".
const CASE_HEADER_RE =
  /^(?:(SERVICE NOTE)|TECHNICAL NOTE|CASE(?:\s*(?:NUMBER|NUM|NO\.?|ID|#))?)\s*[:#]+\s*(.*)$/i;
// A bare case id ("CAS0485000"). Used for a note whose first line is nothing
// but the number, and to vet the labels above so a line like
// "Case: closed by the dealer" can't be mistaken for one.
const CASE_ID_RE = /^[A-Za-z]{2,4}[-\s]?\d{3,}$/;

// A case number is a short token, so never accept a value that runs on into
// the rest of the note - keep the id at its head instead. This is the backstop
// for a note that arrives without its line breaks (see repairLostLineBreaks).
const CASE_VALUE_MAX = 24;
function tidyCaseNumber(value) {
  if (CASE_ID_RE.test(value)) return value;
  const m = value.match(/^[A-Za-z]{2,4}[-\s]?\d{3,}/);
  if (m) return m[0];
  return value.length <= CASE_VALUE_MAX ? value : "";
}

// The case number `line` carries, or "" when it isn't a case header at all.
// Our own label is trusted as-is; the looser ones must look like an id.
function parseCaseHeader(line) {
  const m = line.match(CASE_HEADER_RE);
  if (!m) return "";
  const value = tidyCaseNumber((m[2] || "").trim());
  if (!value) return "";
  return m[1] || CASE_ID_RE.test(value) ? value : "";
}

/* -- import: rebuild a note that lost its line breaks in D365 ------------- */
// Pasted into a D365 timeline entry, a note can come back as one run-on line.
// Its dividers and labels survive, so the lines can be rebuilt from those.
// A note that kept its breaks is returned untouched: the trigger is a divider
// welded to text, which never happens in a note we wrote.
const INLINE_LABELS =
  "SERVICE NOTE|TITLE|DATE|CALL TYPE|CONTACT TYPE|CONTACT|PHONE|DEALER|" +
  "RESOLUTION STATUS";
const BLOCK_LABELS =
  "ENVIRONMENT|ERROR/LOG INFO|PART RECOMMENDATION|ISSUE|TROUBLESHOOTING|" +
  "NEXT STEPS|RESOLUTION";
const ENV_LABELS = "Device Type|Device Firmware|Device Tool|OS|DIDAPI|Romexis|" +
  "Imaging Package|Reco System OS|Reco PC|Reco Firmware|Unit Serial";

function repairLostLineBreaks(text) {
  // Note the excluded "-": the neighbour must be real text, or every divider
  // would match itself (a dash is also a non-newline character).
  const welded = /[^\n-]-{5,}|-{5,}[^\n-]/.test(text);
  const oneLiner = !text.includes("\n") &&
    new RegExp(`(?:${INLINE_LABELS}|${BLOCK_LABELS}):`, "i").test(text);
  if (!welded && !oneLiner) return text;
  return text
    .replace(/\s*_{5,}\s*/g, "\n")                        // signature rule
    .replace(/\s*(-{5,})\s*/g, "\n$1\n")                  // block dividers
    .replace(new RegExp(`\\s*((?:${INLINE_LABELS}):)\\s*`, "gi"), "\n$1 ")
    .replace(new RegExp(`\\s*(${BLOCK_LABELS}):\\s*`, "gi"), "\n$1:\n")
    .replace(new RegExp(`\\s*(-\\s*(?:${ENV_LABELS}):)\\s*`, "gi"), "\n$1 ")
    .replace(/\n{2,}/g, "\n")
    .replace(/^\n+|\n+$/g, "");
}

// Headers whose value is the (possibly multi-line) remainder of their block.
const MULTILINE_HEADERS = {
  "ERROR/LOG INFO": "errorInfo",
  "PART RECOMMENDATION": "partRec",
  "ISSUE": "problem",
  "TROUBLESHOOTING": "workflow",
  "NEXT STEPS": "nextSteps",
  "RESOLUTION": "outcome",
};

// "John Doe (Dealer)" -> contact + contactType; bare text -> contact only.
function parseContactLine(s, out) {
  const m = s.match(/^(.*?)\s*\(([^)]*)\)\s*$/);
  if (m) { out.contact = m[1].trim(); out.contactType = m[2].trim(); }
  else out.contact = s;
}

// "Windows Server 2019" -> osName "Windows Server", osVersion "2019".
function parseOsLine(s, out) {
  for (const n of OS_NAMES) {
    const low = s.toLowerCase();
    if (low === n.toLowerCase() || low.startsWith(n.toLowerCase() + " ")) {
      out.osName = n;
      out.osVersion = s.slice(n.length).trim();
      return;
    }
  }
  out.osVersion = s; // unknown OS name: keep the version, leave the radio default
}

function parseNoteBlock(block, out) {
  const lines = block.split(/\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    let m;
    const caseId = parseCaseHeader(line);
    if (caseId) out.caseNumber = caseId;
    else if ((m = line.match(/^TITLE:\s*(.*)$/i))) out.caseTitle = m[1].trim();
    else if ((m = line.match(/^DATE:\s*(.*)$/i))) out.dateTime = m[1].trim();
    else if ((m = line.match(/^CALL TYPE:\s*(.*)$/i))) out.callType = m[1].trim();
    else if ((m = line.match(/^CONTACT:\s*(.*)$/i))) parseContactLine(m[1].trim(), out);
    else if ((m = line.match(/^CONTACT TYPE:\s*(.*)$/i))) out.contactType = m[1].trim();
    else if ((m = line.match(/^PHONE:\s*(.*)$/i))) out.phone = m[1].trim();
    else if ((m = line.match(/^DEALER:\s*(.*)$/i))) out.dealerName = m[1].trim();
    else if ((m = line.match(/^-\s*Device Type:\s*(.*)$/i))) out.deviceType = m[1].trim();
    else if ((m = line.match(/^-\s*Device Firmware:\s*(.*)$/i))) out.deviceFirmware = m[1].trim();
    else if ((m = line.match(/^-\s*Device Tool(?:\s*Ver(?:sion)?)?:\s*(.*)$/i))) out.deviceToolVersion = m[1].trim();
    else if ((m = line.match(/^-\s*OS:\s*(.*)$/i))) parseOsLine(m[1].trim(), out);
    else if ((m = line.match(/^-\s*DIDAPI:\s*(.*)$/i))) out.didapi = m[1].trim();
    else if ((m = line.match(/^-\s*Romexis:\s*(.*)$/i))) out.romexis = m[1].trim();
    else if ((m = line.match(/^-\s*Imaging Package:\s*(.*)$/i))) out.imagingPackage = m[1].trim();
    else if ((m = line.match(/^-\s*Reco (?:System )?OS:\s*(.*)$/i))) out.recoOs = m[1].trim();
    else if ((m = line.match(/^-\s*Reco PC:\s*(.*)$/i))) out.recoPc = m[1].trim();
    else if ((m = line.match(/^-\s*Reco Firmware:\s*(.*)$/i))) out.recoFirmware = m[1].trim();
    else if ((m = line.match(/^-\s*Unit Serial:\s*(.*)$/i))) out.serialNumber = m[1].trim();
    else if ((m = line.match(/^RESOLUTION STATUS:\s*(.*)$/i))) out.resStatus = m[1].trim();
    else if (/^ENVIRONMENT:\s*$/i.test(line)) { /* section header, no value */ }
    else {
      // A bare "HEADER:" line claims the rest of the block as its value.
      const key = MULTILINE_HEADERS[line.replace(/:\s*$/, "").toUpperCase()];
      if (key) {
        out[key] = lines.slice(i + 1).join("\n").trim();
        break;
      }
    }
  }
}

function parseNote(text) {
  const out = {};
  // Rich-text paths deliver non-breaking spaces where the note had plain ones.
  let t = (text || "").replace(/\r\n/g, "\n").replace(/\u00a0/g, " ");
  t = repairLostLineBreaks(t);
  t = t.replace(/\n_{5,}\s*$/, ""); // drop the trailing underscore signature line
  t.split(/\n-{5,}\n/).forEach((block) => parseNoteBlock(block, out));
  // Some copies carry the case number unlabeled on the very first line - take
  // it from there when no header claimed one.
  if (out.caseNumber === undefined) {
    const first = (t.split("\n").find((l) => l.trim()) || "").trim();
    if (CASE_ID_RE.test(first)) out.caseNumber = first;
  }
  return out;
}

// Write the parsed values into the form; returns how many fields were filled.
// Only fields the note actually mentioned are touched - untouched form fields
// keep their current value. Select values are applied only if they're a real
// option, so a stray contact/resolution label can't jam the dropdown.
function applyImport(out) {
  let count = 0;
  for (const id of IMPORT_FIELD_IDS) {
    if (out[id] === undefined) continue;
    const el = $(id);
    if (!el) continue;
    if (el.tagName === "SELECT") {
      if ([...el.options].some((o) => o.value === out[id])) { el.value = out[id]; count++; }
    } else {
      el.value = out[id];
      count++;
    }
  }
  if (out.osName) {
    setOs(out.osName, false); count++;
  }
  // An imported note tags this draft only - an unrecognised value is ignored,
  // and the standing rotation is never moved by pasting someone else's note.
  if (out.callType && CALL_TYPES.includes(out.callType)) {
    setCallType(out.callType, false);
    count++;
  }
  revealEnvIfFilled();
  return count;
}

// Read the copied note straight off the clipboard and fill the form - no
// intermediate dialog. localhost is a secure context, so readText() works;
// if the browser blocks it (or the clipboard holds no note), we say so.
async function importNote() {
  let text = "";
  try {
    if (!navigator.clipboard || !navigator.clipboard.readText) throw new Error("no clipboard API");
    text = await navigator.clipboard.readText();
  } catch (e) {
    showToast("Couldn't read the clipboard — copy the note, then allow clipboard access", "red");
    return;
  }
  if (!text || !text.trim()) { showToast("Clipboard is empty — copy a note first", "red"); return; }
  let out, count;
  try {
    out = parseNote(text);
    count = applyImport(out);
  } catch (err) {
    // Never fail silently: an unhandled throw here would leave the button dead.
    showToast(`Couldn't read that note: ${err.message}`, "red");
    return;
  }
  if (!count) {
    showToast("No recognizable fields in the copied note", "red");
    return;
  }
  // Split any inline bullets the source note carried in unbroken.
  normalizeBulletField("workflow");
  normalizeBulletField("nextSteps");
  // No title in the note (the clipboard copy strips it)? Rebuild it from the
  // imported device / problem / serial / status so the preview isn't blank.
  if (out.caseTitle === undefined) autoGenerateTitle();
  update();
  saveFormState();
  showToast(`Imported ${count} field${count === 1 ? "" : "s"} from the clipboard`, "green");
}

/* ---- generator: AI polish ----------------------------------------------- */
// LCARS only: a scan overlay pinned to the visible part of the note preview
// (so it shows on a long note and wherever the panel is scrolled). Other
// themes, and anyone who asked for reduced motion, never create it.
let aiScanEl = null;
let aiScanTimer = null;
function startAiScan() {
  stopAiScan(false);
  if (document.documentElement.dataset.theme !== "lcars") return;
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const body = $("print-area");
  const panel = body && body.closest(".panel");
  if (!panel) return;
  const pr = panel.getBoundingClientRect();
  const head = panel.querySelector(".preview-head");
  const bar = document.querySelector(".topbar");
  const top = Math.max(head ? head.getBoundingClientRect().bottom : pr.top,
                       bar ? bar.getBoundingClientRect().bottom : 0);
  const bottom = Math.min(pr.bottom, window.innerHeight);
  const left = pr.left + panel.clientLeft;
  const width = Math.min(pr.right, window.innerWidth) - left;
  if (bottom - top < 40 || width < 40) return;
  const el = document.createElement("div");
  el.className = "ai-scan";
  el.style.cssText = `left:${left}px;top:${top}px;width:${width}px;height:${bottom - top}px;--h:${bottom - top}px`;
  el.innerHTML = '<i class="ai-scan-band"></i>';
  document.body.appendChild(el);
  aiScanEl = el;
}
function stopAiScan(finished) {
  clearTimeout(aiScanTimer);
  const el = aiScanEl;
  aiScanEl = null;
  if (!el) return;
  if (finished) {            // one fast closing pass, then remove
    el.classList.add("done");
    aiScanTimer = setTimeout(() => el.remove(), 900);
  } else {
    el.remove();
  }
}

// What the fields held before the last AI Polish, until undone or the form
// is cleared. The model can rewrite more than the technician wanted.
let polishUndo = null;
function renderPolishUndo(show) {
  const b = $("btn-polish-undo");
  if (b) b.classList.toggle("hidden", !(show && polishUndo));
}
function undoPolish() {
  if (!polishUndo) return;
  $("problem").value = polishUndo.problem; $("workflow").value = polishUndo.workflow;
  $("nextSteps").value = polishUndo.nextSteps; $("contact").value = polishUndo.contact;
  $("outcome").value = polishUndo.outcome;
  polishUndo = null; renderPolishUndo(false);
  autoGenerateTitle(); update();
  showToast("AI Polish undone - your text is back", "slate");
}

async function aiPolish() {
  if (!featureOn("polish")) return;
  const problem = getVal("problem");
  const workflow = getVal("workflow");
  const nextSteps = getVal("nextSteps");
  if (!problem && !workflow && !nextSteps) {
    showToast("Enter Problem, Troubleshooting, or Next Steps to polish", "red");
    return;
  }
  const btn = $("btn-polish");
  const original = btn.innerHTML;
  btn.innerHTML = '<span class="spinner"></span> Working...';
  btn.disabled = true;
  btn.setAttribute("aria-busy", "true");
  document.body.classList.add("ai-busy");   // themes may animate "thinking"
  startAiScan();
  let polished = false;
  try {
    const payload = {
      problem, workflow,
      next_steps: nextSteps,
      status: normalizeResolutionStatus($("resStatus").value),
      outcome: getVal("outcome"),
      errors: getVal("errorInfo"),
      device: getVal("deviceType"),
      serial: getVal("serialNumber"),
      contact: getVal("contact"),
    };
    const data = await api("POST", "/api/polish", payload);
    const r = data.result || {};
    // Keep what was there, so one click puts it back.
    polishUndo = { problem, workflow, nextSteps, contact: getVal("contact"), outcome: getVal("outcome") };
    const skip = new Set((r.warnings || []).map((w) => w.field));   // the server kept the original
    if (r.problem && !skip.has("problem")) $("problem").value = r.problem;
    if (r.contact) $("contact").value = r.contact;
    if (r.workflow && !skip.has("workflow")) $("workflow").value = r.workflow;
    if (r.next_steps && !skip.has("next_steps")) $("nextSteps").value = r.next_steps;
    if (r.resolution) $("outcome").value = r.resolution;
    // Title is auto-generated (device - problem - serial); regenerate from the
    // polished problem rather than letting the model set it.
    autoGenerateTitle();
    update();
    const kept = (r.warnings || []).map((w) => ({ workflow: "Troubleshooting", next_steps: "Next Steps", problem: "Problem" }[w.field] || w.field));
    showToast(kept.length ? `AI Polish applied - but it would have dropped detail from ${kept.join(" and ")}, so your original was kept`
                          : "AI Polish applied", kept.length ? "amber" : "green");
    renderPolishUndo(true);
    polished = true;
    document.body.classList.add("ai-done");
    setTimeout(() => document.body.classList.remove("ai-done"), 1000);
  } catch (err) {
    showToast(err.message, "red");
  } finally {
    btn.innerHTML = original;
    btn.disabled = false;
    btn.removeAttribute("aria-busy");
    document.body.classList.remove("ai-busy");
    stopAiScan(polished);
  }
}

/* ---- generator: save + clear -------------------------------------------- */
// A real case number has been assigned in D365 - anything but blank / the
// seeded "CAS" placeholder counts.
function hasCaseNumber() {
  const v = getVal("caseNumber");
  return !!v && v.toUpperCase() !== "CAS";
}

// Default: insert a new ticket and reset. While editing a saved ticket, save
// updates it in place; asNew=true forks the current fields into a fresh row.
// A Case ID is required before saving so cases get created in D365 up front;
// bypass=true (Shift+Click the Save button) skips that gate.
async function saveTicket(asNew = false, bypass = false) {
  if (!bypass && !hasCaseNumber()) {
    showToast("Enter a Case ID before saving", "red");
    const el = $("caseNumber");
    if (el) { el.focus(); el.select(); }
    return;
  }
  if (!bypass) {
    const missing = missingRequired();
    if (missing.length) { reportMissingRequired(missing); return; }
    const unlisted = await unlistedFields();
    if (unlisted.length) { reportUnlisted(unlisted); return; }
  }
  try {
    const ticket = collectTicket();
    // Auto-register any values the user typed straight into the ticket fields.
    if (ticket.contact_type === "Dealer") await autoRegister("dealers", ticket.dealer_name);
    for (const key of FREE_LISTS) await autoRegister(key, ticket[ENV_COMBOS[key][1]]);

    if (editing && !asNew) {
      // Finishing an edit: update in place, close the session, return to the
      // repository so the refreshed row is immediately visible.
      const label = editing.label;
      await api("PUT", `/api/tickets/${editing.id}`, ticket);
      // Photos added while editing went straight onto this ticket.
      resetFields();
      switchPage("database");
      showToast(`Ticket ${label} updated`, "green");
    } else if (editing && asNew) {
      const saved = await api("POST", "/api/tickets", ticket);
      // The copy carries the original's photos; the original keeps its own.
      if (photos.length) {
        await api("POST", "/api/photos/copy", { from: editing.id, to: saved.ticket.id });
      }
      resetFields();
      switchPage("database");
      showToast("Saved as a new ticket", "green");
    } else {
      const saved = await api("POST", "/api/tickets", ticket);
      const n = photos.length ? (await api("POST", "/api/photos/claim",
        { ticket_id: saved.ticket.id })).claimed : 0;
      photos = [];
      resetFields();
      loadPhotos();
      showToast(n ? `Saved to database with ${n} photo${n === 1 ? "" : "s"}` : "Saved to database", "green");
    }
  } catch (err) {
    showToast(err.message, "red");
  }
}

// Reset every generator field back to its default (no confirmation, no toast).
function resetFields() {
  document.querySelectorAll(".form-panel input:not([type=radio]):not([type=checkbox]), .form-panel textarea")
    .forEach((el) => { if (el.id !== "dateTime" && el.id !== "caseNumber") el.value = ""; });
  $("caseNumber").value = "CAS";
  $("contactType").value = "End User";
  $("resStatus").value = "Resolved";
  setOs("Windows");
  document.body.dataset.fiMore = ""; fiFolded = {};
  polishUndo = null; renderPolishUndo(false);
  // Back to the standing rotation - clearing the form ends any edit session,
  // including one that had borrowed the other rotation.
  setCallType(standingCallType, false);
  repeatDismissedDigits = "";
  incomingFilledDigits = "";
  incomingTypeFromSkill = false;
  knownCallerFill = null;
  contactTypePicked = false;
  clearRepeatCaller();
  setEditing(null);
  // Before refreshTimestamp, so its saveFormState persists the zeroed clock.
  resetFiTimer();
  refreshTimestamp(false);
  update();
  // A caller who rang in while the last note was still open is usually the
  // one on the line now that it has been saved or cleared.
  takePendingIncoming();
}

async function clearFields() {
  const ok = await confirmModal(
    "Reset all fields?",
    "This clears the current service entry. This cannot be undone.",
    "Yes, clear"
  );
  if (!ok) return;
  const hadEdit = !!editing;
  resetFields();
  // Unsaved photos go with the rest of the form. A saved ticket's stay put.
  if (!hadEdit) await discardDraftPhotos();
  showToast("All fields reset", "slate");
}

/* ---- database page (sortable / filterable table) ------------------------ */
let ticketsCache = [];
let ticketSort = { key: "created_at", dir: "desc" };

// A filter made of nothing but phone characters (3+ digits) is treated as a
// phone lookup as well as plain text. The digit floor keeps a short numeric
// query - a partial case number, say - from matching every stored number.
const PHONE_QUERY_RE = /^(?=(?:\D*\d){3})[\d\s()+.\-]+$/;

// Resolved = green, Awaiting = amber, Escalated = red: scan the table at a glance.
function statusBadge(status) {
  const normalized = normalizeResolutionStatus(status);
  let kind = "amber";
  if (normalized === "Resolved") kind = "green";
  else if (normalized.startsWith("Escalated")) kind = "red";
  return `<span class="badge ${kind}">${escapeHtml(normalized)}</span>`;
}

async function loadTickets() {
  try {
    const data = await api("GET", "/api/tickets");
    ticketsCache = data.tickets || [];
    renderTickets();
  } catch (err) {
    $("ticket-tbody").innerHTML =
      `<tr><td colspan="8" class="table-empty">${escapeHtml(err.message)}</td></tr>`;
  }
}

function ticketTypeLabel(t) {
  return (t.contact_type || "") +
    (t.dealer_name ? " - " + t.dealer_name : "");
}

function renderTickets() {
  const tbody = $("ticket-tbody");
  if (!tbody) return;
  const q = ($("ticket-search").value || "").trim().toLowerCase();
  const statusFilter = $("ticket-status-filter").value;
  const typeFilter = $("ticket-type-filter").value;
  const callFilter = $("ticket-call-filter").value;

  // A query made only of phone characters also matches on digits alone, so
  // "5551234567" finds a number stored as "555-123-4567" (and vice versa).
  const qDigits = PHONE_QUERY_RE.test(q) ? q.replace(/\D/g, "") : "";

  let rows = ticketsCache.filter((t) => {
    if (statusFilter && normalizeResolutionStatus(t.res_status) !== statusFilter) return false;
    if (typeFilter && t.contact_type !== typeFilter) return false;
    if (callFilter === "(untyped)") { if ((t.call_type || "").trim()) return false; }
    else if (callFilter && t.call_type !== callFilter) return false;
    if (!q) return true;
    const hay = [t.case_number, t.case_title, t.call_type, t.contact,
      t.contact_type, t.phone, t.dealer_name,
      normalizeResolutionStatus(t.res_status), t.created_at].join(" ").toLowerCase();
    if (hay.includes(q)) return true;
    return !!qDigits && String(t.phone || "").replace(/\D/g, "").includes(qDigits);
  });

  const { key, dir } = ticketSort;
  const factor = dir === "asc" ? 1 : -1;
  rows.sort((a, b) => {
    let av = a[key], bv = b[key];
    if (key === "contact_type") { av = ticketTypeLabel(a); bv = ticketTypeLabel(b); }
    av = (av == null ? "" : String(av)).toLowerCase();
    bv = (bv == null ? "" : String(bv)).toLowerCase();
    if (av < bv) return -1 * factor;
    if (av > bv) return 1 * factor;
    return (a.id - b.id) * factor;
  });

  // Header sort indicators.
  document.querySelectorAll("#ticket-table thead th[data-sort]").forEach((th) => {
    const active = th.dataset.sort === key;
    th.classList.toggle("sorted", active);
    th.querySelector(".sort-arrow")?.remove();
    if (active) {
      const span = document.createElement("span");
      span.className = "sort-arrow";
      span.textContent = dir === "asc" ? "▲" : "▼";
      th.appendChild(span);
    }
  });

  $("ticket-count").textContent =
    `${rows.length} of ${ticketsCache.length} ticket${ticketsCache.length === 1 ? "" : "s"}`;

  if (!rows.length) {
    const msg = ticketsCache.length
      ? "No tickets match the current filters."
      : "No saved tickets yet. Use Save to Database on the Note Generator.";
    tbody.innerHTML = `<tr><td colspan="8" class="table-empty">${msg}</td></tr>`;
    return;
  }

  tbody.innerHTML = rows.map((t) => `
    <tr data-id="${t.id}" title="Click to preview the saved note">
      <td class="cell-date">${escapeHtml(localDateTime(t.created_at))}</td>
      <td>${escapeHtml(t.case_number || "")}</td>
      <td class="cell-title" title="${escapeHtml(t.case_title || "")}">${t.photo_count
        ? `<span class="photo-badge" title="${t.photo_count} photo${t.photo_count === 1 ? "" : "s"}">${CAMERA_SVG}${t.photo_count}</span>` : ""}${escapeHtml(t.case_title || "")}</td>
      <td>${escapeHtml(t.contact || "")}</td>
      <td class="cell-phone">${escapeHtml(t.phone || "")}</td>
      <td>${escapeHtml(ticketTypeLabel(t))}</td>
      <td>${statusBadge(t.res_status)}</td>
      <td>
        <div class="row-actions">
          <button class="btn small indigo" data-load="${t.id}">Open</button>
          <button class="btn small" data-copy="${t.id}">Copy</button>
          <button class="icon-btn" data-del="${t.id}" title="Delete">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
          </button>
        </div>
      </td>
    </tr>`).join("");
}

function sortTicketsBy(key) {
  if (ticketSort.key === key) {
    ticketSort.dir = ticketSort.dir === "asc" ? "desc" : "asc";
  } else {
    ticketSort.key = key;
    // Dates default to newest-first; text columns default A->Z.
    ticketSort.dir = key === "created_at" ? "desc" : "asc";
  }
  renderTickets();
}

async function openTicket(id) {
  try {
    const data = await api("GET", `/api/tickets/${id}`);
    // Don't silently clobber an in-progress draft (unless it IS this ticket).
    if (isFormDirty() && !(editing && editing.id === data.ticket.id)) {
      const ok = await confirmModal(
        "Load this ticket?",
        "The generator holds unsaved content that will be replaced.",
        "Load"
      );
      if (!ok) return;
    }
    if (!editing && photos.length) await discardDraftPhotos();
    closeNoteModal();
    loadTicketIntoForm(data.ticket);
    startEditing(data.ticket);
    saveFormState();
    switchPage("generator");
    showToast(`Editing ticket ${editing.label}`, "indigo");
  } catch (err) { showToast(err.message, "red"); }
}

/* ---- database page: note preview modal ----------------------------------- */
let noteModalTicket = null;

async function viewTicket(id) {
  try {
    const data = await api("GET", `/api/tickets/${id}`);
    noteModalTicket = data.ticket;
    $("note-modal-title").textContent =
      data.ticket.case_title || data.ticket.case_number || `Ticket #${id}`;
    $("note-modal-body").textContent =
      data.ticket.note_text || "(no note text was saved with this ticket)";
    $("note-modal").classList.remove("hidden");
  } catch (err) { showToast(err.message, "red"); }
}

function closeNoteModal() {
  const modal = $("note-modal");
  if (modal) modal.classList.add("hidden");
  noteModalTicket = null;
}

async function copyTicketNote(id) {
  try {
    const data = await api("GET", `/api/tickets/${id}`);
    copyText(noteForClipboard(data.ticket.note_text || ""), "Note copied!");
  } catch (err) { showToast(err.message, "red"); }
}

async function deleteTicket(id) {
  const ok = await confirmModal("Delete this ticket?", "It will be permanently removed from the database.", "Delete");
  if (!ok) return;
  try {
    await api("DELETE", `/api/tickets/${id}`);
    if (editing && editing.id === Number(id)) setEditing(null);
    showToast("Ticket deleted", "slate");
    loadTickets();
  } catch (err) { showToast(err.message, "red"); }
}

/* ---- dashboard / insights ----------------------------------------------- */
// All figures come from /api/stats (computed in SQL from saved tickets).
// The payload carries every tile window at once, so switching range is a
// re-render of numbers already in hand rather than another request.
let statsCache = null;

const TILE_RANGE_KEY = "tickassist_tile_range_v1";
const TILE_RANGE_LABELS = {
  "1d": "today", "7d": "the last 7 days", "30d": "the last 30 days",
  all: "all time",
};
let tileRange = "all";

// Each bar panel carries its own window selector and remembers its own
// choice: what you want to see over a week (today's escalations) is rarely
// what you want to see over a year (which dealers you deal with). The panels
// all read from the same payload, so switching one is a re-render, not a
// request. Keyed by the chart element each control governs.
const PANEL_RENDERERS = {
  "chart-calltypes": (f) => renderBarList("chart-calltypes", f.call_types || [],
    callTypeColor, "No call types recorded yet."),
  "chart-status": (f) => renderBarList("chart-status", f.status || [],
    statusColor, "No tickets yet."),
  "chart-escalations": (f) => renderEscalations(f.escalation_targets || []),
  "chart-devices": (f) => renderBarList("chart-devices", f.device_types || [],
    "brand", "No device types recorded."),
  "chart-dealers": (f) => renderBarList("chart-dealers", f.dealers || [],
    "brand", "No dealers recorded."),
  "chart-contacts": (f) => renderBarList("chart-contacts", f.contact_types || [],
    "brand", "No contact types recorded."),
};
const PANEL_RANGE_KEY = (chart) => `tickassist_range_${chart}`;
const panelRanges = {};

function panelRange(chart) {
  if (panelRanges[chart]) return panelRanges[chart];
  let stored = null;
  try { stored = localStorage.getItem(PANEL_RANGE_KEY(chart)); } catch (e) {}
  panelRanges[chart] = TILE_RANGE_LABELS[stored] ? stored : "all";
  return panelRanges[chart];
}

// Built here rather than in the template so all six stay identical.
function buildPanelRangeControls() {
  document.querySelectorAll(".panel-head[data-ranged]").forEach((head) => {
    const chart = head.dataset.ranged;
    if (head.querySelector(".range-mini")) return;
    const buttons = Object.keys(TILE_RANGE_LABELS).map((key) =>
      `<button type="button" role="radio" data-range="${key}" aria-checked="false"
               title="${escapeHtml(TILE_RANGE_LABELS[key])}">${key === "all" ? "All" : key}</button>`
    ).join("");
    head.insertAdjacentHTML("beforeend",
      `<div class="range-mini" role="radiogroup" data-range-for="${chart}"
            aria-label="Time range for this panel">${buttons}</div>`);
  });
}

function renderRangedPanel(chart) {
  if (!statsCache || !PANEL_RENDERERS[chart]) return;
  const key = panelRange(chart);
  // Without `ranges` (an older server) every panel falls back to the whole
  // payload, which is the all-time view - the same numbers as before.
  const figures = (statsCache.ranges && statsCache.ranges[key]) || statsCache;
  PANEL_RENDERERS[chart](figures);
  document.querySelectorAll(`[data-range-for="${chart}"] button`).forEach((b) =>
    b.setAttribute("aria-checked", String(b.dataset.range === key)));
}

function setPanelRange(chart, key) {
  if (!TILE_RANGE_LABELS[key]) return;
  panelRanges[chart] = key;
  try { localStorage.setItem(PANEL_RANGE_KEY(chart), key); } catch (e) {}
  renderRangedPanel(chart);
}

function renderRangeToggle(available) {
  const bar = $("tile-range-bar");
  if (bar) bar.classList.toggle("hidden", !available);
  document.querySelectorAll("#tile-range .mode-opt").forEach((b) =>
    b.setAttribute("aria-checked", String(b.dataset.range === tileRange)));
}

function setTileRange(key, persist = true) {
  if (!TILE_RANGE_LABELS[key]) return;
  tileRange = key;
  if (persist) {
    try { localStorage.setItem(TILE_RANGE_KEY, key); } catch (e) {}
  }
  if (statsCache) renderStatTiles(statsCache);
}

function initTileRange() {
  let stored = null;
  try { stored = localStorage.getItem(TILE_RANGE_KEY); } catch (e) {}
  if (TILE_RANGE_LABELS[stored]) tileRange = stored;
}

async function loadDashboard() {
  try {
    renderDashboard(await api("GET", "/api/stats"));
  } catch (err) {
    showToast(err.message, "red");
  }
}

function renderDashboard(s) {
  statsCache = s;
  const empty = $("dash-empty");
  const content = $("dash-content");
  const hasData = s && s.total > 0;
  if (empty) empty.classList.toggle("hidden", hasData);
  if (content) content.classList.toggle("hidden", !hasData);
  if (!hasData) return;

  renderStatTiles(s);
  // These two keep fixed spans: the column chart states its own in the title,
  // and a day-of-week pattern needs several weeks before it means anything.
  renderDailyChart("chart-daily", s.daily || []);
  renderWeekdayProse(s.weekdays || []);
  // The rest each honour their own remembered window.
  Object.keys(PANEL_RENDERERS).forEach(renderRangedPanel);
}

function statTile(value, label, sub, accent) {
  return `<div class="stat-tile accent-${accent}">
      <div class="stat-value">${escapeHtml(String(value))}</div>
      <div class="stat-label">${escapeHtml(label)}</div>
      <div class="stat-sub">${escapeHtml(sub)}</div>
    </div>`;
}

// Tiles read whichever window the range toggle holds. A server that does not
// ship `ranges` still gets correct all-time tiles - the toggle just stays
// hidden rather than offering a choice it cannot honour.
function renderStatTiles(s) {
  const el = $("stat-tiles");
  if (!el) return;
  const windows = s.ranges || null;
  renderRangeToggle(!!windows);
  const f = (windows && windows[tileRange]) || {
    total: s.total, resolved: s.resolved, escalated: s.escalated,
    resolution_rate: s.resolution_rate, escalation_rate: s.escalation_rate,
    active_days: s.active_days, avg_per_active_day: s.avg_per_active_day,
    busiest: s.busiest || { date: "", count: 0 },
  };
  const span = windows ? TILE_RANGE_LABELS[tileRange] : "all time";
  const days = f.active_days || 0;

  el.innerHTML = [
    statTile(f.total, "Tickets", span, "brand"),
    statTile(f.resolution_rate + "%", "Resolution rate",
      `${f.resolved} of ${f.total} resolved in-house`, "green"),
    statTile(f.escalation_rate + "%", "Escalated onward",
      `${f.escalated} routed to the right team`, "slate"),
    statTile(f.avg_per_active_day ?? 0, "Per working day",
      `average across ${days} day${days === 1 ? "" : "s"} worked`, "brand"),
    statTile((f.busiest && f.busiest.count) || 0, "Busiest day",
      f.busiest && f.busiest.date ? fmtDayLabel(f.busiest.date) : "no activity yet",
      "slate"),
  ].join("");
}

// Where escalations go, each bar colour-coded by the rotation the escalation
// came from. Bar length is still the total, so the ranking reads as before -
// the colour split is what shows that the two rotations send work to quite
// different places rather than escalating alike.
function renderEscalations(targets) {
  const rows = (targets || []).map((t) => ({
    name: t.name,
    count: t.count,
    parts: [
      { cls: "call-first", count: t.first_impressions || 0, label: FIRST_IMPRESSIONS },
      { cls: "call-trouble", count: t.troubleshooting || 0, label: TROUBLESHOOTING },
      // Anything saved before the rotations existed still has to be drawn.
      { cls: "untyped",
        count: Math.max(0, t.count - (t.first_impressions || 0) - (t.troubleshooting || 0)),
        label: "Untyped" },
    ].filter((p) => p.count > 0),
  }));
  renderBarList("chart-escalations", rows, "brand",
    "No escalations — everything stayed in-house.");
  if (rows.length) {
    $("chart-escalations").insertAdjacentHTML("beforeend",
      `<div class="legend">
        <span class="legend-item"><span class="legend-swatch call-first"></span>${escapeHtml(FIRST_IMPRESSIONS)}</span>
        <span class="legend-item"><span class="legend-swatch call-trouble"></span>${escapeHtml(TROUBLESHOOTING)}</span>
      </div>`);
  }
}

// Fixed hue per rotation - the colour follows the call type itself, never its
// position in the list, so a filtered or reordered chart never repaints it.
function callTypeColor(name) {
  if (canonicalCallType(name) === FIRST_IMPRESSIONS) return "call-first";
  if (name === TROUBLESHOOTING) return "call-trouble";
  return "untyped";
}

const WEEKDAY_FULL = {
  Mon: "Monday", Tue: "Tuesday", Wed: "Wednesday", Thu: "Thursday",
  Fri: "Friday", Sat: "Saturday", Sun: "Sunday",
};

// Day-of-week intensity, written out rather than plotted. It is a handful of
// numbers whose point is the comparison between them, and a sentence carries
// that faster than five bars. The average is per day that weekday was actually
// worked - Wednesday coming round more often than Friday is a fact about the
// calendar, not about how heavy a Wednesday is.
//
// Ordered by the WEIGHTED score, not raw volume: a First Impressions day is
// high count by nature, so volume alone would always crown the intake rotation
// and say nothing about how hard the day was. What each line prints, though,
// is the real call count, with the score in brackets after it - the score is
// the ordering key, not a quantity of anything.
function renderWeekdayProse(weekdays) {
  const el = $("weekday-prose");
  if (!el) return;
  if (!weekdays.length) {
    el.innerHTML = `<p>No activity recorded yet.</p>`;
    return;
  }
  // The weighted figures come from the server. If they are missing - an older
  // build still serving /api/stats - fall back to plain call volume and drop
  // the weighting language, rather than rendering NaN over the whole panel.
  const weighted = weekdays.every((w) => Number.isFinite(w.load_avg));
  const rank = (w) => (weighted ? w.load_avg : w.avg);

  const ranked = [...weekdays].sort((a, b) => rank(b) - rank(a));
  const name = (w) => `<strong>${escapeHtml(WEEKDAY_FULL[w.name] || w.name)}</strong>`;
  const calls = (w) => `<span class="num">~${Math.round(w.avg)}</span>`;

  // Calls lead, the weighted score follows in brackets: the call count is the
  // thing that happened, the score is what orders the list. Calls stay whole -
  // you cannot take a third of a call - while the score carries two decimals,
  // because it is an index, not a tally, and its fractional part is often the
  // only thing separating two days.
  const score = (w) => (weighted
    ? ` (weighted score: <span class="num">${Number(rank(w)).toFixed(2)}</span>)` : "");
  const perDay = (w) =>
    `${calls(w)} ${Math.round(w.avg) === 1 ? "call" : "calls"} per day${score(w)}`;

  const lines = [];
  const top = ranked[0];
  lines.push(`<p class="lead">Your most intense day of the week tends to be ` +
    `${name(top)}, with ${perDay(top)}.</p>`);

  ranked.slice(1, -1).forEach((w) => {
    lines.push(`<p>${name(w)} averages ${perDay(w)}.</p>`);
  });

  if (ranked.length > 1) {
    const low = ranked[ranked.length - 1];
    lines.push(`<p>${name(low)} is your lightest, with ${perDay(low)}.</p>`);
  }

  // Where the weighting actually changes the answer, say so - otherwise the
  // reader has no way to tell that the ranking is not just volume.
  const byVolume = [...weekdays].sort((a, b) => b.avg - a.avg)[0];
  if (weighted && byVolume.name !== top.name) {
    lines.push(`<p>By raw call count ${name(byVolume)} would lead instead ` +
      `(${calls(byVolume)} a day against ${name(top)}&rsquo;s ${calls(top)}) ` +
      `&mdash; ${name(top)} comes out ahead once troubleshooting is weighted.</p>`);
  }

  const totalDays = weekdays.reduce((sum, w) => sum + w.days, 0);
  const totalCalls = weekdays.reduce((sum, w) => sum + w.count, 0);
  lines.push(`<p>That is <span class="num">${totalCalls}</span> ` +
    `${totalCalls === 1 ? "note" : "notes"} across ` +
    `<span class="num">${totalDays}</span> worked ` +
    `${totalDays === 1 ? "day" : "days"}.</p>`);

  el.innerHTML = lines.join("");
}

// Statuses are outcome categories, not a severity scale - an escalation is a
// correct routing decision, never a failure. So: green = closed in-house,
// amber = pending on the customer, brand blue = correctly routed onward.
// Nothing is red; the label always names the category, so colour never stands
// alone.
function statusColor(name) {
  if (name === "Resolved") return "green";
  if (name === "Awaiting Information") return "amber";
  return "brand"; // any "Escalated ..." status - routed onward, not a problem
}

// rows: [{name, count}]. color is a "brand"/"green"/... string or a fn(name).
function renderBarList(containerId, rows, color, emptyMsg) {
  const el = $(containerId);
  if (!el) return;
  if (!rows.length) {
    el.innerHTML = `<div class="chart-empty">${escapeHtml(emptyMsg)}</div>`;
    return;
  }
  const max = Math.max(...rows.map((r) => r.count), 1);
  el.innerHTML = '<div class="bars">' + rows.map((r) => {
    const pct = Math.round((r.count / max) * 100);
    const cls = typeof color === "function" ? color(r.name) : color;
    // `display` / `hint` let a row print something other than its raw count
    // (an average, say) while the bar still scales on the numeric value.
    const shown = r.display === undefined ? r.count : r.display;
    // `parts` splits one row into several fills laid end to end. Each segment
    // is sized against the same max as a whole bar would be, so a split row
    // still spans exactly as far as its total earns.
    const fills = (r.parts && r.parts.length)
      ? r.parts.map((p) =>
          `<span class="bar-fill ${p.cls}" style="width:${(p.count / max) * 100}%"></span>`).join("")
      : `<span class="bar-fill ${cls}" style="width:${pct}%"></span>`;
    const breakdown = (r.parts && r.parts.length > 1)
      ? " - " + r.parts.map((p) => `${p.count} ${p.label}`).join(", ")
      : "";
    const hint = r.hint || `${r.name}: ${r.count}${breakdown}`;
    return `<div class="bar-row" title="${escapeHtml(hint)}">
        <span class="bar-label">${escapeHtml(r.name)}</span>
        <span class="bar-track">${fills}</span>
        <span class="bar-val">${escapeHtml(String(shown))}</span>
      </div>`;
  }).join("") + "</div>";
}

// One column per day, each split into its rotations. Column height is the
// day's total, so the trend still reads at a glance; the segments answer what
// the day was made of. Weekends are banded whether or not they hold anything.
function renderDailyChart(containerId, daily) {
  const el = $(containerId);
  if (!el) return;
  if (!daily.length) { el.innerHTML = `<div class="chart-empty">No activity.</div>`; return; }
  const max = Math.max(...daily.map((d) => d.count || 0), 1);

  const SERIES = [
    // Bottom-up. Fixed order, so a segment never changes place day to day.
    { key: "troubleshooting", cls: "call-trouble", label: TROUBLESHOOTING },
    { key: "first_impression", cls: "call-first", label: FIRST_IMPRESSIONS },
  ];

  const cells = daily.map((d) => {
    const total = d.count || 0;
    const parts = SERIES.map((s) => ({ ...s, n: d[s.key] || 0 }));
    // Anything saved before the rotations existed still has to add up.
    const untyped = Math.max(0, total - parts.reduce((sum, p) => sum + p.n, 0));
    if (untyped) parts.push({ key: "untyped", cls: "untyped", label: "Untyped", n: untyped });

    const segs = parts.filter((p) => p.n > 0).map((p) =>
      `<span class="seg ${p.cls}" style="height:${(p.n / total) * 100}%"></span>`
    ).join("");

    const label = fmtDayLabel(d.date);
    const breakdown = parts.filter((p) => p.n > 0)
      .map((p) => `${p.n} ${p.label}`).join(", ");
    const weekend = isWeekend(d.date);
    const hint = total
      ? `${label}: ${total} ${total === 1 ? "ticket" : "tickets"}${breakdown ? " - " + breakdown : ""}`
      : `${label}: none${weekend ? " (weekend)" : ""}`;

    return `<span class="day ${weekend ? "weekend" : ""}" title="${escapeHtml(hint)}">
        <span class="col ${total ? "" : "zero"}" style="height:${Math.round((total / max) * 100)}%">${segs}</span>
      </span>`;
  }).join("");

  const at = (i) => fmtDayLabel(daily[i].date);
  const legend = [
    `<span class="legend-item"><span class="legend-swatch call-first"></span>${escapeHtml(FIRST_IMPRESSIONS)}</span>`,
    `<span class="legend-item"><span class="legend-swatch call-trouble"></span>${escapeHtml(TROUBLESHOOTING)}</span>`,
    `<span class="legend-item"><span class="legend-swatch weekend"></span>Weekend</span>`,
  ].join("");

  el.innerHTML = `<div class="col-chart">${cells}</div>
    <div class="col-axis"><span>${at(0)}</span><span>${at(Math.floor(daily.length / 2))}</span><span>${at(daily.length - 1)}</span></div>
    <div class="legend">${legend}</div>`;
}

// "YYYY-MM-DD" -> true for Saturday / Sunday, parsed as a local date.
function isWeekend(iso) {
  const p = (iso || "").split("-");
  if (p.length !== 3) return false;
  const day = new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2])).getDay();
  return day === 0 || day === 6;
}

// "YYYY-MM-DD" -> "Aug 3", parsed as a local date (no UTC shift).
function fmtDayLabel(iso) {
  const p = (iso || "").split("-");
  if (p.length !== 3) return iso || "";
  const d = new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
  return isNaN(d) ? iso : d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

/* ---- settings: merge an older database ---------------------------------- */
// Two steps on purpose. Check reads the source and reports what it found;
// only then does a Merge button appear. The server snapshots the live database
// before writing, so a surprising result is always recoverable.
function renderMergeResult(html, kind) {
  const el = $("merge-result");
  if (!el) return;
  el.className = "merge-result" + (kind ? " " + kind : "");
  el.innerHTML = html;
}

// The database picked in the dialog, held so the merge step can send the same
// bytes without a second trip through the file dialog.
let mergeFile = null;

// A folder picker hands over every file under it; only one of these is the
// database, and it is found without reading any of the others.
const MERGE_FILENAMES = ["tickassist.db", "detailed_log.db"];

function setMergeFile(file, label) {
  mergeFile = file;
  const el = $("merge-picked");
  if (el) el.textContent = file ? (label || file.name) : "";
  if (file) $("merge-path").value = "";
}

// Sends the picked database to the local server, which merges from a temp copy.
async function postMergeFile(apply) {
  const q = `?name=${encodeURIComponent(mergeFile.name)}&apply=${apply ? 1 : 0}`;
  const resp = await fetch(`/api/merge/upload${q}`, {
    method: "POST",
    headers: { "Content-Type": "application/octet-stream" },
    body: await mergeFile.arrayBuffer(),
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(data.error || `Upload failed (${resp.status})`);
  return data;
}

async function checkMerge() {
  const path = getVal("merge-path");
  if (!path && !mergeFile) {
    return renderMergeResult("Choose a database first.", "error");
  }
  renderMergeResult("Reading&hellip;");
  try {
    const r = mergeFile ? await postMergeFile(false)
                        : await api("POST", "/api/merge", { path, apply: false });
    const span = r.earliest
      ? ` spanning <strong>${escapeHtml(r.earliest)}</strong> to <strong>${escapeHtml(r.latest)}</strong>`
      : "";
    if (r.anything === false || (r.anything === undefined && !r.new)) {
      renderMergeResult(
        `Found <strong>${r.total}</strong> ${r.total === 1 ? "ticket" : "tickets"} in that ` +
        `${escapeHtml(r.kind)} database, and everything in it is already here. Nothing to merge.` +
        `<span class="merge-source">${escapeHtml(r.source)}</span>`);
      return;
    }
    const extra = mergeExtras(r);
    renderMergeResult(
      (r.new
        ? `<strong>${r.new}</strong> new ${r.new === 1 ? "ticket" : "tickets"}${span} ` +
          `to bring in from that ${escapeHtml(r.kind)} database` +
          (r.duplicates ? `, and <strong>${r.duplicates}</strong> already here that will be skipped` : "") + "."
        : `All <strong>${r.total}</strong> tickets in that ${escapeHtml(r.kind)} database are already here, but it has more to bring in.`) +
      (extra.length ? `<ul class="merge-extra">${extra.map((t) => `<li>${t}</li>`).join("")}</ul>` : "") +
      `<span class="merge-source">${escapeHtml(r.source)}</span>` +
      `<div class="btn-row"><button class="btn green" id="btn-merge-apply">Merge</button></div>`);
  } catch (err) {
    renderMergeResult(escapeHtml(err.message), "error");
  }
}

const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const MERGE_LIST_NAMES = { dealers: ["dealer", "dealers"], device_types: ["device type", "device types"],
                           reco_units: ["Reco unit", "Reco units"],
                           os_versions: ["OS version", "OS versions"], device_firmware: ["firmware value", "firmware values"],
                           device_tool_versions: ["device tool version", "device tool versions"],
                           didapi_versions: ["DIDAPI version", "DIDAPI versions"],
                           romexis_versions: ["Romexis version", "Romexis versions"],
                           imaging_packages: ["imaging package", "imaging packages"],
                           reco_os: ["Reco OS", "Reco OS values"], reco_firmware: ["Reco firmware", "Reco firmware values"] };

// The non-ticket parts of a merge preview, as list items.
function mergeExtras(r) {
  const out = [];
  if (r.photos) {
    out.push(`<strong>${plural(r.photos, "photo", "photos")}</strong> with ${r.photos === 1 ? "its ticket" : "their tickets"}` +
      (r.photos_skipped ? ` (${r.photos_skipped} already here, skipped)` : ""));
  }
  for (const [key, n] of Object.entries(r.lists || {})) {
    const [one, many] = MERGE_LIST_NAMES[key] || [key, key];
    out.push(`<strong>${plural(n, "new " + one, "new " + many)}</strong>`);
  }
  if (r.macros) out.push(`<strong>${plural(r.macros, "new macro", "new macros")}</strong>`);
  if (r.macros_kept) out.push(`${plural(r.macros_kept, "macro", "macros")} with the same trigger here kept as yours`);
  return out;
}

async function applyMerge() {
  const path = getVal("merge-path");
  if (!path && !mergeFile) return;
  const ok = await confirmModal(
    "Merge this database in?",
    "Its tickets, photos, lists and macros will be added to this database. A snapshot of the current database is saved first, so this can be undone by restoring it.",
    "Merge"
  );
  if (!ok) return;
  renderMergeResult("Merging&hellip;");
  try {
    const r = mergeFile ? await postMergeFile(true)
                        : await api("POST", "/api/merge", { path, apply: true });
    const extra = mergeExtras(r);
    renderMergeResult(
      `Merged <strong>${r.added}</strong> ${r.added === 1 ? "ticket" : "tickets"}` +
      (r.duplicates ? `, skipped <strong>${r.duplicates}</strong> already here` : "") + "." +
      (extra.length ? `<ul class="merge-extra">${extra.map((t) => `<li>${t}</li>`).join("")}</ul>` : "") +
      `<span class="merge-source">Snapshot of the previous database: ${escapeHtml(r.backup)}</span>`,
      "done");
    showToast(`Merged ${plural(r.added, "ticket", "tickets")}` +
              (r.photos ? ` and ${plural(r.photos, "photo", "photos")}` : ""), "green");
    loadTickets();
    if (typeof loadMacros === "function") loadMacros();
    document.querySelectorAll("[data-list-addbtn]").forEach((b) => {
      if (typeof loadList === "function") loadList(b.dataset.listAddbtn);
    });
  } catch (err) {
    renderMergeResult(escapeHtml(err.message), "error");
  }
}

/* ---- settings page ------------------------------------------------------ */
const MODEL_HINTS = {
  gemini: "Suggested: gemini-2.5-flash. Get a key at aistudio.google.com.",
  anthropic: "Suggested: claude-haiku-4-5-20251001. Get a key at console.anthropic.com.",
};

// The last /api/settings answer. The integration drawers fill from it when
// they open, and the status tiles and Connections list read it.
let settingsCache = null;

// Each integration drawer fills its own fields. A drawer with edits not yet
// saved is left alone, so a background reload never wipes what is being typed.
const DRAWER_FILLERS = {
  calls: (s) => {
    $("cw-enabled").checked = !!s.call_watch_enabled;
    $("cw-match").value = s.call_watch_match || "";
    $("cw-ignore").value = s.call_watch_ignore || "";
    $("cw-rules").value = s.call_watch_rules || "";
  },
  sheet: (s) => {
    renderSheetSources(s.sheet_sources || []);
    $("sheet-check-on").checked = s.sheet_check !== false;
  },
  d365: (s) => loadD365Settings(s),
  transfer: (s) => { $("tr-url").value = s.transfer_url || ""; },
};

function fillDrawers(s) {
  for (const [name, fill] of Object.entries(DRAWER_FILLERS)) {
    if (!drawerDirty(name)) fill(s);
  }
}

async function loadSettings() {
  try {
    const s = await api("GET", "/api/settings");
    settingsCache = s;
    document.body.dataset.edition = s.edition || "full";
    const updUrl = $("upd-url");
    if (updUrl && document.activeElement !== updUrl) updUrl.value = s.update_url || "";
    if ($("upd-version")) $("upd-version").textContent = `Version ${s.version || ""}${s.edition === "lite" ? " (Lite)" : ""}`;
    if (!updateChecked && s.update_url) { updateChecked = true; checkUpdates(true); }
    $("llm-provider").value = s.llm_provider || "gemini";
    $("llm-model").value = s.llm_model || "";
    $("llm-key").value = s.llm_api_key || "";
    $("key-status").textContent = s.api_key_set ? "A key is currently saved." : "No key saved yet.";
    $("model-help").textContent = MODEL_HINTS[s.llm_provider] || "";
    fillDrawers(s);
    reqRulesDraft = null;
    renderReqPanel();
    applyRequiredMarks();
    renderCallWatchStatus(s.call_watch);
    setD365State(s.d365);
    renderIntegrations();
    return s;
  } catch (err) { showToast(err.message, "red"); return null; }
}

// AI Polish only. Every integration drawer saves its own fields, so saving
// one panel can never also commit half-finished edits sitting in another.
async function saveSettings() {
  try {
    await api("POST", "/api/settings", {
      llm_provider: $("llm-provider").value,
      llm_model: $("llm-model").value.trim(),
      llm_api_key: $("llm-key").value,
    });
    showToast("Settings saved", "green");
    loadSettings();
  } catch (err) { showToast(err.message, "red"); }
}

async function saveSheetSettings() {
  try {
    await api("POST", "/api/settings", {
      sheet_sources: collectSheetSources(),
      sheet_check: $("sheet-check-on").checked,
    });
    // A new link or mapping deserves a fresh look at what is in the note.
    sheetLast = {};
    sheetHealth = null;
    markDrawerClean("sheet");
    showToast("Google Sheets saved", "green");
    loadSettings();
  } catch (err) { showToast(err.message, "red"); }
}

/* ---- incoming calls (CXone MAX) ------------------------------------------ */
// The server reads the caller's number off the MAX window / its notifications
// (callwatch.py) or receives it from a screen pop, and this long-polls for it.
// A pending fetch is not subject to background-tab timer throttling, so the
// number lands even while TickAssist sits behind MAX.
//
// Rule: it fills Phone Number only when that field is empty and no saved
// ticket is open. Otherwise the number is offered in a line under the field -
// a call ringing in must never overwrite the note still being written.
let incomingSeq = null;
let incomingPending = null; // { phone, digits, contactType } offered but not yet used
// The number this page itself put in Phone Number, so a caller type that MAX
// draws a moment after the number can still be applied to the same call -
// and never to a number the user typed.
let incomingFilledDigits = "";

// Set Contact Type from the call, if the rule named one of the dropdown's own
// options (matched case-insensitively). Fired as input so the Dealer field
// shows or hides and the preview updates exactly as for a manual pick.
// Contact Type came from the call's own skill (current, so it outranks
// whatever the caller was on an earlier ticket).
let incomingTypeFromSkill = false;
// What fillKnownCaller put in, so a later correction can undo just that.
let knownCallerFill = null; // { digits, contact, dealer, type, typeBefore }
// Contact Type was picked by hand on this note. Programmatic changes (a MAX
// skill, a known caller, an import) fire untrusted events and do not count.
let contactTypePicked = false;
const DEFAULT_CONTACT_TYPE = "End User";

// A number already in the database - whether it came in from MAX or was
// typed - brings back who the caller was: their name, their Contact Type and,
// for a dealer, the company, from their most recent ticket that has a name.
// Only into fields still empty: Contact Type counts as empty while it holds the
// default and nobody has picked it, and a skill MAX showed with this call
// outranks history. Never while a saved ticket is open. A typed number must be
// complete (10 digits) first, so a half-typed one cannot fill in a stranger.
function fillKnownCaller(matches, digits) {
  if (!featureOn("known_caller")) return;
  if (editing || !digits) return;
  const fromCall = incomingFilledDigits === digits;
  if (!fromCall && digits.length < 10) return;
  if (knownCallerFill && knownCallerFill.digits === digits) return; // done once
  const last = (matches || []).find((t) => (t.contact || "").trim());
  if (!last) return;
  const filled = [];
  const fill = { digits, contact: "", dealer: "", type: "", typeBefore: "" };

  if (!getVal("contact")) {
    $("contact").value = last.contact.trim();
    fill.contact = $("contact").value;
    filled.push(fill.contact);
  }
  const lastType = (last.contact_type || "").trim();
  const lastDealer = (last.dealer_name || "").trim();
  const sel = $("contactType");
  if (lastType && !contactTypePicked && !(fromCall && incomingTypeFromSkill) &&
      sel.value === DEFAULT_CONTACT_TYPE) {
    const before = sel.value;
    const applied = applyIncomingContactType(lastType);
    if (applied && applied !== before) { fill.type = applied; fill.typeBefore = before; }
  }
  const typeNote = [];
  if (fill.type) typeNote.push(fill.type);
  if (lastDealer && sel.value === "Dealer" && !getVal("dealerName")) {
    $("dealerName").value = lastDealer;
    fill.dealer = lastDealer;
    typeNote.push(lastDealer);
  }
  if (typeNote.length) filled.push(`(${typeNote.join(", ")})`);
  knownCallerFill = fill;
  if (!filled.length) return;
  update();
  const others = [...new Set((matches || []).map((t) => (t.contact || "").trim())
    .filter((n) => n && n.toLowerCase() !== last.contact.trim().toLowerCase()))];
  showToast(`Known caller: ${filled.join(" ")}, filled from their last ticket` +
    (others.length ? ` (this number has also been ${others.join(", ")})` : ""), "indigo");
}

// The number changed (a typo fixed, a different caller, cleared): what the old
// number filled in goes back out - but only fields still holding exactly what
// was filled, so nothing typed since is touched.
function undoKnownCallerFill() {
  const f = knownCallerFill;
  knownCallerFill = null;
  if (!f) return;
  let changed = false;
  if (f.contact && getVal("contact") === f.contact) { $("contact").value = ""; changed = true; }
  if (f.dealer && getVal("dealerName") === f.dealer) { $("dealerName").value = ""; changed = true; }
  if (f.type && !contactTypePicked && $("contactType").value === f.type) {
    $("contactType").value = f.typeBefore || DEFAULT_CONTACT_TYPE;
    changed = true;
  }
  if (changed) update();
}

function applyIncomingContactType(type) {
  const sel = $("contactType");
  if (!sel || !type) return false;
  const opt = [...sel.options].find((o) =>
    o.value.toLowerCase() === String(type).trim().toLowerCase());
  if (!opt) return false;
  if (sel.value !== opt.value) {
    sel.value = opt.value;
    sel.dispatchEvent(new Event("input", { bubbles: true }));
  }
  return opt.value;
}

const INCOMING_SOURCE_LABEL = {
  window: "MAX", toast: "MAX notification", "screen-pop": "CXone screen pop",
  "address-bar": "the call page",
};

function renderIncomingNotice() {
  const el = $("incoming-call");
  if (!el) return;
  const p = incomingPending;
  if (!p || getVal("phone").replace(/\D/g, "").endsWith(p.digits)) {
    incomingPending = null;
    el.classList.add("hidden");
    el.innerHTML = "";
    return;
  }
  el.innerHTML =
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.18 2 2 0 0 1 4.08 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.1 9.9a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>` +
    `<span class="rc-text">Incoming call: <span class="rc-name">${escapeHtml(p.phone)}</span>` +
    ([p.contactType, p.caseNumber].filter(Boolean).length
      ? ` <span class="rc-meta">(${escapeHtml([p.contactType, p.caseNumber].filter(Boolean).join(", "))})</span>` : "") + `</span>` +
    `<button type="button" class="btn-link" data-incoming-use>Use this number</button>` +
    `<button type="button" class="rc-close" data-incoming-dismiss aria-label="Dismiss" title="Dismiss">` +
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>`;
  el.classList.remove("hidden");
}

// Put a number in Phone Number exactly as if it had been typed, so formatting,
// the preview, the repeat-caller line, the timer, and autosave all follow.
// A case number MAX showed with the call (e.g. the Call Triage panel's
// "Inbound Case Reference") goes into Case ID - only while it is still blank,
// so a case number already there is never replaced. Returns what it set.
function applyIncomingCase(caseNumber) {
  const el = $("caseNumber");
  if (!el || !caseNumber || editing) return null;
  if (hasCaseNumber()) {
    if (getVal("caseNumber").toUpperCase() !== caseNumber.toUpperCase()) {
      showToast(`MAX shows case ${caseNumber} - Case ID kept as ${getVal("caseNumber")}`, "slate");
    }
    return null;
  }
  el.value = caseNumber;
  el.dispatchEvent(new Event("input", { bubbles: true }));
  return caseNumber;
}

const withCase = (c) => (c ? `, case ${c}` : "");

function fillIncomingPhone(phone, contactType, caseNumber) {
  const el = $("phone");
  if (!el) return null;
  el.value = phone;
  el.dispatchEvent(new Event("input", { bubbles: true }));
  incomingFilledDigits = phone.replace(/\D/g, "");
  knownCallerFill = null;
  const applied = applyIncomingContactType(contactType);
  incomingTypeFromSkill = !!applied;
  fillIncomingPhone.lastCase = applyIncomingCase(caseNumber);
  incomingPending = null;
  renderIncomingNotice();
  return applied;
}

const withType = (type) => (type ? ` as ${type}` : "");

// Offers older than this are from a call long over; drop rather than fill.
const INCOMING_PENDING_MAX_MS = 10 * 60 * 1000;

function takePendingIncoming() {
  const p = incomingPending;
  if (!p) return;
  if (Date.now() - p.at <= INCOMING_PENDING_MAX_MS && !getVal("phone")) {
    const type = fillIncomingPhone(p.phone, p.contactType, p.caseNumber);
    showToast(`Phone filled with the waiting caller, ${p.phone}${withType(type)}${withCase(fillIncomingPhone.lastCase)}`, "indigo");
  } else {
    incomingPending = null;
    renderIncomingNotice();
  }
}

function handleIncoming(ev) {
  if (!ev || !ev.digits || !featureOn("calls")) return;
  // The Settings > Test call: report that it arrived, fill nothing.
  if (ev.source === "test") {
    if (callTestWaiter) callTestWaiter(ev);
    showCallCard(ev, true);   // LCARS: preview the call card
    return;
  }
  noteTransferCall(ev);       // the call's id, for Transfer call
  updateCallCard(ev);         // a skill / case MAX showed after the number
  if (!featureOn("caller_type")) ev = { ...ev, contact_type: null };
  if (!featureOn("case_from_max")) ev = { ...ev, case_number: null };
  const current = getVal("phone").replace(/\D/g, "");
  if (current.endsWith(ev.digits)) {
    // Same call: a case number MAX has only now shown (the triage panel can
    // load on answer) - only for a number this page filled.
    if (ev.case_number && incomingFilledDigits === ev.digits) {
      const c = applyIncomingCase(ev.case_number);
      if (c) showToast(`Case ID set to ${c} from MAX`, "indigo");
    }
    // Same call. If MAX has only now shown the skill, type the call - but
    // only when this page filled the number, never over a hand-typed one.
    if (ev.contact_type && incomingFilledDigits === ev.digits && !editing) {
      const type = applyIncomingContactType(ev.contact_type);
      if (type) {
        incomingTypeFromSkill = true;
        // A dealer copied from history no longer applies once the call itself
        // says the caller is something else - but only if it is untouched.
        if (type !== "Dealer" && knownCallerFill && knownCallerFill.dealer &&
            getVal("dealerName") === knownCallerFill.dealer) {
          $("dealerName").value = "";
          knownCallerFill.dealer = "";
          update();
        }
        showToast(`Contact Type set to ${type} from MAX`, "indigo");
      }
    }
    return;
  }
  if (incomingPending && incomingPending.digits === ev.digits) {
    // A late caller type for the call already waiting in the offer.
    if (ev.contact_type) incomingPending.contactType = ev.contact_type;
    if (ev.case_number) incomingPending.caseNumber = ev.case_number;
    renderIncomingNotice();
    return;
  }
  if (ev.update) return; // a type for a call that is no longer in play
  const from = INCOMING_SOURCE_LABEL[ev.source] || "MAX";
  showCallCard(ev);           // LCARS only; a no-op on every other theme
  if (!current && !editing) {
    const type = fillIncomingPhone(ev.phone, ev.contact_type, ev.case_number);
    showToast(`Incoming call ${ev.phone}${withType(type)}${withCase(fillIncomingPhone.lastCase)} - filled from ${from}`, "indigo");
  } else {
    incomingPending = { phone: ev.phone, digits: ev.digits, at: Date.now(),
                        contactType: ev.contact_type || null,
                        caseNumber: ev.case_number || null };
    renderIncomingNotice();
    showToast(`Incoming call ${ev.phone} - Phone Number already filled, not replaced`, "slate");
  }
}

async function pollIncoming() {
  for (;;) {
    try {
      const q = incomingSeq === null ? "" : `?since=${incomingSeq}`;
      const data = await api("GET", `/api/incoming${q}`);
      // The first answer only establishes "now": a call that rang before this
      // page opened is not replayed into it.
      if (incomingSeq !== null && data.event) handleIncoming(data.event);
      incomingSeq = data.seq;
      renderCallWatchStatus(data.watch);
    } catch (e) {
      // Server restarting or briefly unreachable: back off, then resume.
      await new Promise((r) => setTimeout(r, 5000));
    }
  }
}

function initIncomingCalls() {
  on("incoming-call", "click", (e) => {
    if (!incomingPending) return;
    if (e.target.closest("[data-incoming-use]")) {
      fillIncomingPhone(incomingPending.phone, incomingPending.contactType,
                        incomingPending.caseNumber);
    }
    else if (e.target.closest("[data-incoming-dismiss]")) {
      incomingPending = null;
      renderIncomingNotice();
    }
  });
  // The offer goes stale once the field holds that number or is cleared and
  // refilled by hand.
  on("phone", "input", renderIncomingNotice);
  on("btn-save-callwatch", "click", saveCallWatch);
  on("btn-cw-refresh", "click", refreshCallWatch);
  on("btn-cw-test", "click", testCallWatch);
  // The long-poll only reports status every 25 s; while Settings or the MAX
  // drawer is open, refresh it often enough to watch it find the MAX window.
  // No ?since=, so this answers at once and never consumes a call.
  setInterval(async () => {
    const settingsOpen = $("page-settings") && $("page-settings").classList.contains("active");
    if (!settingsOpen && openDrawerName !== "calls") return;
    if (!featureOn("calls")) return;
    try { renderCallWatchStatus((await api("GET", "/api/incoming")).watch); } catch (e) {}
  }, 3000);
  const pop = $("cw-pop-url");
  // Show the real port (it moves off 8765 if that one was taken).
  if (pop && /^(localhost|127\.0\.0\.1)$/.test(location.hostname)) pop.textContent = `${location.protocol}//${location.host}/call?phone={ANI}`;
  pollIncoming();
}

// The window reader's last reported status, for the tiles and Connections.
let callWatch = null;

function renderCallWatchStatus(w) {
  if (!w) return;
  callWatch = w;
  renderIntegrations();
  const el = $("cw-status");
  if (!el) return;
  const state = w.state || "off";
  let text = w.message || "";
  if (state === "running" && w.titles && w.titles.length) {
    text += ` Watching: ${w.titles.map((t) => `"${t}"`).join(", ")}.`;
  }
  const lc = w.last_call;
  if (lc && lc.phone) {
    text += lc.contact_type
      ? ` Last call ${lc.phone}: Contact Type ${lc.contact_type}, from "${lc.matched}".`
      : ` Last call ${lc.phone}: no caller-type rule matched` +
        (lc.context && lc.context.length
          ? ` - it came with: ${lc.context.map((t) => `"${t}"`).join(", ")}.`
          : ".");
  }
  if (lc && lc.phone && lc.case_number) text += ` Case ${lc.case_number}.`;
  if (w.ambiguous && w.ambiguous.numbers) {
    text += ` Last skipped (several new numbers at once): ${w.ambiguous.numbers.join(", ")}` +
      ` - add any that are not callers to the list below.`;
  }
  el.textContent = text || "Off.";
  el.dataset.state = state;
  // The reader can see the call page's id right now: use it even if this
  // page missed the moment it appeared (opened or reloaded mid-call).
  if (w.call_page_id && featureOn("calls") &&
      (!transferCall || transferCall.contactId !== w.call_page_id)) {
    const d = String(w.call_page_phone || "");
    noteTransferCall({ contact_id: w.call_page_id, digits: d,
                       phone: d ? `${d.slice(-10, -7)}-${d.slice(-7, -4)}-${d.slice(-4)}` : "" });
  }
  renderCallDiag(w);
}

// What the reader can see right now, plus the result of the last Test.
let callTestLine = "";
let callTestWaiter = null; // resolves when the test call reaches this page

function renderCallDiag(w) {
  const el = $("cw-diag");
  if (!el || !w) return;
  const lines = [];
  if (callTestLine) lines.push(callTestLine);
  let seen = false;
  (w.scan || []).forEach((s) => {
    let line = `\"${s.title}\": ${s.items == null ? "?" : s.items} text items read`;
    if (s.doc === 1) line += ", page content readable";
    else if (s.doc === 0) line += ", page content NOT readable";
    if (s.numbers && s.numbers.length) { seen = true; line += `. Numbers visible now: ${s.numbers.join(", ")}`; }
    else line += ". No phone numbers visible now";
    lines.push(line + ".");
    if (s.hint) lines.push(`-> ${s.hint}`);
  });
  if (w.state === "running") {
    if (w.address_bars) {
      lines.push(`Browser address bars read: ${w.address_bars}` +
        (w.addresses && w.addresses.length ? ` (${w.addresses.map((a) => `"${a}"`).join(", ")})` : "") + ".");
    } else {
      lines.push("No browser address bar could be read (needs an open Edge or Chrome window).");
    }
    if (w.page_text) lines.push(`Call page address shown in MAX: "${w.page_text}"`);
    lines.push(w.call_page_id
      ? `Call page seen: call ID ending ${String(w.call_page_id).slice(-6)}.`
      : "No CXone call page (transfer_pop2.html?contactId=...) seen yet.");
  }
  if (w.toasts) lines.push(`${w.toasts} matching notification${w.toasts === 1 ? "" : "s"} on screen.`);
  if (seen) lines.push("Numbers already on screen are the baseline; only a number that appears after the reader has looked counts as a caller.");
  el.textContent = lines.join("\n");
  el.hidden = !lines.length;
}

async function refreshCallWatch() {
  const btn = $("btn-cw-refresh");
  btn.disabled = true;
  try {
    callTestLine = "";
    const r = await api("POST", "/api/callwatch/refresh", {});
    renderCallWatchStatus(r.call_watch || r.watch);
    showToast(r.restarted ? "Window reader restarted - re-reading MAX"
                          : "Reader not started - see the status line",
              r.restarted ? "green" : "slate");
  } catch (err) { showToast(err.message, "red"); }
  finally { btn.disabled = false; }
}

async function testCallWatch() {
  const btn = $("btn-cw-test");
  btn.disabled = true;
  try {
    const t0 = Date.now();
    // Listen before sending, so a fast answer is not missed.
    const arrived = new Promise((resolve) => {
      callTestWaiter = resolve;
      setTimeout(() => resolve(null), 6000);
    });
    const r = await api("POST", "/api/callwatch/test", {});
    const ev = await arrived;
    callTestWaiter = null;
    callTestLine = ev
      ? `Test call: sent from the server and received by this page in ${((Date.now() - t0) / 1000).toFixed(1)} s (nothing was filled in). The link between TickAssist and the browser works.`
      : "Test call: sent, but this page did not receive it within 6 s. The browser is not getting events from the server - check for a proxy, VPN, extension or security software blocking localhost.";
    renderCallWatchStatus(r.watch);
    showToast(ev ? "Test call received" : "Test call did not arrive", ev ? "green" : "red");
  } catch (err) { callTestWaiter = null; showToast(err.message, "red"); }
  finally { btn.disabled = false; }
}

async function saveCallWatch() {
  try {
    const r = await api("POST", "/api/settings", {
      call_watch_enabled: $("cw-enabled").checked,
      call_watch_match: $("cw-match").value.trim(),
      call_watch_ignore: $("cw-ignore").value.trim(),
      call_watch_rules: $("cw-rules").value.trim(),
    });
    renderCallWatchStatus(r.call_watch);
    markDrawerClean("calls");
    showToast("Incoming-call settings saved", "green");
    loadSettings();
  } catch (err) { showToast(err.message, "red"); }
}

/* ---- Dynamics 365 deep links --------------------------------------------- */
// Auth is the user's existing browser session - no API or key involved.
const D365_ORG_URL = "https://planmecausprod.crm.dynamics.com";
// The org set up under Integrations > Dynamics 365, so the links and the
// signed-in integration always point at the same D365.
const d365Org = () => (d365State.org || D365_ORG_URL).replace(/\/+$/, "");

// Database page: look an existing case up via Dynamics search.
function openInD365(caseNumber) {
  const num = (caseNumber || "").trim();
  if (!num || num === "CAS") {
    showToast("This ticket has no case number", "red");
    return;
  }
  window.open(
    `${d365Org()}/main.aspx?pagetype=search&searchText=${encodeURIComponent(num)}`,
    "_blank"
  );
}

// Imaging = 766610007 in this org, BUT the case form's own logic overwrites
// casetypecode on load (verified 2026-07-21: even a minimal extraqs URL with
// only this parameter does not stick). Left null so it isn't sent; if the
// org's form customization ever changes, setting the value re-enables it.
const D365_CASETYPE_IMAGING = null;

// Generator: open a fresh case form prefilled via extraqs.
// - Title and Description are plain fields and prefill cleanly. The
//   Description carries contact (+ dealer company for dealer techs), phone,
//   and case type, since Customer/Contact on the form are LOOKUP fields:
//   a URL can only set those with the target record's GUID, which requires
//   the authenticated API - free text like a phone number cannot resolve it.
// - Timeline notes are likewise API-only records, so the finished note is
//   copied to the clipboard first; pasting it is the one manual step.
// With a Case ID already in the note the case exists, so a blank form would be
// a duplicate: search D365 for that case instead, with the note on the
// clipboard ready to paste into its timeline. Shift+click forces a new case.
async function openNewD365Case(forceNew = false) {
  if (!forceNew && hasCaseNumber()) {
    const num = getVal("caseNumber").toUpperCase();
    const noteText = noteForClipboard(buildNote());
    const list = notePhotos();
    try {
      await copySequence([list.length ? { note: noteText, html: noteHtmlWithPhotos(noteText, list) } : noteText]);
      showToast(`Searching D365 for ${num} - the note is on the clipboard, Ctrl+V pastes it into the timeline`, "green");
    } catch (err) {
      showToast(`Searching D365 for ${num} (could not load the clipboard)`, "amber");
    }
    window.open(`${d365Org()}/main.aspx?pagetype=search&searchText=${encodeURIComponent(num)}`, "_blank");
    return;
  }
  const title = getVal("caseTitle");
  const contact = getVal("contact");
  const dealer = $("contactType").value === "Dealer" ? getVal("dealerName") : "";
  const phone = getVal("phone");

  const descLines = [];
  if (contact) descLines.push(`CONTACT: ${contact}${dealer ? " - " + dealer : ""}`);
  if (phone) descLines.push(`PHONE / CUSTOMER LOOKUP: ${phone}`);
  descLines.push("CASE TYPE: Imaging");

  // Values are encoded individually, then the whole extraqs string again -
  // the double encoding is what D365's URL-addressing scheme expects.
  // casetypecode goes first: if D365 chokes partway through the parameter
  // list (the multiline description is the riskiest), it still lands.
  const fields = [];
  if (D365_CASETYPE_IMAGING != null) fields.push(`casetypecode=${D365_CASETYPE_IMAGING}`);
  if (title) fields.push(`title=${encodeURIComponent(title)}`);
  fields.push(`description=${encodeURIComponent(descLines.join("\n"))}`);

  // Clipboard history queue, copied oldest-first so Win+V lists (top-down):
  // phone, contact, serial, note - and Ctrl+V pastes the phone immediately.
  // The note carries its photos inline, so one paste brings both.
  const noteText = noteForClipboard(buildNote());
  const list = notePhotos();
  const queue = [
    list.length ? { note: noteText, html: noteHtmlWithPhotos(noteText, list) } : noteText,
    getVal("serialNumber"),
    contact,
    phone,
  ].filter((v) => typeof v !== "string" || v.trim());
  try {
    await copySequence(queue);
    showToast("Clipboard loaded - Ctrl+V pastes the phone; Win+V has contact, serial, and the note" +
      (list.length ? ` (with its ${list.length} photo${list.length === 1 ? "" : "s"})` : ""), "green");
  } catch (err) {
    showToast("Failed to load the clipboard", "red");
  }
  window.open(
    `${d365Org()}/main.aspx?etn=incident&pagetype=entityrecord` +
    `&extraqs=${encodeURIComponent(fields.join("&"))}`,
    "_blank"
  );
}

/* ---- Dynamics 365 integration -------------------------------------------- */
// Signed in (Settings > Dynamics 365), "New D365 Case" creates the case through
// the Dataverse API instead of opening a prefilled form, and "Send to D365"
// adds the note to an existing case. Signed out, everything behaves as before.
let d365State = { configured: false, signed_in: false, user: "", org: "" };
let d365Dialog = null; // { mode, matches, selected, case, tab }
const D365_CHOICES_KEY = "tickassist_d365_choices_v1";

function d365Description() {
  const contact = getVal("contact");
  const dealer = $("contactType").value === "Dealer" ? getVal("dealerName") : "";
  const phone = getVal("phone");
  const lines = [];
  if (contact) lines.push(`CONTACT: ${contact}${dealer ? " - " + dealer : ""}`);
  if (phone) lines.push(`PHONE / CUSTOMER LOOKUP: ${phone}`);
  lines.push("CASE TYPE: Imaging");
  return lines.join("\n");
}

function setD365State(st) {
  if (st) d365State = st;
  const signedIn = !!d365State.signed_in;
  $("btn-d365-note")?.classList.toggle("hidden", !signedIn);
  const nb = $("btn-new-d365-case");
  if (nb) {
    nb.title = signedIn
      ? "Create the case in D365 - customer, title, description, note and photos"
      : "Open a new D365 case with the title prefilled - or, with a Case ID entered, search D365 for that case";
  }
  renderIntegrations();
  const status = $("d365-status");
  if (!status) return;
  status.dataset.state = signedIn ? "running" : "";
  status.textContent = signedIn
    ? `Signed in${d365State.user ? " as " + d365State.user : ""} to ${d365State.org}.`
    : d365State.configured
      ? "Not signed in. Press Sign in - a Microsoft sign-in tab opens."
      : "Not set up yet: IT registers TickAssist once (see Setup for IT), then fill in the IDs below.";
  $("btn-d365-signin").classList.toggle("hidden", signedIn);
  $("btn-d365-signout").classList.toggle("hidden", !signedIn);
  $("btn-d365-test").classList.toggle("hidden", !signedIn);
}

function fillChoiceSelect(id, options, current) {
  const sel = $(id);
  if (!sel) return;
  const opts = [...(options || [])];
  if (current !== "" && current != null && !opts.some((o) => String(o.value) === String(current))) {
    opts.push({ value: current, label: `Value ${current}` });
  }
  sel.innerHTML = `<option value="">(leave blank)</option>` + opts.map((o) =>
    `<option value="${escapeHtml(String(o.value))}">${escapeHtml(o.label)} (${escapeHtml(String(o.value))})</option>`).join("");
  sel.value = current == null ? "" : String(current);
}

function loadD365Settings(s) {
  if (!$("d365-org")) return;
  $("d365-org").value = s.d365_org_url || "";
  $("d365-tenant").value = s.d365_tenant_id || "";
  $("d365-client").value = s.d365_client_id || "";
  $("d365-custmode").value = s.d365_customer_mode || "account";
  $("d365-extra").value = s.d365_case_extra || "";
  $("d365-html").checked = s.d365_note_html !== false;
  let choices = {};
  try { choices = JSON.parse(localStorage.getItem(D365_CHOICES_KEY) || "{}"); } catch (e) { /* none */ }
  fillChoiceSelect("d365-casetype", choices.casetypecode, s.d365_case_type || "");
  fillChoiceSelect("d365-origin", choices.caseorigincode, s.d365_case_origin || "");
  setD365State(s.d365);
}

async function saveD365Settings(quiet = false) {
  const extra = $("d365-extra").value.trim();
  if (extra) {
    try {
      const v = JSON.parse(extra);
      if (!v || typeof v !== "object" || Array.isArray(v)) throw new Error();
    } catch (e) {
      showToast('Other case fields must be JSON, like {"prioritycode": 2}', "red");
      return false;
    }
  }
  try {
    const res = await api("POST", "/api/settings", {
      d365_org_url: $("d365-org").value.trim(),
      d365_tenant_id: $("d365-tenant").value.trim(),
      d365_client_id: $("d365-client").value.trim(),
      d365_case_type: $("d365-casetype").value,
      d365_case_origin: $("d365-origin").value,
      d365_customer_mode: $("d365-custmode").value,
      d365_case_extra: extra,
      d365_note_html: $("d365-html").checked,
    });
    setD365State(res.d365);
    markDrawerClean("d365");
    if (!quiet) showToast("Dynamics 365 settings saved", "green");
    loadSettings();
    return true;
  } catch (err) { showToast(err.message, "red"); return false; }
}

async function d365SignIn() {
  if (!(await saveD365Settings(true))) return;
  if (!d365State.configured) {
    showToast("Fill in the D365 URL, Tenant ID and Client ID first", "red");
    return;
  }
  window.open("/d365/login", "_blank");
  $("d365-status").textContent = "Waiting for the Microsoft sign-in tab...";
  const until = Date.now() + 5 * 60 * 1000;
  while (Date.now() < until) {
    await new Promise((r) => setTimeout(r, 2000));
    try {
      const st = await api("GET", "/api/d365/status");
      if (st.signed_in) {
        setD365State(st);
        showToast(`Signed in to D365${st.user ? " as " + st.user : ""}`, "green");
        return;
      }
    } catch (e) { /* keep waiting */ }
  }
  setD365State();
}

async function d365SignOut() {
  try {
    setD365State(await api("POST", "/api/d365/signout", {}));
    showToast("Signed out of D365", "slate");
  } catch (err) { showToast(err.message, "red"); }
}

async function d365Test() {
  $("d365-status").textContent = "Testing...";
  try {
    const res = await api("POST", "/api/d365/test", {});
    const ch = res.form.choices || {};
    localStorage.setItem(D365_CHOICES_KEY, JSON.stringify(ch));
    fillChoiceSelect("d365-casetype", ch.casetypecode, $("d365-casetype").value);
    fillChoiceSelect("d365-origin", ch.caseorigincode, $("d365-origin").value);
    $("d365-choices-help").textContent =
      `Loaded ${(ch.casetypecode || []).length} case types and ${(ch.caseorigincode || []).length} origins from D365.`;
    const req = res.form.required || [];
    $("d365-required-help").innerHTML = req.length
      ? "Your case form also requires: " + req.map((r) =>
          `<code>${escapeHtml(r.name)}</code> (${escapeHtml(r.label)})`).join(", ") +
        ". Lookups need <code>field@odata.bind</code> with a record id."
      : "D365 reports no other required case fields.";
    $("d365-case-settings").open = true;
    setD365State();
    $("d365-status").textContent = `Connected as ${res.user.name || res.user.login || "you"} to ${d365State.org}.`;
    showToast("D365 connection works", "green");
  } catch (err) {
    setD365State();
    $("d365-status").dataset.state = "error";
    $("d365-status").textContent = err.message;
  }
}

/* -- the dialog -- */
function d365ShowError(msg) {
  const el = $("d365-error");
  el.textContent = msg || "";
  el.classList.toggle("hidden", !msg);
  // A lapsed sign-in turns the buttons back to the signed-out behaviour, and
  // offers the fix right here: the D365 drawer opens over the note in hand.
  if (msg && /sign in/i.test(msg)) {
    api("GET", "/api/d365/status").then((st) => setD365State(st)).catch(() => {});
    const fix = document.createElement("button");
    fix.type = "button";
    fix.className = "btn-link";
    fix.dataset.d365Fix = "";
    fix.textContent = "Sign in again";
    el.append(" ", fix);
  }
}

function d365RenderPhotosRow() {
  const row = $("d365-photos-row");
  const fresh = photos.filter((p) => !p.d365_sent_at);
  const sent = photos.length - fresh.length;
  row.classList.toggle("hidden", !photos.length);
  if (!photos.length) return;
  if (fresh.length) {
    $("d365-photos-label").textContent = `Attach ${fresh.length} photo${fresh.length === 1 ? "" : "s"}` +
      (sent ? ` (${sent} already sent)` : "");
    $("d365-send-photos").checked = true;
  } else {
    $("d365-photos-label").textContent = `Attach the ${sent} photo${sent === 1 ? "" : "s"} again (already sent)`;
    $("d365-send-photos").checked = false;
  }
}

function d365PhotoIds() {
  if (!$("d365-send-photos").checked || !photos.length) return [];
  const fresh = photos.filter((p) => !p.d365_sent_at);
  return (fresh.length ? fresh : photos).map((p) => p.id);
}

function openD365Dialog(mode) {
  d365Dialog = { mode, matches: [], selected: null, case: null };
  $("d365-modal-title").textContent = mode === "create" ? "Create D365 Case" : "Send Note to D365";
  $("d365-create-body").classList.toggle("hidden", mode !== "create");
  $("d365-note-body").classList.toggle("hidden", mode !== "note");
  $("d365-go").textContent = mode === "create" ? "Create Case" : "Send to D365";
  $("d365-go").disabled = false;
  $("d365-send-note").checked = true;
  d365ShowError("");
  d365RenderPhotosRow();
  $("d365-modal").classList.remove("hidden");
}

function closeD365Dialog() {
  $("d365-modal").classList.add("hidden");
  d365Dialog = null;
}

function d365ResultLabel(m) {
  if (m.kind === "contact") {
    return `<b>${escapeHtml(m.name)}</b>` +
      (m.account_name ? ` &middot; ${escapeHtml(m.account_name)}` : "") +
      `<span class="d365-meta">${escapeHtml([m.phone, m.email].filter(Boolean).join(" · "))}</span>`;
  }
  return `<b>${escapeHtml(m.name)}</b> <span class="d365-kind">account</span>` +
    `<span class="d365-meta">${escapeHtml([m.account_number && "#" + m.account_number, m.city, m.phone].filter(Boolean).join(" · "))}</span>`;
}

function d365RenderResults(note) {
  const box = $("d365-results");
  const d = d365Dialog;
  if (!d.matches.length) {
    box.innerHTML = `<div class="d365-empty">${escapeHtml(note || "No match. Search by name or account number.")}</div>`;
    return;
  }
  box.innerHTML = d.matches.map((m, i) => `
    <label class="d365-result">
      <input type="radio" name="d365-customer" value="${i}" ${d.selected === i ? "checked" : ""}>
      <span>${d365ResultLabel(m)}</span>
    </label>`).join("");
}

async function d365Search(phone, name) {
  const d = d365Dialog;
  if (!d) return;
  $("d365-results").innerHTML = `<div class="d365-empty">Searching D365...</div>`;
  try {
    const q = new URLSearchParams();
    if (phone) q.set("phone", phone);
    if (name) q.set("name", name);
    const res = await api("GET", `/api/d365/customers?${q}`);
    if (d365Dialog !== d) return;
    d.matches = res.matches || [];
    // One match, or one person among a contact and accounts sharing the
    // number, is picked for you; anything less clear is left to choose.
    const people = d.matches.filter((m) => m.kind === "contact");
    d.selected = d.matches.length === 1 ? 0
      : people.length === 1 && phone ? d.matches.indexOf(people[0]) : null;
    d365RenderResults(phone && !name ? `No D365 contact or account has ${phone}. Search by name.` : "");
  } catch (err) {
    if (d365Dialog !== d) return;
    d.matches = [];
    d365RenderResults(err.message);
    if (/sign/i.test(err.message)) setD365State({ ...d365State, signed_in: false });
  }
}

async function openD365Create() {
  if (hasCaseNumber()) {
    const ok = await confirmModal("This note already has a case",
      `Case ID is ${getVal("caseNumber")}. Create another case in D365 anyway?`, "Create new");
    if (!ok) return;
  }
  openD365Dialog("create");
  $("d365-title").value = getVal("caseTitle");
  $("d365-desc").value = d365Description();
  const phone = getVal("phone");
  $("d365-search").value = phone || getVal("contact");
  d365Search(phone, phone ? "" : getVal("contact"));
  setTimeout(() => $("d365-title").focus(), 0);
}

async function openD365Note() {
  if (!hasCaseNumber()) {
    showToast("Enter the Case ID first (or use New D365 Case)", "red");
    $("caseNumber").focus();
    return;
  }
  openD365Dialog("note");
  const d = d365Dialog;
  const number = getVal("caseNumber");
  $("d365-subject").value = `Technical Note - ${getVal("caseTitle") || number}`;
  $("d365-go").disabled = true;
  $("d365-case-card").textContent = `Looking up ${number} in D365...`;
  try {
    const res = await api("GET", `/api/d365/case?number=${encodeURIComponent(number)}`);
    if (d365Dialog !== d) return;
    d.case = res.case;
    const c = res.case;
    $("d365-case-card").innerHTML =
      `<b>${escapeHtml(c.number)}</b> &middot; ${escapeHtml(c.title)}` +
      `<span class="d365-meta">${escapeHtml([c.customer, c.status].filter(Boolean).join(" · "))}</span>` +
      (c.active ? "" : `<span class="d365-warn">This case is not active - D365 may refuse new notes.</span>`);
    if (!getVal("caseTitle")) $("d365-subject").value = `Technical Note - ${c.title}`;
    $("d365-go").disabled = false;
  } catch (err) {
    if (d365Dialog !== d) return;
    $("d365-case-card").textContent = "";
    d365ShowError(err.message);
  }
}

async function d365Go() {
  const d = d365Dialog;
  if (!d) return;
  d365ShowError("");
  const sendNote = $("d365-send-note").checked;
  const ids = d365PhotoIds();
  const text = noteForClipboard(buildNote());
  const go = $("d365-go");

  if (d.mode === "create") {
    const title = $("d365-title").value.trim();
    if (!title) { d365ShowError("A case needs a title."); return; }
    if (d.selected == null) { d365ShowError("Pick the customer for this case."); return; }
    const m = d.matches[d.selected];
    const mode = d365State.customer_mode || "account";
    const customer = m.kind === "account"
      ? { kind: "account", id: m.id }
      : (mode === "account" && m.account_id ? { kind: "account", id: m.account_id } : { kind: "contact", id: m.id });
    const contactId = m.kind === "contact" && customer.kind === "account" ? m.id : null;
    // Opened now, while the click still counts, so the case can show in it.
    const tab = window.open("about:blank", "_blank");
    go.disabled = true; go.textContent = "Creating...";
    try {
      const res = await api("POST", "/api/d365/case", {
        title, description: $("d365-desc").value, customer, contact_id: contactId,
        note: sendNote ? { subject: `Technical Note - ${title}`, text } : null,
        photo_ids: ids,
      });
      const c = res.case;
      if (c.number) {
        $("caseNumber").value = c.number;
        $("caseNumber").dispatchEvent(new Event("input", { bubbles: true }));
      }
      if (title !== getVal("caseTitle")) {
        $("caseTitle").value = title;
        $("caseTitle").dispatchEvent(new Event("input", { bubbles: true }));
      }
      saveFormState();
      closeD365Dialog();
      if (tab && c.url) tab.location.href = c.url; else if (tab) tab.close();
      await loadPhotos();
      if (res.note_error) {
        showToast(`Created ${c.number}, but the note didn't go: ${res.note_error}`, "red");
      } else {
        const n = res.note ? res.note.photos : 0;
        showToast(`Created ${c.number} in D365` + (res.note ? " with the note" : "") +
          (n ? ` and ${n} photo${n === 1 ? "" : "s"}` : ""), "green");
      }
    } catch (err) {
      if (tab) tab.close();
      go.disabled = false; go.textContent = "Create Case";
      d365ShowError(err.message);
    }
    return;
  }

  if (!d.case) return;
  if (!sendNote && !ids.length) { d365ShowError("Nothing to send - tick the note or photos."); return; }
  go.disabled = true; go.textContent = "Sending...";
  try {
    const res = await api("POST", "/api/d365/note", {
      number: d.case.number, incident_id: d.case.id,
      subject: $("d365-subject").value.trim(),
      text: sendNote ? text : "", photo_ids: ids,
    });
    closeD365Dialog();
    await loadPhotos();
    const n = res.note.photos;
    showToast(`Sent to ${res.case.number}` + (sendNote ? ": the note" : ":") +
      (n ? `${sendNote ? " and" : ""} ${n} photo${n === 1 ? "" : "s"}` : ""), "green");
  } catch (err) {
    go.disabled = false; go.textContent = "Send to D365";
    d365ShowError(err.message);
  }
}

function initD365() {
  if (!$("d365-modal")) return;
  on("btn-d365-save", "click", () => saveD365Settings(false));
  on("btn-d365-signin", "click", d365SignIn);
  on("btn-d365-signout", "click", d365SignOut);
  on("btn-d365-test", "click", d365Test);
  on("btn-d365-note", "click", openD365Note);
  on("d365-modal-close", "click", closeD365Dialog);
  on("d365-cancel", "click", closeD365Dialog);
  on("d365-go", "click", d365Go);
  on("d365-modal", "click", (e) => { if (e.target === $("d365-modal")) closeD365Dialog(); });
  // "Sign in again" under a lapsed-sign-in error: the dialog steps aside for
  // the D365 drawer, and the note stays exactly as it was.
  on("d365-error", "click", (e) => {
    if (!e.target.closest("[data-d365-fix]")) return;
    closeD365Dialog();
    openDrawer("d365");
  });
  $("d365-results").addEventListener("change", (e) => {
    if (e.target.name === "d365-customer" && d365Dialog) d365Dialog.selected = Number(e.target.value);
  });
  const search = () => {
    const v = $("d365-search").value.trim();
    if (!v) return;
    const digits = v.replace(/\D/g, "");
    if (digits.length >= 7 && /^[\d\s()+.\-]+$/.test(v)) d365Search(v, "");
    else d365Search("", v);
  };
  on("d365-search-btn", "click", search);
  $("d365-search").addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); search(); }
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && d365Dialog && $("modal").classList.contains("hidden")) {
      e.preventDefault();
      closeD365Dialog();
    }
  });
}

/* ---- photos ------------------------------------------------------------ */
// Photos live in the local database with their ticket (the unsaved form's
// are a draft set the save claims). They are sized for D365 on the way in:
// its default note attachment limit is 5 MB, and a phone photo is often more.
const PHOTO_MAX_EDGE = 2000;               // px, long side, when resizing
const PHOTO_KEEP_BYTES = 2.5 * 1024 * 1024; // smaller files are kept as-is
const PHOTO_KEEP_EDGE = 2560;
const PHOTO_JPEG_QUALITY = 0.85;
const PHOTO_KEEP_TYPES = ["image/png", "image/jpeg", "image/gif", "image/webp"];
const CAMERA_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>';

let photos = []; // [{ id, name, mime, width, height, size }]

const photoScope = () => (editing ? `ticket=${editing.id}` : "draft=1");

async function loadPhotos() {
  if (!featureOn("photos")) { photos = []; renderPhotos(); return; }
  const scope = photoScope();
  try {
    const data = await api("GET", `/api/photos?${scope}`);
    if (scope !== photoScope()) return; // the form moved on meanwhile
    photos = data.photos || [];
  } catch (err) { photos = []; }
  renderPhotos();
}

async function discardDraftPhotos() {
  try { await api("POST", "/api/photos/discard-drafts"); } catch (err) { /* best effort */ }
  await loadPhotos();
}

const fmtBytes = (n) => (n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

function photoExt(mime) {
  return ({ "image/jpeg": "jpg", "image/png": "png", "image/gif": "gif",
            "image/webp": "webp", "image/bmp": "bmp" })[mime] || "img";
}

// CAS0485494-1.jpg when the case has a number, so attachments in D365 and
// files in Downloads say which case they belong to.
function photoFileName(p, index) {
  const base = hasCaseNumber() ? getVal("caseNumber").replace(/[^\w-]+/g, "") : "photo";
  return `${base}-${index + 1}.${photoExt(p.mime)}`;
}

function canvasBlob(canvas, type, quality) {
  return new Promise((resolve, reject) => canvas.toBlob(
    (b) => (b ? resolve(b) : reject(new Error("Could not encode the image"))), type, quality));
}

// Small, browser-friendly images are kept byte for byte; anything large is
// scaled to PHOTO_MAX_EDGE - as PNG if that stays small (screenshots of text),
// otherwise as JPEG on white.
async function preparePhoto(file) {
  let bmp;
  try {
    bmp = await createImageBitmap(file);
  } catch (err) {
    const heic = /hei[cf]/i.test(`${file.type} ${file.name}`);
    throw new Error(`${file.name || "That image"} can't be opened by the browser` +
      (heic ? " - iPhone HEIC photos need to be shared as JPEG" : ""));
  }
  const w = bmp.width, h = bmp.height, edge = Math.max(w, h);
  if (PHOTO_KEEP_TYPES.includes(file.type) && file.size <= PHOTO_KEEP_BYTES && edge <= PHOTO_KEEP_EDGE) {
    bmp.close();
    return { blob: file, w, h };
  }
  const scale = Math.min(1, PHOTO_MAX_EDGE / edge);
  const cw = Math.max(1, Math.round(w * scale)), ch = Math.max(1, Math.round(h * scale));
  const canvas = document.createElement("canvas");
  canvas.width = cw; canvas.height = ch;
  const ctx = canvas.getContext("2d");
  if (file.type === "image/png") {
    ctx.drawImage(bmp, 0, 0, cw, ch);
    const png = await canvasBlob(canvas, "image/png");
    if (png.size <= PHOTO_KEEP_BYTES) { bmp.close(); return { blob: png, w: cw, h: ch }; }
  }
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, cw, ch);
  ctx.drawImage(bmp, 0, 0, cw, ch);
  bmp.close();
  return { blob: await canvasBlob(canvas, "image/jpeg", PHOTO_JPEG_QUALITY), w: cw, h: ch };
}

async function addPhotos(fileList) {
  const files = [...fileList].filter((f) => f && (f.type.startsWith("image/") || /\.(hei[cf])$/i.test(f.name)));
  if (!files.length) { showToast("Those aren't image files", "red"); return; }
  const scope = photoScope();
  let added = 0;
  for (const file of files) {
    try {
      const { blob, w, h } = await preparePhoto(file);
      const stem = (file.name || "").replace(/\.[^.]+$/, "") || `pasted-${Date.now()}`;
      const name = `${stem}.${photoExt(blob.type)}`;
      const res = await fetch(`/api/photos?${scope}&name=${encodeURIComponent(name)}&w=${w}&h=${h}`,
        { method: "POST", headers: { "Content-Type": blob.type }, body: blob });
      if (!res.ok) {
        let msg = `Upload failed (${res.status})`;
        try { msg = (await res.json()).error || msg; } catch (e) { /* no body */ }
        throw new Error(msg);
      }
      added++;
    } catch (err) {
      showToast(err.message, "red");
    }
  }
  await loadPhotos();
  if (added) {
    showToast(`Added ${added} photo${added === 1 ? "" : "s"}` +
      (editing ? ` to ${editing.label}` : " - saved with the ticket"), "green");
  }
}

// The clipboard only takes PNG images, so other formats are converted.
async function photoPngBlob(id) {
  const res = await fetch(`/api/photos/${id}`);
  if (!res.ok) throw new Error("Photo not found");
  const blob = await res.blob();
  if (blob.type === "image/png") return blob;
  const bmp = await createImageBitmap(blob);
  const canvas = document.createElement("canvas");
  canvas.width = bmp.width; canvas.height = bmp.height;
  canvas.getContext("2d").drawImage(bmp, 0, 0);
  bmp.close();
  return canvasBlob(canvas, "image/png");
}

async function copyPhoto(id) {
  if (!window.ClipboardItem || !navigator.clipboard || !navigator.clipboard.write) {
    throw new Error("This browser can't copy images - use Save instead");
  }
  // Handing ClipboardItem the promise keeps the click's permission alive
  // while the image is fetched and converted.
  await navigator.clipboard.write([new ClipboardItem({ "image/png": photoPngBlob(id) })]);
}

function downloadPhoto(p, index) {
  const a = document.createElement("a");
  a.href = `/api/photos/${p.id}?download=1&name=${encodeURIComponent(photoFileName(p, index))}`;
  a.download = photoFileName(p, index);
  document.body.appendChild(a);
  a.click();
  a.remove();
}

function renderPhotos() {
  const grid = $("photo-grid");
  if (!grid) return;
  const n = photos.length;
  $("photos-count").textContent = n ? `(${n})` : "";
  $("photo-empty").classList.toggle("hidden", n > 0);
  $("btn-photo-copy-all").classList.toggle("hidden", n < 2);
  $("btn-photo-save-all").classList.toggle("hidden", n < 2);
  grid.innerHTML = photos.map((p, i) => `
    <div class="photo-tile" data-photo="${p.id}">
      <img src="/api/photos/${p.id}" alt="${escapeHtml(p.name || "Photo")}" loading="lazy"
           draggable="true" data-photo-open="${p.id}"
           title="${escapeHtml(photoFileName(p, i))} - ${p.width && p.height ? `${p.width}x${p.height}, ` : ""}${fmtBytes(p.size)}. Click to open full size; drag to a folder to save it.">
      <div class="photo-actions">
        <button class="btn small" data-photo-copy="${p.id}" title="Copy the image - paste it into a D365 note">Copy</button>
        <button class="btn small" data-photo-save="${p.id}" title="Download, to attach in D365">Save</button>
        <button class="icon-btn" data-photo-del="${p.id}" title="Remove photo">${TRASH_SVG}</button>
      </div>
    </div>`).join("");
}

function initPhotos() {
  const zone = $("photo-drop");
  if (!zone) return;
  const input = $("photo-input");
  on("btn-photo-add", "click", () => input.click());
  input.addEventListener("change", () => {
    if (input.files.length) addPhotos(input.files);
    input.value = "";
  });

  on("btn-photo-copy-all", "click", async () => {
    try {
      await copySequence(photos.map((p) => ({ photo: p.id })));
      showToast(`${photos.length} photos copied - Win+V lists them all, newest first`, "green");
    } catch (err) { showToast(err.message || "Copy failed", "red"); }
  });
  on("btn-photo-save-all", "click", async () => {
    for (let i = 0; i < photos.length; i++) {
      if (i) await new Promise((r) => setTimeout(r, 300));
      downloadPhoto(photos[i], i);
    }
  });

  $("photo-grid").addEventListener("click", async (e) => {
    const t = e.target.closest("[data-photo-copy],[data-photo-save],[data-photo-del],[data-photo-open]");
    if (!t) return;
    const id = Number(t.dataset.photoCopy || t.dataset.photoSave || t.dataset.photoDel || t.dataset.photoOpen);
    const index = photos.findIndex((p) => p.id === id);
    if (index < 0) return;
    if (t.dataset.photoOpen) {
      window.open(`/api/photos/${id}`, "_blank");
    } else if (t.dataset.photoCopy) {
      try {
        await copyPhoto(id);
        showToast("Photo copied - paste it into the D365 note (Ctrl+V)", "green");
      } catch (err) { showToast(err.message || "Copy failed", "red"); }
    } else if (t.dataset.photoSave) {
      downloadPhoto(photos[index], index);
    } else if (t.dataset.photoDel) {
      const ok = !editing || await confirmModal("Remove this photo?",
        `It is deleted from saved ticket ${editing.label}. This cannot be undone.`, "Remove");
      if (!ok) return;
      try {
        await api("DELETE", `/api/photos/${id}`);
        await loadPhotos();
        saveFormState();
      } catch (err) { showToast(err.message, "red"); }
    }
  });

  // Dragging a photo out hands over a file (Chrome/Edge), so dropping it on
  // the desktop or a folder saves it. No URL is offered: a localhost link
  // dropped into D365 would only ever work on this PC.
  $("photo-grid").addEventListener("dragstart", (e) => {
    const img = e.target.closest("img[data-photo-open]");
    if (!img) return;
    const index = photos.findIndex((p) => p.id === Number(img.dataset.photoOpen));
    if (index < 0) return;
    const p = photos[index], name = photoFileName(p, index);
    e.dataTransfer.clearData();
    e.dataTransfer.setData("DownloadURL",
      `${p.mime}:${name}:${location.origin}/api/photos/${p.id}?download=1&name=${encodeURIComponent(name)}`);
    e.dataTransfer.effectAllowed = "copy";
    zone.dataset.dragOut = "1";
  });
  $("photo-grid").addEventListener("dragend", () => { delete zone.dataset.dragOut; });

  const hasFiles = (e) => !zone.dataset.dragOut && [...(e.dataTransfer?.types || [])].includes("Files");
  zone.addEventListener("dragover", (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
    zone.classList.add("dragging");
  });
  zone.addEventListener("dragleave", (e) => {
    if (!zone.contains(e.relatedTarget)) zone.classList.remove("dragging");
  });
  zone.addEventListener("drop", (e) => {
    zone.classList.remove("dragging");
    if (!hasFiles(e)) return;
    e.preventDefault();
    addPhotos(e.dataTransfer.files);
  });

  // Ctrl+V of a screenshot anywhere on the Note Generator adds it - except
  // into a text field when the clipboard also carries text, so pasting from
  // Word or a web page still pastes words.
  document.addEventListener("paste", (e) => {
    if (!featureOn("photos")) return;
    if (!$("page-generator").classList.contains("active")) return;
    if (document.querySelector(".modal-backdrop:not(.hidden)") || openDrawerName) return;
    const cd = e.clipboardData;
    if (!cd) return;
    const images = [...cd.items].filter((it) => it.kind === "file" && it.type.startsWith("image/"))
      .map((it) => it.getAsFile()).filter(Boolean);
    if (!images.length) return;
    const field = e.target.closest && e.target.closest("input, textarea, [contenteditable]");
    if (field && (cd.getData("text/plain") || "").trim()) return;
    e.preventDefault();
    addPhotos(images);
  });

  loadPhotos();
}

/* ---- managed lists (dealers / device types / Reco units) ---------------- */
// Each list drives a Settings add/trash panel and a generator combobox.
const LISTS = {
  dealers: { items: [], combo: null },
  device_types: { items: [], combo: null },
  reco_units: { items: [], combo: null },
  // System Environment dropdowns
  os_versions: { items: [], combo: null }, device_firmware: { items: [], combo: null },
  device_tool_versions: { items: [], combo: null }, didapi_versions: { items: [], combo: null },
  romexis_versions: { items: [], combo: null }, imaging_packages: { items: [], combo: null },
  reco_os: { items: [], combo: null }, reco_firmware: { items: [], combo: null },
};
// list -> [input id, ticket column]: what each dropdown suggests, and what a
// save adds to it.
const ENV_COMBOS = {
  os_versions: ["osVersion", "os_version"], device_firmware: ["deviceFirmware", "device_firmware"],
  device_tool_versions: ["deviceToolVersion", "device_tool_version"], didapi_versions: ["didapi", "didapi"],
  romexis_versions: ["romexis", "romexis"], imaging_packages: ["imagingPackage", "imaging_package"],
  reco_os: ["recoOs", "reco_os"], reco_firmware: ["recoFirmware", "reco_firmware"],
};

async function loadList(key) {
  try {
    const data = await api("GET", `/api/lists/${key}`);
    LISTS[key].items = data.items || [];
    LISTS[key].fixed = !!data.fixed;
    LISTS[key].verified = !!data.verified;
    renderListPanel(key);
    if (LISTS[key].combo) LISTS[key].combo.render();
  } catch (err) { showToast(err.message, "red"); }
}

/* ---- listed fields: pick from the list, never invent a value ------------------- */
// Device Type, Reco Unit and the System Environment fields only take values on
// their list. Typing "23" when the list holds 23.1.0 and 23.1.2 gets a short
// dropdown of those to choose from. Environment values that are not on the
// list yet are accepted (and added) only if a linked Google Sheet has them.
// Romexis versions are the exception: the sheets write them awkwardly, so that
// field stays free text with suggestions and a typed value is added on save.
const FREE_LISTS = new Set(["romexis_versions"]);
const LISTED_FIELDS = [["device_types", "deviceType"], ["reco_units", "recoPc"],
  ...Object.entries(ENV_COMBOS).filter(([key]) => !FREE_LISTS.has(key)).map(([key, [id]]) => [key, id])];
const LISTED_LABEL = { deviceType: "Device Type", recoPc: "Reco Unit", osVersion: "OS Version",
  deviceFirmware: "Device Firmware", deviceToolVersion: "Device Tool", didapi: "DIDAPI",
  romexis: "Romexis", imagingPackage: "Imaging Package", recoOs: "Reco OS", recoFirmware: "Reco Firmware" };
let loadedListed = {};          // field id -> value it had when a saved note was opened
const sheetVerdict = {};        // "list|value" -> { ok, at }

function listedKey(id) { const f = LISTED_FIELDS.find((x) => x[1] === id); return f && f[0]; }

function relatedListItems(key, typed) {
  const t = typed.trim().toLowerCase();
  if (!t) return [];
  const toks = (s) => s.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
  const tt = toks(t);
  const scored = [];
  for (const it of LISTS[key].items) {
    const name = it.name.toLowerCase();
    const nt = toks(name);
    let common = 0;
    while (common < tt.length && common < nt.length && tt[common] === nt[common]) common++;
    let score = common * 10;
    if (name.startsWith(t) || t.startsWith(name)) score += 5;
    else if (name.includes(t)) score += 3;
    if (score > 0) scored.push([score, it.name]);
  }
  scored.sort((a, b) => b[0] - a[0] || a[1].localeCompare(b[1], undefined, { numeric: true }));
  return scored.slice(0, 6).map((s) => s[1]);
}

// "ok" | "invalid". Canonicalises the case of a match and adds a sheet-verified value.
async function checkListed(id, announce) {
  const el = $(id), key = listedKey(id);
  if (!el || !key) return "ok";
  const typed = el.value.trim();
  el.classList.remove("list-invalid");
  if (!typed) return "ok";
  const hit = LISTS[key].items.find((it) => it.name.toLowerCase() === typed.toLowerCase());
  if (hit) { if (el.value !== hit.name) el.value = hit.name; return "ok"; }
  if (loadedListed[id] === typed.toLowerCase()) return "ok";   // unchanged on a saved note
  if (LISTS[key].verified) {
    const vk = key + "|" + typed.toLowerCase();
    const seen = sheetVerdict[vk];
    if (!seen || Date.now() - seen.at > 30000) {
      try {
        const r = await api("GET", `/api/lists/${key}/verify?value=${encodeURIComponent(typed)}`);
        sheetVerdict[vk] = { ok: !!r.verified, value: r.value, at: Date.now() };
        if (r.verified && await addListItem(key, r.value)) { if (el.value.trim().toLowerCase() === typed.toLowerCase()) el.value = r.value; return "ok"; }
      } catch (err) { sheetVerdict[vk] = { ok: false, at: Date.now() }; }
    } else if (seen.ok) { await loadList(key); return "ok"; }
  }
  el.classList.add("list-invalid");
  if (announce) {
    const names = relatedListItems(key, typed);
    const combo = LISTS[key].combo;
    if (combo) combo.suggest(names, names.length ? "Not on the list - pick one of these:" : "Not on the list");
  }
  return "invalid";
}

async function unlistedFields() {
  const bad = [];
  for (const [, id] of LISTED_FIELDS) if (await checkListed(id, false) === "invalid") bad.push(id);
  return bad;
}

function reportUnlisted(bad) {
  if (typeof setEnvCollapsed === "function" && $("env-section") &&
      $("env-section").classList.contains("collapsed")) setEnvCollapsed(false, false);
  bad.forEach((id) => { const s = $(id).closest("[data-fi-step]"); if (s) fiFolded[s.dataset.fiStep] = false; });
  renderFiSteps();
  showToast("Pick from the list: " + bad.map((id) => `${LISTED_LABEL[id] || id} "${getVal(id)}"`).join(", ") +
            " (Shift+click Save to save it anyway)", "red");
  const first = $(bad[0]);
  if (first) {
    first.scrollIntoView({ block: "center", behavior: "smooth" });
    first.focus();
    checkListed(bad[0], true);
  }
}

function initListedFields() {
  LISTED_FIELDS.forEach(([, id]) => {
    const el = $(id);
    if (!el) return;
    el.addEventListener("input", () => el.classList.remove("list-invalid"));
    el.addEventListener("change", () => checkListed(id, true));
  });
}

function loadAllLists() { Object.keys(LISTS).forEach(loadList); }

function listHas(key, name) {
  const n = (name || "").trim().toLowerCase();
  return LISTS[key].items.some((it) => it.name.toLowerCase() === n);
}

function renderListPanel(key) {
  const list = document.querySelector(`[data-list="${key}"]`);
  if (!list) return;
  const fixed = LISTS[key].fixed;
  // A fixed list has no Add row and no Remove buttons: only an update changes it.
  const add = document.querySelector(`[data-list-add="${key}"]`);
  if (add && add.closest(".managed-add")) add.closest(".managed-add").classList.toggle("hidden", fixed);
  list.innerHTML = LISTS[key].items.length
    ? LISTS[key].items.map((it) => `
      <div class="managed-row">
        <span class="name">${escapeHtml(it.name)}</span>
        ${fixed ? "" : `<button class="icon-btn" data-list-del="${key}" data-id="${it.id}" title="Remove">${TRASH_SVG}</button>`}
      </div>`).join("") +
      (fixed ? '<div class="field-help">Fixed list - new entries arrive with a TickAssist update.</div>' : "")
    : `<div class="empty">${fixed ? "Empty." : "Nothing here yet. Add one above."}</div>`;
}

// Returns true on success; shows its own error toast on failure.
async function addListItem(key, name) {
  name = (name || "").trim();
  if (!name) { showToast("Enter a value first", "red"); return false; }
  try {
    await api("POST", `/api/lists/${key}`, { name });
    await loadList(key);
    return true;
  } catch (err) { showToast(err.message, "red"); return false; }
}

async function deleteListItem(key, id) {
  const ok = await confirmModal("Remove this entry?", "It will be removed from the list.", "Remove");
  if (!ok) return;
  try {
    await api("DELETE", `/api/lists/${key}/${id}`);
    showToast("Removed", "slate");
    loadList(key);
  } catch (err) { showToast(err.message, "red"); }
}

// Register a value typed straight into a ticket field into its list on save.
async function autoRegister(key, value) {
  const name = (value || "").trim();
  if (!name || listHas(key, name)) return;
  try { await api("POST", `/api/lists/${key}`, { name }); await loadList(key); }
  catch (err) { /* duplicate / race - ignore */ }
}

/* ---- reusable combobox (typeable dropdown backed by a managed list) ------ */
function createCombobox(inputId, menuId, listKey, onChoose, filter) {
  const input = $(inputId);
  const menu = $(menuId);
  if (!input || !menu) return null;
  let activeIndex = -1;
  let pinned = false;   // "pick one of these" menu that stays up after the field is left

  function render() {
    const q = input.value.trim().toLowerCase();
    let items = LISTS[listKey].items || [];
    if (filter) items = filter(items);
    const matches = q ? items.filter((it) => it.name.toLowerCase().includes(q)) : items.slice();
    menu.innerHTML = !matches.length && !q ? "" : matches.length
      ? matches.map((it) =>
          `<div class="combo-item" role="option" data-name="${escapeHtml(it.name)}">${escapeHtml(it.name)}</div>`
        ).join("")
      : `<div class="combo-empty">No matches &mdash; press Save to add "${escapeHtml(input.value.trim())}"</div>`;
    activeIndex = -1;
  }
  function open() { pinned = false; render(); menu.classList.toggle("hidden", !menu.innerHTML); }
  function close() { pinned = false; menu.classList.add("hidden"); activeIndex = -1; }
  // Show the given names (not the typed-text filter) with a note on top.
  function suggest(names, note) {
    pinned = true;
    menu.innerHTML = `<div class="combo-empty">${escapeHtml(note || "")}</div>` + names.map((n) =>
      `<div class="combo-item" role="option" data-name="${escapeHtml(n)}">${escapeHtml(n)}</div>`).join("");
    activeIndex = -1;
    menu.classList.remove("hidden");
  }
  function move(delta) {
    if (menu.classList.contains("hidden")) { open(); return; }
    const items = [...menu.querySelectorAll(".combo-item")];
    if (!items.length) return;
    activeIndex = (activeIndex + delta + items.length) % items.length;
    items.forEach((el, i) => el.classList.toggle("active", i === activeIndex));
    items[activeIndex].scrollIntoView({ block: "nearest" });
  }
  function choose(name) {
    input.value = name; close(); input.classList.remove("list-invalid");
    if (onChoose) onChoose();
  }

  input.addEventListener("focus", () => { if (!pinned) open(); });
  input.addEventListener("input", open);
  input.addEventListener("blur", () => setTimeout(() => { if (!pinned) close(); }, 120));
  document.addEventListener("mousedown", (e) => {
    if (pinned && !menu.contains(e.target) && e.target !== input) close();
  });
  input.addEventListener("keydown", (e) => {
    const isOpen = !menu.classList.contains("hidden");
    if (e.key === "ArrowDown") { e.preventDefault(); move(1); }
    else if (e.key === "ArrowUp") { e.preventDefault(); move(-1); }
    else if (e.key === "Enter" && isOpen) {
      // Enter takes the highlighted suggestion, else the exact match, else the
      // first suggestion; with nothing suggested it just closes the list.
      const items = [...menu.querySelectorAll(".combo-item")];
      const typed = input.value.trim().toLowerCase();
      const pick = items[activeIndex] || items.find((el) => el.dataset.name.toLowerCase() === typed) || items[0];
      if (pick) { e.preventDefault(); choose(pick.dataset.name); } else close();
    } else if (e.key === "Escape") { close(); }
  });
  menu.addEventListener("mousedown", (e) => {
    const item = e.target.closest(".combo-item");
    if (item) { e.preventDefault(); choose(item.dataset.name); }
  });

  return { render, open, close, suggest };
}

/* ---- shorthand macros --------------------------------------------------- */
let macrosCache = [];

const TRASH_SVG =
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>';

async function loadMacros() {
  try {
    const data = await api("GET", "/api/macros");
    macrosCache = data.macros || [];
    renderMacroList();
  } catch (err) { showToast(err.message, "red"); }
}

function renderMacroList() {
  const list = $("macro-list");
  if (!list) return;
  list.innerHTML = macrosCache.length
    ? macrosCache.map((m) => {
      // Single-line preview: show newlines as a subtle return glyph.
      const preview = escapeHtml(m.expansion).replace(/\r?\n/g, ' <span class="macro-nl">&crarr;</span> ');
      return `
      <div class="macro-row">
        <span class="trigger">\\${escapeHtml(m.trigger)}</span>
        <span class="arrow">&rarr;</span>
        <span class="expansion" title="${escapeHtml(m.expansion)}">${preview}</span>
        <button class="icon-btn" data-del-macro="${m.id}" title="Remove macro">${TRASH_SVG}</button>
      </div>`;
    }).join("")
    : `<div class="empty">No macros yet. Add one above.</div>`;
}

async function addMacro() {
  const tEl = $("new-macro-trigger");
  const eEl = $("new-macro-expansion");
  const trigger = tEl.value.trim();
  const expansion = eEl.value;
  if (!trigger || !expansion.trim()) {
    showToast("Enter a trigger and an expansion", "red");
    return;
  }
  try {
    await api("POST", "/api/macros", { trigger, expansion });
    tEl.value = "";
    eEl.value = "";
    autosizeMacroExpansion();
    showToast("Macro added", "green");
    loadMacros();
    tEl.focus();
  } catch (err) { showToast(err.message, "red"); }
}

async function deleteMacro(id) {
  const ok = await confirmModal("Remove this macro?", "It will be permanently removed.", "Remove");
  if (!ok) return;
  try {
    await api("DELETE", `/api/macros/${id}`);
    showToast("Macro removed", "slate");
    loadMacros();
  } catch (err) { showToast(err.message, "red"); }
}

// Grow the expansion textarea to fit its content (single line until it wraps).
function autosizeMacroExpansion() {
  const el = $("new-macro-expansion");
  if (!el || el.offsetParent === null) return; // skip while hidden (scrollHeight 0)
  el.style.height = "auto";
  el.style.height = el.scrollHeight + "px";
}

// Don't expand inside the macro-definition fields themselves.
const MACRO_EXCLUDE = new Set(["new-macro-trigger", "new-macro-expansion"]);

// Expand "\trigger" when a terminator (space / Enter / Tab) is pressed.
function handleMacroKeydown(e) {
  if (e.key !== " " && e.key !== "Enter" && e.key !== "Tab") return;
  if (e.ctrlKey || e.metaKey || e.altKey) return; // shortcuts are not terminators
  if (e.shiftKey && (e.key === "Enter" || e.key === " ")) return;
  if (!macrosCache.length) return;
  const el = e.target;
  if (!el || MACRO_EXCLUDE.has(el.id)) return;
  const tag = el.tagName;
  const isText = tag === "TEXTAREA" ||
    (tag === "INPUT" && /^(text|tel|search|email|url|)$/i.test(el.type));
  if (!isText) return;
  if (typeof el.selectionStart !== "number" || el.selectionStart !== el.selectionEnd) return;

  const pos = el.selectionStart;
  const m = el.value.slice(0, pos).match(/\\([A-Za-z0-9]+)$/);
  if (!m) return;
  const macro = macrosCache.find((x) => x.trigger.toLowerCase() === m[1].toLowerCase());
  if (!macro) return;

  e.preventDefault();
  const start = pos - m[0].length;
  let tail = "";
  if (e.key === " ") tail = " ";
  else if (e.key === "Enter" && tag === "TEXTAREA") tail = "\n";
  const insert = macro.expansion + tail;

  // Select the "\trigger" token, then replace it via execCommand so the swap
  // lands on the browser's native undo stack -> Ctrl+Z reverts the expansion.
  // execCommand also fires a native 'input' event (keeps preview + autosave).
  el.setSelectionRange(start, pos);
  let done = false;
  try { done = document.execCommand("insertText", false, insert); }
  catch (err) { done = false; }
  if (!done) {
    // Fallback (no execCommand): still works, just not natively undoable.
    el.value = el.value.slice(0, start) + insert + el.value.slice(pos);
    const caret = start + insert.length;
    el.setSelectionRange(caret, caret);
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }
}

/* ---- feature switches (Settings > Features drawer) ---------------------- */
// Off features are hidden by a body class (styles.css) and refused by the
// server; this copy only decides what the page offers. Changing them needs the
// owner password, which is set outside the app (tools/owner-tools.bat).
let FEATURES = {};
let featureInfo = { list: [], owner_set: false, overridden: false };
const featureOn = (key) => FEATURES[key] !== false;

function applyFeatures(data) {
  const before = { ...FEATURES };
  featureInfo = data || featureInfo;
  FEATURES = (data && data.features) || {};
  for (const [key, on] of Object.entries(FEATURES)) {
    document.body.classList.toggle(`feat-off-${key}`, !on);
  }
  featuresLoaded = true;
  renderFeatures();
  renderIntegrations();
  if (before.photos === false && FEATURES.photos) loadPhotos();
}

/* ---- integration drawers ---------------------------------------------------
   Settings stays one page with no tabs: each integration's setup lives in a
   drawer that slides over whatever page is showing (index.html, INTEGRATION
   DRAWERS). It opens from its Settings tile, from the sidebar's Connections
   list, from a lapsed-sign-in error mid-note, or from ?open=<name> - never by
   switching page, so the note in hand and the layout under it stay put. One
   drawer at a time; edits not yet saved are confirmed before they are lost. */
let openDrawerName = null;
let drawerOpener = null; // focus goes back here on close
const dirtyDrawers = new Set();
const DRAWER_MS = 260; // a touch over the slide in styles.css

const drawerEl = (name) => document.querySelector(`.drawer[data-drawer="${name}"]`);
const drawerDirty = (name) => dirtyDrawers.has(name);
function markDrawerClean(name) { dirtyDrawers.delete(name); }

function drawerFocusables(el) {
  return [...el.querySelectorAll(
    "button, input, select, textarea, summary, [href], [tabindex]:not([tabindex='-1'])")]
    .filter((x) => !x.disabled && x.offsetParent !== null);
}

async function openDrawer(name, opener) {
  const el = drawerEl(name);
  if (!el) return;
  if (el.dataset.feature && !featureOn(el.dataset.feature)) return;
  if (openDrawerName === name) return;
  if (openDrawerName && !(await closeDrawer())) return;

  drawerOpener = opener || document.activeElement;
  openDrawerName = name;
  markDrawerClean(name);
  // Show what is saved now - not edits abandoned the last time it was open.
  if (name === "features") {
    $("feat-pw").value = "";
    renderFeatures();
  } else if (settingsCache && DRAWER_FILLERS[name]) {
    DRAWER_FILLERS[name](settingsCache);
  }

  const backdrop = $("drawer-backdrop");
  backdrop.classList.remove("hidden");
  el.classList.remove("hidden");
  el.scrollTop = 0;
  void el.offsetWidth; // start the slide from off-screen
  backdrop.classList.add("open");
  el.classList.add("open");
  document.body.classList.add("drawer-open");
  const first = drawerFocusables(el.querySelector(".drawer-body"))[0] ||
    el.querySelector("[data-drawer-close]");
  if (first) first.focus({ preventScroll: true });

  // Then refresh from the server: statuses, and the fields if still untouched.
  if (name === "features") loadFeatures();
  else loadSettings();
}

// Resolves false if the user chose to keep editing.
async function closeDrawer(force = false) {
  const name = openDrawerName;
  if (!name) return true;
  if (!force && drawerDirty(name)) {
    const ok = await confirmModal("Close without saving?",
      "The changes in this panel haven't been saved and will be lost.", "Discard changes");
    if (!ok) return false;
  }
  markDrawerClean(name);
  openDrawerName = null;
  const el = drawerEl(name);
  const backdrop = $("drawer-backdrop");
  el.classList.remove("open");
  backdrop.classList.remove("open");
  document.body.classList.remove("drawer-open");
  setTimeout(() => {
    if (openDrawerName !== name) el.classList.add("hidden");
    if (!openDrawerName) backdrop.classList.add("hidden");
  }, DRAWER_MS);
  if (name === "features") { $("feat-pw").value = ""; featMessage(""); }
  if (drawerOpener && document.contains(drawerOpener)) drawerOpener.focus({ preventScroll: true });
  drawerOpener = null;
  return true;
}

function initDrawers() {
  // Anything marked data-open-drawer opens one: tiles, the Features button,
  // and the Connections rows (rendered later, hence the delegation).
  document.addEventListener("click", (e) => {
    const t = e.target.closest("[data-open-drawer]");
    if (t) { e.preventDefault(); openDrawer(t.dataset.openDrawer, t); }
  });
  document.querySelectorAll(".drawer").forEach((el) => {
    const name = el.dataset.drawer;
    el.addEventListener("click", (e) => {
      if (e.target.closest("[data-drawer-close]")) closeDrawer();
    });
    // Any edit makes the drawer dirty until it is saved. The owner password
    // alone is not worth a "discard?" prompt.
    const touch = (e) => {
      if (e.target.id === "feat-pw" || e.target.closest("[data-no-dirty]")) return;
      dirtyDrawers.add(name);
    };
    el.addEventListener("input", touch);
    el.addEventListener("change", touch);
  });
  on("drawer-backdrop", "click", () => closeDrawer());

  document.addEventListener("keydown", (e) => {
    if (!openDrawerName) return;
    // A dialog on top (the discard confirm) handles its own keys - including
    // the Escape that just closed it, which must not close the drawer too.
    if (e.defaultPrevented || !$("modal").classList.contains("hidden")) return;
    const el = drawerEl(openDrawerName);
    if (e.key === "Escape") {
      e.preventDefault();
      closeDrawer();
    } else if (e.key === "Tab") {
      // Keep focus inside the drawer; the page behind is under the backdrop.
      const items = drawerFocusables(el);
      if (!items.length) return;
      const first = items[0], last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      else if (!el.contains(document.activeElement)) { e.preventDefault(); first.focus(); }
    }
  });
}

/* ---- integration status: Settings tiles, drawer headers, Connections ------
   One reading of each integration's health, shown in three places with the
   same dot and words. `live` decides the sidebar: only what is set up and
   switched on appears there, so a PC that uses none of them shows nothing. */
const INTEGRATIONS = [
  { key: "calls", name: "CXone MAX" },
  { key: "d365", name: "Dynamics 365" },
  { key: "sheet", name: "Google Sheets" },
];
// The sheet is only read on a lookup or a Test, so its health is whatever the
// last of those found: { rows } after a good Test, { error } after a failure.
let sheetHealth = null;
let featuresLoaded = false;

function integrationStatus(key) {
  const s = settingsCache || {};
  if (key === "calls") {
    const w = callWatch || s.call_watch;
    if (!w) return { state: "busy", text: "Checking…", short: "Checking", live: false };
    const st = w.state || "off";
    if (st === "unsupported") {
      return { state: "off", text: "Needs Windows - the screen pop still works", short: "Off", live: false };
    }
    if (st === "off") return { state: "off", text: "Off", short: "Off", live: false };
    if (st === "starting") return { state: "busy", text: "Starting the window reader…", short: "Starting", live: true };
    if (st === "error") return { state: "warn", text: "The window reader stopped - open for details", short: "Stopped", live: true };
    const n = w.windows || 0;
    return n
      ? { state: "ok", text: `Listening - reading ${n} MAX window${n === 1 ? "" : "s"}`, short: "Listening", live: true }
      : { state: "warn", text: "Running, but no MAX window is open", short: "No window", live: true };
  }
  if (key === "d365") {
    const d = d365State || {};
    if (!d.configured) return { state: "off", text: "Not set up", short: "Not set up", live: false };
    if (!d.signed_in) {
      return { state: "warn", text: "Signed out - New D365 Case opens the browser form", short: "Signed out", live: true };
    }
    return { state: "ok", text: `Signed in${d.user ? " as " + d.user : ""}`, short: "Signed in", live: true };
  }
  if (key === "sheet") {
    const n = (s.sheet_sources || []).filter((x) => x.url).length;
    if (!n) return { state: "off", text: "Not set up", short: "Not set up", live: false };
    if (sheetHealth && sheetHealth.error) {
      return { state: "warn", text: `Can't read the sheet: ${sheetHealth.error}`, short: "Can't read", live: true };
    }
    return { state: "ok", text: n > 1 ? `${n} sheets linked` : (sheetHealth && sheetHealth.rows ? `Linked - ${sheetHealth.rows} rows` : "Linked"),
             short: "Linked", live: true };
  }
  return { state: "off", text: "", short: "", live: false };
}

function renderIntegrations() {
  for (const { key } of INTEGRATIONS) {
    const st = integrationStatus(key);
    document.querySelectorAll(`[data-integ-status="${key}"]`).forEach((el) => {
      el.dataset.state = st.state;
      el.querySelector(".integ-state").textContent = st.text;
      el.title = st.text;
    });
  }
  // The panel goes only when every integration in it is switched off.
  const panel = $("integrations-panel");
  if (panel) panel.classList.toggle("hidden", !INTEGRATIONS.some(({ key }) => featureOn(key)));
  renderConnections();
}

function renderConnections() {
  const box = $("conn");
  const list = $("conn-list");
  if (!box || !list) return;
  // Until the feature switches are known, an off feature could flash in.
  const rows = !featuresLoaded ? [] : INTEGRATIONS
    .filter(({ key }) => featureOn(key))
    .map((i) => ({ ...i, st: integrationStatus(i.key) }))
    .filter((i) => i.st.live);
  box.classList.toggle("hidden", !rows.length);
  // Rebuilt only when something changed, so a status poll never drops the
  // hover or keyboard focus on a row.
  const sig = JSON.stringify(rows.map((r) => [r.key, r.st.state, r.st.text]));
  if (list.dataset.sig === sig) return;
  list.dataset.sig = sig;
  list.innerHTML = rows.map((r) =>
    `<button type="button" class="conn-item" data-open-drawer="${r.key}" data-state="${r.st.state}"` +
    ` title="${escapeHtml(`${r.name}: ${r.st.text}`)}">` +
    `<span class="dot"></span><span class="conn-name">${escapeHtml(r.name)}</span>` +
    `<span class="conn-state">${escapeHtml(r.st.short)}</span></button>`).join("");
}

function renderFeatures() {
  const list = $("feat-list");
  if (!list) return;
  const owner = !!featureInfo.owner_set;
  $("btn-save-features").classList.toggle("hidden", !owner);
  if (!drawerDirty("features")) list.innerHTML = (featureInfo.list || []).map((f) =>
    `<label class="feat-item${owner ? "" : " locked"}">` +
    `<span class="feat-text"><span class="feat-label">${escapeHtml(f.label)}</span>` +
    `<span class="feat-desc">${escapeHtml(f.description)}</span></span>` +
    `<input type="checkbox" class="switch" data-feat="${escapeHtml(f.key)}"` +
    `${FEATURES[f.key] !== false ? " checked" : ""}${owner ? "" : " disabled"}></label>`).join("");
  $("feat-lock").textContent = !owner ? "No owner password in this build"
    : featureInfo.overridden ? "Locked - set for this PC" : "Locked - office defaults";
  $("feat-controls").classList.toggle("hidden", !owner);
  $("btn-feat-reset").classList.toggle("hidden", !featureInfo.overridden);
  const restart = $("feat-restart");
  restart.classList.toggle("hidden", !featureInfo.restart_needed);
  restart.textContent = featureInfo.restart_needed
    ? `TickAssist was updated while it was running (still running ${featureInfo.running_version}). ` +
      "Close the TickAssist window and start it again with run.bat before changing features."
    : "";
}

function featMessage(text, kind) {
  const el = $("feat-msg");
  el.textContent = text || "";
  el.className = `feat-msg${kind ? " " + kind : ""}${text ? "" : " hidden"}`;
}

async function loadFeatures() {
  try { applyFeatures(await api("GET", "/api/features")); }
  catch (err) { featuresLoaded = true; renderIntegrations(); /* older server */ }
}

async function saveFeatures(reset) {
  const password = $("feat-pw").value;
  if (!password) return featMessage("Enter the owner password.", "error");
  featMessage("Saving...");
  const body = { password };
  if (reset) {
    body.reset = true;
  } else {
    body.features = {};
    document.querySelectorAll("#feat-list [data-feat]").forEach((cb) => {
      body.features[cb.dataset.feat] = cb.checked;
    });
  }
  try {
    await api("POST", "/api/features", body);
    $("feat-pw").value = "";
    markDrawerClean("features");
    // Reload so every feature starts up the way it does on a fresh launch -
    // D365, photos and incoming calls all set themselves up at page load.
    sessionStorage.setItem("tickassist_feat_saved",
      reset ? "This PC now follows the office defaults" : "Features saved");
    featMessage("Saved - reloading...", "done");
    setTimeout(() => {
      location.href = location.pathname + "?page=settings&open=features";
    }, 400);
  } catch (err) {
    featMessage(err.message, "error");
    showToast(err.message, "red");
  }
}

function initFeatures() {
  const saved = sessionStorage.getItem("tickassist_feat_saved");
  if (saved) {
    sessionStorage.removeItem("tickassist_feat_saved");
    showToast(saved, "green");
    featMessage(saved + ".", "done");
  }
  on("btn-save-features", "click", () => saveFeatures(false));
  on("btn-feat-reset", "click", () => saveFeatures(true));
  on("feat-pw", "keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); saveFeatures(false); } });
  return loadFeatures();
}

/* ---- wiring ------------------------------------------------------------- */
// No browser autofill or form history in any field: a ticket form is not a
// login or address form, and a suggestion from another field (or another
// call) landing in a note is worse than no suggestion at all.
function disableBrowserAutofill() {
  document.querySelectorAll("input, textarea").forEach((el) => {
    if (el.type === "file" || el.type === "checkbox" || el.type === "radio") return;
    el.setAttribute("autocomplete", "off");
    el.setAttribute("data-lpignore", "true");
    el.setAttribute("data-1p-ignore", "");
  });
}

/* ---- Google Sheet lookup ------------------------------------------------- */
// Typing an Imaging Package number looks it up (server-side, sheets.py) in the
// shared Google Sheet and fills the other fields from that row. By default only
// empty fields are filled, so nothing the user typed is overwritten. Found rows
// fill quietly while typing; "not in the sheet" is only reported once the field
// is left, so half-typed numbers don't nag.
let sheetTimers = {};
let sheetToken = {};
let sheetLast = {};   // lookup field -> the value last looked up

function setFieldFromSheet(id, value, overwrite) {
  const el = $(id);
  if (!el || !value) return false;
  if (el.value.trim() && !overwrite) return false;
  if (el.tagName === "SELECT") {
    const opt = [...el.options].find((o) =>
      o.value.toLowerCase() === value.toLowerCase() || o.text.toLowerCase() === value.toLowerCase());
    if (!opt || el.value === opt.value) return false;
    el.value = opt.value;
  } else {
    if (el.value === value) return false;
    el.value = value;
  }
  el.dispatchEvent(new Event("input", { bubbles: true }));
  return true;
}

// Put one sheet row's values into the form; returns the labels of what changed.
function applySheetValues(values, overwrite, keyId = "imagingPackage") {
  const filled = [];
  for (const [field, value] of Object.entries(values || {})) {
    const id = FIELD_MAP[field];
    if (!id || id === keyId) continue;
    // The dealer box only exists for a Dealer contact; don't fill what's hidden.
    if (field === "dealer_name" && getVal("contactType") !== "Dealer") continue;
    if (setFieldFromSheet(id, value, overwrite)) {
      const el = $(id);
      filled.push((el && el.placeholder) || id);
    }
  }
  if (filled.length) { update(); revealEnvIfFilled(); renderEnvSummary(); }
  return filled;
}

// The same package number can sit in more than one section of the sheet (e.g.
// Promax packages at the top and a "Viso Package" block lower down). The row
// that fits the Device Type is used; the others are offered under the field.
let sheetAlts = [];
// A Device Type that already names the product line (Promax / Viso) has settled
// which section applies, so the offer stays out of the way.
const sheetDeviceSettled = () => /promax|viso/i.test(getVal("deviceType"));

function renderSheetAlternatives(alts) {
  if (alts !== undefined) sheetAlts = alts || [];
  const box = $("sheet-alt");
  if (!box) return;
  box.textContent = "";
  const show = sheetAlts.length && !sheetDeviceSettled();
  box.classList.toggle("hidden", !show);
  if (!show) return;
  sheetAlts.forEach((alt) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn small";
    btn.textContent = `Use ${alt.section}`;
    btn.title = `Same number found in "${alt.section}" (sheet row ${alt.row}) - fill from that row instead`;
    btn.addEventListener("click", () => {
      const filled = applySheetValues(alt.values, true);
      showToast(filled.length ? `Filled from ${alt.section}: ${filled.join(", ")}`
                              : `Nothing to change from ${alt.section}`, "indigo");
      sheetRow = { key: getVal("imagingPackage"), section: alt.section, values: alt.values || {} };
      applySheetCheck();
      renderSheetAlternatives([]);
    });
    box.appendChild(btn);
  });
}

// Which TickAssist fields a sheet can be looked up by. Each sheet in Settings
// picks one; typing in that field reads every sheet keyed by it.
const SHEET_KEY_FIELDS = [
  ["imaging_package", "Imaging Package"], ["serial_number", "Serial Number"],
  ["device_type", "Device Type"], ["case_number", "Case ID"], ["phone", "Phone"],
  ["dealer_name", "Dealer"], ["contact", "Contact"],
];
const sheetKeyLabel = (f) => (SHEET_KEY_FIELDS.find((x) => x[0] === f) || [f, f])[1];
const sheetSourcesList = () => (settingsCache && settingsCache.sheet_sources) || [];

async function sheetLookup(announceMiss, checkOnly = false, field = "imaging_package") {
  if (!featureOn("sheet")) return;
  const id = FIELD_MAP[field];
  const isPkg = field === "imaging_package";
  const key = getVal(id);
  const label = sheetKeyLabel(field);
  if (!sheetSourcesList().some((s) => s.key_field === field && s.url)) {
    if (isPkg) { sheetRow = null; applySheetCheck(); renderSheetAlternatives([]); }
    return;
  }
  if (key.length < 2) {
    sheetLast[field] = "";
    if (isPkg) { sheetRow = null; applySheetCheck(); renderSheetAlternatives([]); }
    return;
  }
  if (!checkOnly && key === sheetLast[field] && !announceMiss) return;
  const token = (sheetToken[field] = (sheetToken[field] || 0) + 1);
  let res;
  try {
    res = await api("GET", `/api/sheet/lookup?field=${field}&key=${encodeURIComponent(key)}` +
      "&prefer=" + encodeURIComponent(getVal("deviceType")));
  } catch (err) {
    if (checkOnly) return;
    if (token === sheetToken[field] && key !== sheetLast[field]) showToast("Sheet lookup: " + err.message, "red");
    sheetLast[field] = key;
    sheetHealth = { error: err.message };
    renderIntegrations();
    return;
  }
  if (token !== sheetToken[field] || key !== getVal(id)) return; // typed on since
  if (!res.configured) return;
  sheetLast[field] = key;
  if (sheetHealth && sheetHealth.error) { sheetHealth = null; renderIntegrations(); }
  const results = res.results || [];
  const found = results.filter((r) => r.found);
  const first = found[0];
  if (isPkg) {
    sheetRow = first ? { key, section: first.section, values: first.values || {} } : null;
    applySheetCheck();
  }
  if (checkOnly) return;   // reopened note: compare only, fill nothing
  if (isPkg) renderSheetAlternatives(first ? first.alternatives : []);
  results.filter((r) => r.error).forEach((r) => showToast(`${r.source}: ${r.error}`, "red"));
  if (!found.length) {
    if (announceMiss) showToast(`${label} ${key} isn't in the sheet${results.length > 1 ? "s" : ""}`, "amber");
    return;
  }
  const filled = [], names = [];
  found.forEach((r) => {
    const f = applySheetValues(r.values, r.overwrite, id);
    if (f.length) { filled.push(...f); names.push(r.source); }
  });
  if (!filled.length) {
    if (announceMiss) showToast(`${label} ${key}: nothing new to fill from the sheets`, "indigo");
    return;
  }
  const more = isPkg && first && (first.alternatives || []).length
    ? " - also found in another section, see the button by the OS options" : "";
  showToast(`Filled from ${names.join(" + ")} (${key}): ${[...new Set(filled)].join(", ")}${more}`, "indigo");
}

/* ---- the sheet list in Settings --------------------------------------------- */
function renderSheetSources(list) {
  const box = $("sheet-sources");
  if (!box) return;
  if (!list.length) { box.innerHTML = '<div class="empty">No sheets yet. Add one below.</div>'; return; }
  box.innerHTML = list.map((s, i) => `
    <div class="sheet-src" data-idx="${i}">
      <div class="sheet-src-head">
        <input class="input ss-name" type="text" placeholder="Name (e.g. Imaging packages)" value="${escapeHtml(s.name)}" autocomplete="off">
        <button class="btn small ss-del" type="button" title="Remove this sheet">Remove</button>
      </div>
      <label class="label">Sheet link</label>
      <input class="input ss-url" type="text" placeholder="https://docs.google.com/spreadsheets/d/..." value="${escapeHtml(s.url)}" autocomplete="off" spellcheck="false">
      <div class="sheet-src-row">
        <div><label class="label">Look it up by this field</label>
          <select class="select ss-field">${SHEET_KEY_FIELDS.map(([f, l]) =>
            `<option value="${f}"${f === s.key_field ? " selected" : ""}>${l}</option>`).join("")}</select></div>
        <div><label class="label">...which is this sheet column</label>
          <input class="input ss-col" type="text" placeholder="${escapeHtml(sheetKeyLabel(s.key_field))}" value="${escapeHtml(s.key_column)}" autocomplete="off"></div>
      </div>
      <label class="label">Column mapping (optional)</label>
      <textarea class="textarea mono small ss-map" rows="3" spellcheck="false" placeholder="Sheet column = TickAssist field, one per line&#10;Windows = os_version">${escapeHtml(s.map)}</textarea>
      <label class="check-row"><input type="checkbox" class="ss-over"${s.overwrite ? " checked" : ""}>
        <span>Replace fields that already have text (default: only fill empty ones)</span></label>
      <div class="btn-row"><button class="btn small ss-test" type="button">Test</button></div>
      <div class="cw-status hidden ss-status" role="status"></div>
    </div>`).join("");
}

function collectSheetSources() {
  return [...document.querySelectorAll("#sheet-sources .sheet-src")].map((c) => ({
    name: c.querySelector(".ss-name").value.trim(),
    url: c.querySelector(".ss-url").value.trim(),
    key_field: c.querySelector(".ss-field").value,
    key_column: c.querySelector(".ss-col").value.trim(),
    map: c.querySelector(".ss-map").value,
    overwrite: c.querySelector(".ss-over").checked,
  }));
}

function initSheet() {
  // Typing Promax/Viso in Device Type hides the offer; clearing it brings it back.
  on("deviceType", "input", () => renderSheetAlternatives());
  // Every field a sheet can be keyed by watches for typing; sheetLookup does
  // nothing unless a sheet is keyed by that field.
  SHEET_KEY_FIELDS.forEach(([field]) => {
    const box = $(FIELD_MAP[field]);
    if (!box) return;
    box.addEventListener("input", () => {
      if (field === "imaging_package") {
        sheetRow = null; applySheetCheck();   // the old row no longer applies
        renderSheetAlternatives([]);
      }
      clearTimeout(sheetTimers[field]);
      sheetTimers[field] = setTimeout(() => sheetLookup(false, false, field), 700);
    });
    box.addEventListener("change", () => { clearTimeout(sheetTimers[field]); sheetLookup(true, false, field); });
  });
  on("btn-sheet-save", "click", saveSheetSettings);
  on("btn-sheet-add", "click", () => {
    const list = collectSheetSources();
    list.push({ name: "", url: "", key_field: "imaging_package", key_column: "", map: "", overwrite: false });
    renderSheetSources(list);
    dirtyDrawers.add("sheet");
    const cards = document.querySelectorAll("#sheet-sources .ss-name");
    if (cards.length) cards[cards.length - 1].focus();
  });
  const list = $("sheet-sources");
  if (list) {
    list.addEventListener("change", (e) => {
      if (!e.target.classList.contains("ss-field")) return;
      e.target.closest(".sheet-src").querySelector(".ss-col").placeholder = sheetKeyLabel(e.target.value);
    });
    list.addEventListener("click", async (e) => {
      const card = e.target.closest(".sheet-src");
      if (!card) return;
      if (e.target.closest(".ss-del")) {
        const idx = Number(card.dataset.idx);
        const all = collectSheetSources();
        all.splice(idx, 1);
        renderSheetSources(all);
        dirtyDrawers.add("sheet");
        return;
      }
      if (!e.target.closest(".ss-test")) return;
      const out = card.querySelector(".ss-status");
      const src = collectSheetSources()[Number(card.dataset.idx)];
      const ofSaved = !drawerDirty("sheet");
      out.classList.remove("hidden");
      out.dataset.state = "";
      out.textContent = "Reading the sheet...";
      try {
        const r = await api("POST", "/api/sheet/test", {
          sheet_url: src.url,
          sheet_key_column: src.key_column || sheetKeyLabel(src.key_field),
          sheet_map: src.map,
        });
        const mapped = r.mapped.map((m) => `${m.column} → ${m.field}`).join(", ") || "none";
        const secs = (r.sections || []).map((x) => `${x.name} (${x.rows})`).join(", ");
        out.textContent = `Connected: ${r.rows} rows${secs ? " in " + secs : ""}, key column "${r.key_column}". ` +
          `Mapped: ${mapped}.` + (r.unmapped.length ? ` Not used: ${r.unmapped.join(", ")}.` : "");
        out.dataset.state = "running";
        if (ofSaved) { sheetHealth = { rows: r.rows }; renderIntegrations(); }
      } catch (err) {
        out.dataset.state = "error";
        out.textContent = err.message;
        if (ofSaved) { sheetHealth = { error: err.message }; renderIntegrations(); }
      }
    });
  }
  on("sheet-check", "click", (e) => {
    if (!e.target.closest("[data-sheet-fix]") || !sheetRow) return;
    const values = {};
    sheetMismatches().forEach((m) => { values[m.field] = m.want; });
    const filled = applySheetValues(values, true);
    showToast(filled.length ? `Set from the sheet: ${filled.join(", ")}` : "Nothing to change", "indigo");
  });
}

/* ---- program updates -------------------------------------------------------- */
let updateChecked = false;
let updateInfo = null;

function updStatus(text, state) {
  const out = $("upd-status");
  if (!out) return;
  out.classList.toggle("hidden", !text);
  out.dataset.state = state || "";
  out.textContent = text || "";
}

async function checkUpdates(silent) {
  if (!silent) updStatus("Checking...", "");
  try {
    updateInfo = await api("GET", "/api/update/check");
  } catch (err) {
    if (!silent) updStatus(err.message, "error");
    return;
  }
  const newer = updateInfo.newer && !updateInfo.restart_needed;
  $("update-chip").classList.toggle("hidden", !newer);
  $("btn-upd-install").classList.toggle("hidden", !newer);
  if (newer) {
    $("update-chip").textContent = `Update ${updateInfo.latest} available`;
    $("btn-upd-install").textContent = `Install ${updateInfo.latest} and restart`;
  }
  if (!silent || newer) {
    updStatus(newer
      ? `Version ${updateInfo.latest} is available (you have ${updateInfo.current}).${updateInfo.notes ? " " + updateInfo.notes : ""}`
      : `You're up to date (version ${updateInfo.current}).`, newer ? "" : "running");
  }
}

async function installUpdate() {
  if (!updateInfo || !updateInfo.newer) return;
  if (!confirm(`Update TickAssist to ${updateInfo.latest}?\n\nIt will restart in a few seconds. ` +
               `Your settings, lists and macros are kept.`)) return;
  updStatus("Downloading and installing...", "");
  try {
    saveFormState();
    await api("POST", "/api/update/apply", {});
    updStatus("Installed. Restarting...", "running");
    await api("POST", "/api/update/restart", {});
  } catch (err) {
    updStatus(err.message, "error");
    showToast(err.message, "red");
    return;
  }
  // The old copy is closing and the new one is starting; reload when it answers.
  const started = Date.now();
  const wait = async () => {
    try {
      const h = await fetch("/api/health", { cache: "no-store" });
      const j = await h.json();
      if (j.running_version && j.running_version !== updateInfo.current) { location.reload(); return; }
    } catch (e) { /* still restarting */ }
    if (Date.now() - started < 45000) setTimeout(wait, 1000);
    else updStatus("TickAssist didn't come back by itself - start it again from its shortcut.", "error");
  };
  setTimeout(wait, 2500);
}

function initUpdates() {
  on("btn-upd-save", "click", async () => {
    try {
      await api("POST", "/api/settings", { update_url: getVal("upd-url") });
      showToast("Update address saved", "green");
      await checkUpdates(false);
    } catch (err) { updStatus(err.message, "error"); }
  });
  on("btn-upd-check", "click", () => checkUpdates(false));
  on("btn-upd-install", "click", installUpdate);
  on("update-chip", "click", installUpdate);
}

function init() {
  disableBrowserAutofill();
  initTheme();
  on("theme-picker", "click", (e) => {
    const b = e.target.closest(".theme-option");
    if (b) applyTheme(b.dataset.theme);
  });
  // Topbar quick toggle: flips the resolved theme to an explicit light/dark.
  on("btn-theme-quick", "click", () =>
    applyTheme(resolveTheme(themePref) === "dark" ? "light" : "dark"));

  // Suppress the browser's saved-info / autofill dropdowns on ticket fields
  // (Edge matches labels like "Contact Name" and offers profile data).
  document.querySelectorAll(".form-panel input").forEach((el) =>
    el.setAttribute("autocomplete", "off"));
  // Edge ignores "off" for name/phone profile autofill specifically;
  // "one-time-code" is the token browsers reliably honor as an opt-out.
  ["contact", "phone"].forEach((id) => {
    const el = $(id);
    if (el) el.setAttribute("autocomplete", "one-time-code");
  });

  if ($("dateTime")) $("dateTime").value = new Date().toLocaleString();
  // The standing rotation loads before the draft, which may override it for
  // this one note (see restoreFormState).
  ensureVersionBadge();
  initCallType();
  initLcarsExtras();
  initSettingsTabs();
  initTransfer();
  initRequired();
  initFiMore();
  initEnvCollapsed();
  on("env-toggle", "click", () =>
    setEnvCollapsed(!$("env-section").classList.contains("collapsed")));
  // Restore any in-progress entry from a previous (possibly crashed) session.
  restoreFormState();

  // The First Impressions handle timer ticks once a second; renderFiTimer is
  // cheap and hides itself off-rotation, so the interval just always runs.
  renderFiTimer();
  setInterval(renderFiTimer, 1000);

  // Navbar.
  document.querySelectorAll(".nav-item").forEach((b) =>
    b.addEventListener("click", () => switchPage(b.dataset.page)));

  // Live preview listeners.
  document.querySelectorAll(".form-panel input, .form-panel textarea, .form-panel select")
    .forEach((el) => {
      el.addEventListener("input", update);
      el.addEventListener("input", fiTimerOnInput);
    });
  document.querySelectorAll('input[name="os"]')
    .forEach((r) => r.addEventListener("change", update));
  ["deviceType", "problem", "serialNumber"].forEach((id) =>
    on(id, "input", autoGenerateTitle));

  // Reflow inline "* " bullets onto separate lines when leaving Troubleshooting
  // / Next Steps (typed or pasted text never hits the server-side polish pass).
  ["workflow", "nextSteps"].forEach((id) =>
    on(id, "blur", () => { normalizeBulletField(id); update(); }));

  on("caseNumber", "input", () => {
    const el = $("caseNumber");
    const fixed = el.value.replace(/^\s*CAS[\s-]*CAS/i, "CAS");
    if (fixed !== el.value) { el.value = fixed; update(); }
  });

  // Double-click the (read-only) timestamp to reset it to the current time.
  // That gesture marks the start of a call, so it also arms the handle timer
  // (the programmatic refresh in resetFields deliberately does not).
  on("dateTime", "dblclick", () => { startFiTimer(true); refreshTimestamp(true); });

  // Double-click the timer box to zero it, mirroring the timestamp gesture.
  // If the note already holds anything the count restarts from now; on an
  // empty note it just goes idle at 00:00 (and disarms a dbl-click start).
  on("fi-timer", "dblclick", () => {
    resetFiTimer();
    if (isFormDirty()) startFiTimer(false);
    scheduleFormSave();
    showToast("Timer reset");
  });

  // A hand pick of Contact Type is the user's word on it for this note; a
  // known caller's previous type never replaces it.
  on("contactType", "change", (e) => { if (e.isTrusted) contactTypePicked = true; });

  // Live phone-number formatting (###-###-####).
  on("phone", "input", () => {
    const el = $("phone");
    el.value = formatPhone(el.value);
    update();
    checkRepeatCaller();
  });
  // Jump to this caller's history in the repository.
  on("repeat-caller", "click", (e) => {
    if (e.target.closest("[data-repeat-dismiss]")) {
      repeatDismissedDigits = getVal("phone").replace(/\D/g, "");
      return clearRepeatCaller();
    }
    const btn = e.target.closest("[data-repeat-phone]");
    if (!btn) return;
    $("ticket-search").value = btn.dataset.repeatPhone;
    $("ticket-call-filter").value = "";
    $("ticket-status-filter").value = "";
    $("ticket-type-filter").value = "";
    switchPage("database");
  });

  // Generator buttons (all null-safe so removing one can't break the rest).
  on("btn-polish", "click", aiPolish);
  on("btn-polish-undo", "click", undoPolish);
  on("btn-save", "click", (e) => saveTicket(false, e.shiftKey));
  on("btn-import", "click", importNote);
  on("btn-copy", "click", copyNote);
  on("btn-copy-title", "click", () => {
    const t = getVal("caseTitle");
    if (!t) { showToast("No title to copy", "red"); return; }
    copyText(t, "Title copied!");
  });
  on("btn-new-d365-case", "click", (e) =>
    (featureOn("d365") && d365State.signed_in ? openD365Create() : openNewD365Case(e.shiftKey)));
  on("btn-clear", "click", clearFields);

  // Edit-mode banner (shown while a saved ticket is open in the generator).
  on("btn-save-as-new", "click", (e) => saveTicket(true, e.shiftKey));
  // X cancels the edit session entirely: banner closes, form resets to blank.
  on("btn-stop-editing", "click", () => {
    resetFields();
    showToast("Stopped editing — form cleared", "slate");
  });

  // Typeable dropdowns backed by managed lists.
  LISTS.dealers.combo = createCombobox("dealerName", "dealer-menu", "dealers", update);
  LISTS.device_types.combo = createCombobox("deviceType", "deviceType-menu", "device_types", autoGenerateTitle);
  LISTS.reco_units.combo = createCombobox("recoPc", "recoPc-menu", "reco_units", update);
  Object.entries(ENV_COMBOS).forEach(([key, [id]]) => {
    const onChoose = id === "imagingPackage"
      ? () => { update(); const el = $(id); el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); }
      : update;
    // OS versions follow the systems ticked: Windows 10/11, Server 20xx, macOS names.
    LISTS[key].combo = createCombobox(id, id + "-menu", key, onChoose, key === "os_versions" ? osVersionsForChecked : undefined);
  });
  document.querySelectorAll('input[name="os"]').forEach((c) => c.addEventListener("change", () => { if (LISTS.os_versions.combo) LISTS.os_versions.combo.render(); }));
  initListedFields();

  // Rotation toggles. Flipping either while a saved ticket is open retags only
  // that ticket; with no ticket open, the topbar one moves the standing
  // rotation everything starts from. Both copies share this handler so they
  // can never disagree.
  const onRotationClick = (e) => {
    const opt = e.target.closest("[data-call-type]");
    if (!opt || opt.dataset.callType === callType) return;
    setCallType(opt.dataset.callType, !editing);
    update();
    showToast(editing
      ? `This ticket is now a ${opt.dataset.callType} call`
      : `Rotation set to ${opt.dataset.callType}`, "indigo");
  };
  on("call-type-toggle", "click", onRotationClick);
  on("case-call-type-toggle", "click", onRotationClick);

  // Dashboard page: refresh recomputes the stats; the range toggle re-reads
  // the windows already in the payload.
  on("btn-refresh-stats", "click", loadDashboard);
  initTileRange();
  on("tile-range", "click", (e) => {
    const opt = e.target.closest("[data-range]");
    if (opt) { setTileRange(opt.dataset.range); renderRangeToggle(true); }
  });
  buildPanelRangeControls();
  on("dash-content", "click", (e) => {
    const group = e.target.closest("[data-range-for]");
    const opt = e.target.closest("[data-range]");
    if (group && opt) setPanelRange(group.dataset.rangeFor, opt.dataset.range);
  });

  // Database page: refresh refetches; filters/sort re-render the cache.
  on("btn-refresh-tickets", "click", loadTickets);
  on("btn-export-tickets", "click", () => { window.location.href = "/api/tickets/export"; });
  on("ticket-search", "input", renderTickets);
  on("ticket-status-filter", "change", renderTickets);
  on("ticket-type-filter", "change", renderTickets);
  on("ticket-call-filter", "change", renderTickets);
  document.querySelectorAll("#ticket-table thead th[data-sort]").forEach((th) =>
    th.addEventListener("click", () => sortTicketsBy(th.dataset.sort)));
  on("ticket-table", "click", (e) => {
    const open = e.target.closest("[data-load]");
    const copy = e.target.closest("[data-copy]");
    const del = e.target.closest("[data-del]");
    if (open) openTicket(open.dataset.load);
    else if (copy) copyTicketNote(copy.dataset.copy);
    else if (del) deleteTicket(del.dataset.del);
    else {
      const row = e.target.closest("tr[data-id]");
      if (row) viewTicket(row.dataset.id);
    }
  });

  // Note preview modal.
  on("note-modal-close", "click", closeNoteModal);
  on("note-modal", "click", (e) => { if (e.target === $("note-modal")) closeNoteModal(); });
  on("note-modal-open", "click", () => { if (noteModalTicket) openTicket(noteModalTicket.id); });
  on("note-modal-copy", "click", () => {
    if (noteModalTicket) copyText(noteForClipboard(noteModalTicket.note_text || ""), "Note copied!");
  });
  on("note-modal-d365", "click", () => {
    if (noteModalTicket) openInD365(noteModalTicket.case_number);
  });

  // Settings page.
  on("btn-save-settings", "click", saveSettings);
  on("btn-merge-check", "click", checkMerge);
  on("merge-path", "keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); checkMerge(); } });
  // Typing a path and picking a file are alternatives, not both at once.
  on("merge-path", "input", () => { if (getVal("merge-path")) setMergeFile(null); });

  // File dialog: pick the database directly.
  on("btn-merge-pick-file", "click", () => $("merge-file").click());
  on("merge-file", "change", (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    setMergeFile(file);
    checkMerge();
  });

  // Folder dialog, where the browser supports it: pick the folder, and the
  // database inside it is located without uploading anything else.
  if ("webkitdirectory" in document.createElement("input")) {
    $("btn-merge-pick-folder").classList.remove("hidden");
  }
  on("btn-merge-pick-folder", "click", () => $("merge-folder").click());
  on("merge-folder", "change", (e) => {
    const files = [...(e.target.files || [])];
    if (!files.length) return;
    const match = MERGE_FILENAMES.reduce((found, name) => found ||
      files.find((f) => f.name.toLowerCase() === name), null);
    if (!match) {
      setMergeFile(null);
      renderMergeResult(
        `No TickAssist database in that folder (looked for ` +
        `${MERGE_FILENAMES.map((n) => `<code>${n}</code>`).join(" or ")}).`, "error");
      return;
    }
    setMergeFile(match, match.webkitRelativePath || match.name);
    checkMerge();
  });
  // The Merge button only exists once a check has found something.
  on("merge-result", "click", (e) => {
    if (e.target.closest("#btn-merge-apply")) applyMerge();
  });
  on("llm-provider", "change", () => {
    $("model-help").textContent = MODEL_HINTS[$("llm-provider").value] || "";
  });
  on("btn-lists-import", "click", async () => {
    const btn = $("btn-lists-import"), out = $("lists-import-status");
    btn.disabled = true; out.textContent = "Reading your sheets...";
    try {
      const r = await api("POST", "/api/lists/sync", {});
      out.textContent = r.total ? `Added ${r.total} value${r.total === 1 ? "" : "s"} from your sheets.`
                                : "Everything in your sheets is already on the lists.";
      loadAllLists();
    } catch (err) { out.textContent = err.message; }
    btn.disabled = false;
  });
  // Managed-list panels (dealers / device types / Reco units) - generic wiring.
  document.querySelectorAll("[data-list-addbtn]").forEach((btn) => {
    const key = btn.dataset.listAddbtn;
    const input = document.querySelector(`[data-list-add="${key}"]`);
    const add = async () => {
      if (await addListItem(key, input.value)) { input.value = ""; showToast("Added", "green"); input.focus(); }
    };
    btn.addEventListener("click", add);
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); add(); } });
  });
  document.querySelectorAll("[data-list]").forEach((container) => {
    container.addEventListener("click", (e) => {
      const del = e.target.closest("[data-list-del]");
      if (del) deleteListItem(del.dataset.listDel, del.dataset.id);
    });
  });

  // Macros: add / delete and the global expansion engine.
  on("btn-add-macro", "click", addMacro);
  on("new-macro-trigger", "keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); $("new-macro-expansion").focus(); }
  });
  on("new-macro-expansion", "keydown", (e) => {
    // Enter adds the macro; Shift+Enter inserts a newline.
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); addMacro(); }
  });
  on("new-macro-expansion", "input", autosizeMacroExpansion);
  autosizeMacroExpansion();
  on("macro-list", "click", (e) => {
    const del = e.target.closest("[data-del-macro]");
    if (del) deleteMacro(del.dataset.delMacro);
  });
  // Capture phase so we can pre-empt the terminator keystroke in any field.
  document.addEventListener("keydown", handleMacroKeydown, true);

  // Modal buttons + keyboard (Enter confirms, Escape cancels / closes).
  on("modal-confirm", "click", () => closeModal(true));
  on("modal-cancel", "click", () => closeModal(false));
  on("modal", "click", (e) => { if (e.target === $("modal")) closeModal(false); });
  document.addEventListener("keydown", (e) => {
    const confirmOpen = $("modal") && !$("modal").classList.contains("hidden");
    const noteOpen = $("note-modal") && !$("note-modal").classList.contains("hidden");
    if (confirmOpen) {
      if (e.key === "Enter") { e.preventDefault(); closeModal(true); }
      else if (e.key === "Escape") { e.preventDefault(); closeModal(false); }
    } else if (noteOpen && e.key === "Escape") {
      e.preventDefault();
      closeNoteModal();
    }
  });

  // Global shortcuts: Ctrl+S saves/updates, Ctrl+Enter copies the note.
  // With an integration drawer open, Ctrl+S saves that drawer instead.
  document.addEventListener("keydown", (e) => {
    if (!(e.ctrlKey || e.metaKey)) return;
    const confirmOpen = $("modal") && !$("modal").classList.contains("hidden");
    const anyModalOpen = confirmOpen ||
      ($("note-modal") && !$("note-modal").classList.contains("hidden")) ||
      ($("d365-modal") && !$("d365-modal").classList.contains("hidden")) ||
      !!openDrawerName;
    const onGenerator = $("page-generator").classList.contains("active");
    if (e.key.toLowerCase() === "s") {
      e.preventDefault(); // suppress the browser's save-page dialog everywhere
      if (openDrawerName && !confirmOpen) {
        const save = drawerEl(openDrawerName).querySelector(".drawer-foot .btn.indigo");
        if (save && !save.classList.contains("hidden")) save.click();
      } else if (onGenerator && !anyModalOpen) saveTicket(false);
    } else if (e.key === "Enter" && onGenerator && !anyModalOpen) {
      e.preventDefault();
      // Same as the Copy Note button - photos included when the note has any.
      copyNote();
    }
  });

  // Flush any pending (debounced) autosave before the tab goes away.
  window.addEventListener("beforeunload", saveFormState);

  // Initial load: managed lists for the comboboxes, macros for expansion,
  // settings for the D365 link.
  loadAllLists();
  loadMacros();
  loadSettings();
  update();
  initIncomingCalls();
  initSheet();
  initUpdates();
  initPhotos();
  initD365();
  initDrawers();
  const featuresReady = initFeatures();

  // Deep-linking: /?page=database opens that section directly, and
  // &open=calls|d365|sheet|features slides that drawer in over it once the
  // feature switches are known.
  try {
    const params = new URLSearchParams(location.search);
    const startPage = params.get("page");
    if (["generator", "database", "dashboard", "settings"].includes(startPage)) switchPage(startPage);
    const startDrawer = params.get("open");
    if (startDrawer) featuresReady.then(() => openDrawer(startDrawer));
  } catch (e) { /* no-op */ }
}

/* ---- LCARS extras: incoming-call card and yellow / red alert ------------- */
// Everything here is LCARS-only. On any other theme the card is never built
// and the alert engine clears itself and does nothing.
const isLcars = () => document.documentElement.dataset.theme === "lcars";
const reducedMotion = () => !!(window.matchMedia &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches);

// A made-up but plausible stardate: thousands = years since 2000, the rest is
// how far through the year it is.
function stardate(d = new Date()) {
  const y = d.getFullYear();
  const start = new Date(y, 0, 1);
  const frac = (d - start) / (new Date(y + 1, 0, 1) - start);
  const n = Math.floor(frac * 10000) / 10;
  return `${(y - 2000) * 1000 + Math.floor(n)}.${Math.floor((n % 1) * 10)}`;
}

/* -- Incoming-call card ---------------------------------------------------- */
// Real data (name, class, dealer, last device, last issue, status) comes from
// earlier tickets with this number; the signal readouts are decoration,
// derived from the digits so a given number always reads the same, and the
// card says so. A number with no history gets "NO PRIOR RECORD".
let callCard = null;      // { el, digits, phone, test, type, caseNumber, hist }
let callCardToken = 0;

const CC_ISSUE_MAX = 90;
const ccText = (s) => escapeHtml(String(s || "").trim());

function ccSignal(digits) {
  const n = [...digits].reduce((a, c) => a + Number(c), 0) + digits.length * 3;
  return {
    relay: String(1 + (n % 12)).padStart(2, "0"),
    carrier: 90 + (n % 10),
    channel: `${3 + (n % 7)}.${(n * 7) % 10}`,
  };
}

function ccAge(ts) {
  const t = Date.parse(String(ts || "").replace(" ", "T"));
  if (!t) return "";
  const ago = humanAge(Date.now() - t);
  return ago === "moments" ? "MOMENTS AGO" : `${ago.toUpperCase()} AGO`;
}

function ccHtml(c) {
  const sig = ccSignal(c.digits);
  const h = c.hist;
  const last = h && h.tickets && h.tickets[0];
  const named = h && h.tickets && h.tickets.find((t) => (t.contact || "").trim());
  const rows = [];
  const row = (k, v) => { if (v) rows.push(`<dt>${k}</dt><dd>${v}</dd>`); };
  let badge = "";
  const chips = [];

  if (c.test) {
    badge = `<span class="cc-badge test">TEST TRANSMISSION</span>`;
  } else if (!featureOn("known_caller")) {
    badge = `<span class="cc-badge none">CALLER HISTORY OFF</span>`;
  } else if (h === null) {
    badge = `<span class="cc-badge scan">CROSS-REFERENCING DATABASE&hellip;</span>`;
  } else if (h.count > 0) {
    badge = `<span class="cc-badge known">KNOWN CONTACT</span>`;
  } else {
    badge = `<span class="cc-badge none">NO PRIOR RECORD</span>`;
    chips.push(`<span class="cc-chip ice">FIRST CONTACT</span>`);
  }

  row("CALLER", named ? ccText(named.contact) : "");
  row("CLASS", ccText(c.type || (last && last.contact_type)));
  row("DEALER", last && last.dealer_name ? ccText(last.dealer_name) : "");
  row("CASE", ccText(c.caseNumber));
  if (h && h.count > 0) {
    row("ON FILE", `${h.count} ${h.count === 1 ? "TRANSMISSION" : "TRANSMISSIONS"}` +
      (last ? ` &middot; LAST CONTACT ${ccAge(last.created_at)}` : ""));
    const dev = last && [last.device_type, last.serial_number].filter((x) => (x || "").trim()).join(" ");
    row("LAST DEVICE", ccText(dev));
    if (last && last.res_status) row("LAST STATUS", ccText(normalizeResolutionStatus(last.res_status)).toUpperCase());
    let issue = last ? String(last.problem || last.case_title || "").trim().replace(/\s+/g, " ") : "";
    if (issue.length > CC_ISSUE_MAX) issue = issue.slice(0, CC_ISSUE_MAX - 1).trimEnd() + "\u2026";
    row("LAST ISSUE", issue ? `&ldquo;${ccText(issue)}&rdquo;` : "");

    const t = last && Date.parse(String(last.created_at || "").replace(" ", "T"));
    if (t && Date.now() - t < 7 * 864e5) chips.push(`<span class="cc-chip tan">RETURNED WITHIN 7 DAYS</span>`);
    const st = last ? normalizeResolutionStatus(last.res_status) : "";
    if (st.startsWith("Escalated")) chips.push(`<span class="cc-chip alert">PRIOR CASE ESCALATED</span>`);
    else if (st === "Awaiting Information") chips.push(`<span class="cc-chip tan">AWAITING INFORMATION</span>`);
  }

  const canUse = !c.test && incomingPending && incomingPending.digits === c.digits;
  const canView = h && h.count > 0;
  return `
    <div class="cc-bar">
      <span class="cc-title">INCOMING TRANSMISSION</span>
      <span class="cc-sd">STARDATE ${stardate()}</span>
      <button type="button" class="cc-x" data-cc-close aria-label="Dismiss">&times;</button>
    </div>
    <div class="cc-body">
      <div class="cc-number">${ccText(c.phone)}</div>
      ${badge}
      ${rows.length ? `<dl class="cc-grid">${rows.join("")}</dl>` : ""}
      ${chips.length ? `<div class="cc-chips">${chips.join("")}</div>` : ""}
      <div class="cc-sig" title="Signal readouts are decoration">
        <span>RELAY ${sig.relay}</span><span>CARRIER LOCK ${sig.carrier}%</span><span>CH ${sig.channel}</span>
        <span class="cc-eq" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></span>
      </div>
    </div>
    <div class="cc-foot">
      ${canUse ? `<button type="button" class="btn small indigo" data-cc-use>Use number</button>` : ""}
      ${canView ? `<button type="button" class="btn small" data-cc-view>View history</button>` : ""}
      <button type="button" class="btn small" data-cc-close>Dismiss</button>
      <span class="cc-note">SIGNAL DATA SIMULATED</span>
    </div>
    <div class="cc-drain"><i></i></div>`;
}

function renderCallCard() {
  if (!callCard) return;
  callCard.el.innerHTML = ccHtml(callCard);
  const bar = callCard.el.querySelector(".cc-drain i");
  if (bar) bar.addEventListener("animationend", closeCallCard);
}

function closeCallCard() {
  callCardToken++;
  const c = callCard;
  callCard = null;
  if (!c) return;
  c.el.classList.add("leaving");
  setTimeout(() => c.el.remove(), 260);
}

async function showCallCard(ev, test = false) {
  if (!isLcars() || !ev || !ev.digits) return;
  if (callCard) {
    if (callCard.digits === ev.digits && callCard.test === test) return;  // same call
    callCard.el.remove();
    callCard = null;
  }
  const el = document.createElement("div");
  el.className = "call-card";
  el.setAttribute("role", "status");
  el.setAttribute("aria-label", "Incoming call");
  document.body.appendChild(el);
  callCard = { el, digits: ev.digits, phone: ev.phone || ev.digits, test,
               type: ev.contact_type || "", caseNumber: ev.case_number || "", hist: null };
  const token = ++callCardToken;
  renderCallCard();
  if (test || !featureOn("known_caller")) return;
  try {
    const data = await api("GET", `/api/tickets/callcard?phone=${encodeURIComponent(ev.digits)}`);
    if (!callCard || token !== callCardToken) return;   // closed or replaced
    callCard.hist = { count: data.count || 0, tickets: data.tickets || [] };
  } catch (e) {
    if (!callCard || token !== callCardToken) return;
    callCard.hist = { count: 0, tickets: [] };
  }
  renderCallCard();
}

// MAX can show the skill or case a moment after the number.
function updateCallCard(ev) {
  if (!callCard || callCard.test || callCard.digits !== ev.digits) return;
  if (ev.contact_type) callCard.type = ev.contact_type;
  if (ev.case_number) callCard.caseNumber = ev.case_number;
  renderCallCard();
}

function initCallCard() {
  document.addEventListener("click", (e) => {
    if (!callCard || !callCard.el.contains(e.target)) return;
    if (e.target.closest("[data-cc-close]")) return closeCallCard();
    if (e.target.closest("[data-cc-use]") && incomingPending) {
      fillIncomingPhone(incomingPending.phone, incomingPending.contactType, incomingPending.caseNumber);
      return closeCallCard();
    }
    if (e.target.closest("[data-cc-view]")) {
      $("ticket-search").value = callCard.digits;
      $("ticket-call-filter").value = "";
      $("ticket-status-filter").value = "";
      $("ticket-type-filter").value = "";
      closeCallCard();
      switchPage("database");
    }
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && callCard) closeCallCard();
  });
}

/* -- Yellow / red alert ---------------------------------------------------- */
// Conditions are rules: [yellow|red] when [field] [reaches|is|contains] [value].
// The first match at the highest level wins. Kept in this browser
// (localStorage) like the theme choice, and edited in Settings on LCARS.
const ALERT_KEY = "tickassist_alerts_v1";
const ALERT_PREVIEW_MS = 6000;

const ALERT_FIELDS = {
  handle:      { label: "Handle time (First Impressions)", op: "gte", unit: "min",
                 get: () => (callType === FIRST_IMPRESSIONS && fiTimerStart
                   ? (Date.now() - fiTimerStart) / 60000 : 0) },
  contactType: { label: "Contact Type", op: "is", list: () => selectValues("contactType"), get: () => getVal("contactType") },
  callType:    { label: "Call Type", op: "is", list: () => [FIRST_IMPRESSIONS, TROUBLESHOOTING], get: () => callType },
  resStatus:   { label: "Resolution Status", op: "is", list: () => selectValues("resStatus"), get: () => getVal("resStatus") },
  deviceType:  { label: "Device Type", op: "has", get: () => getVal("deviceType") },
  dealer:      { label: "Dealer", op: "has", get: () => getVal("dealerName") },
  error:       { label: "Error / Log Info", op: "has", get: () => getVal("errorInfo") },
  problem:     { label: "Problem / Request", op: "has", get: () => getVal("problem") },
  workflow:    { label: "Troubleshooting", op: "has", get: () => getVal("workflow") },
  anyText:     { label: "Any note field", op: "has",
                 get: () => ["errorInfo", "partRec", "problem", "workflow", "nextSteps", "outcome"]
                   .map(getVal).join("\n") },
};
const ALERT_OP_LABEL = { gte: "reaches", is: "is", has: "contains" };

const ALERT_DEFAULTS = [
  { level: "yellow", field: "handle", value: "10" },
  { level: "red", field: "handle", value: "15" },
  { level: "red", field: "anyText", value: "smoke, fire, burning, burnt, sparks, sparking, shock, injur*" },
];

function selectValues(id) {
  const el = $(id);
  return el ? [...el.options].map((o) => o.value).filter(Boolean) : [];
}

function loadAlertRules() {
  try {
    const raw = JSON.parse(localStorage.getItem(ALERT_KEY) || "null");
    if (Array.isArray(raw)) {
      return raw.filter((r) => r && ALERT_FIELDS[r.field] && (r.level === "yellow" || r.level === "red"))
                .map((r) => ({ level: r.level, field: r.field, value: String(r.value ?? "") }));
    }
  } catch (e) { /* fall through to the defaults */ }
  return ALERT_DEFAULTS.map((r) => ({ ...r }));
}
function saveAlertRules(rules) {
  try { localStorage.setItem(ALERT_KEY, JSON.stringify(rules)); } catch (e) { /* private mode */ }
}

const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
// Whole words, case-insensitive; a trailing * means "starts with" (injur* ->
// injured). Whole-word matching keeps "fire" from firing on "firewall".
function hasTerm(text, term) {
  const t = term.trim();
  if (!t) return false;
  const prefix = t.endsWith("*");
  const body = escapeRe(prefix ? t.slice(0, -1) : t);
  if (!body) return false;
  return new RegExp(`(^|[^\\p{L}\\p{N}])${body}${prefix ? "" : "(?![\\p{L}\\p{N}])"}`, "iu").test(text);
}

function ruleMatch(r) {
  const f = ALERT_FIELDS[r.field];
  const terms = String(r.value || "").split(",").map((s) => s.trim()).filter(Boolean);
  if (!f || !terms.length) return false;
  const v = f.get();
  if (f.op === "gte") { const n = parseFloat(terms[0]); return Number.isFinite(n) && v >= n; }
  if (f.op === "is") return terms.some((t) => String(v).toLowerCase() === t.toLowerCase());
  return terms.some((t) => hasTerm(String(v), t));
}

function ruleWhy(r) {
  const f = ALERT_FIELDS[r.field];
  if (f.op === "gte") return `${f.label.replace(" (First Impressions)", "")} ${r.value} ${f.unit}`;
  if (f.op === "is") return `${f.label}: ${f.get()}`;
  const hit = String(r.value).split(",").map((s) => s.trim()).find((t) => hasTerm(String(f.get()), t));
  return `${f.label} mentions "${(hit || "").replace(/\*$/, "")}"`;
}

let alertShown = "";        // level currently on screen ("" = none)
let alertAck = "";          // highest level the user acknowledged
let alertPreviewUntil = 0;  // a Settings preview is running until then
const alertRank = (l) => (l === "red" ? 2 : l === "yellow" ? 1 : 0);

function ensureAlertEls() {
  let banner = $("alert-banner");
  if (!banner) {
    banner = document.createElement("div");
    banner.id = "alert-banner";
    banner.className = "alert-banner";
    banner.setAttribute("role", "alert");
    banner.innerHTML = `<b class="ab-level"></b><span class="ab-why"></span>` +
      `<button type="button" class="ab-ack" data-alert-ack>Acknowledge</button>`;
    document.body.appendChild(banner);
    banner.addEventListener("click", (e) => {
      if (!e.target.closest("[data-alert-ack]")) return;
      alertAck = alertShown;
      if (alertPreviewUntil) alertPreviewUntil = 0;
      evaluateAlerts();
    });
  }
  if (!$("alert-vignette")) {
    const v = document.createElement("div");
    v.id = "alert-vignette";
    v.className = "alert-vignette";
    v.setAttribute("aria-hidden", "true");
    document.body.appendChild(v);
  }
  return banner;
}

function setAlert(level, why) {
  const html = document.documentElement;
  if (!level) {
    alertShown = "";
    delete html.dataset.alert;
    const b = $("alert-banner");
    if (b) b.classList.remove("on");
    return;
  }
  const banner = ensureAlertEls();
  const changed = level !== alertShown;
  alertShown = level;
  html.dataset.alert = level;
  banner.dataset.level = level;
  banner.querySelector(".ab-level").textContent = level === "red" ? "RED ALERT" : "YELLOW ALERT";
  const text = (why || "").toUpperCase();
  const whyEl = banner.querySelector(".ab-why");
  if (whyEl.textContent !== text) whyEl.textContent = text;
  banner.classList.add("on");
  if (changed) { banner.classList.remove("flash"); void banner.offsetWidth; banner.classList.add("flash"); }
}

function evaluateAlerts() {
  if (!isLcars()) { alertAck = ""; return setAlert(""); }
  if (alertPreviewUntil && Date.now() < alertPreviewUntil) return;
  if (alertPreviewUntil) { alertPreviewUntil = 0; alertAck = ""; }
  let level = "", why = "";
  for (const r of loadAlertRules()) {
    if (!ruleMatch(r)) continue;
    if (alertRank(r.level) > alertRank(level)) { level = r.level; why = ruleWhy(r); }
  }
  if (!level) alertAck = "";                       // condition cleared: re-arm
  else if (alertRank(alertAck) >= alertRank(level)) return setAlert("");  // acknowledged
  setAlert(level, why);
}

function previewAlert(level) {
  alertAck = "";
  alertPreviewUntil = Date.now() + ALERT_PREVIEW_MS;
  setAlert(level, "PREVIEW - NO CONDITION MET");
  setTimeout(evaluateAlerts, ALERT_PREVIEW_MS + 50);
}

/* Settings > Alert Conditions */
function renderAlertRules() {
  const box = $("alert-rules");
  if (!box) return;
  const rules = loadAlertRules();
  const fieldOpts = (sel) => Object.entries(ALERT_FIELDS)
    .map(([k, f]) => `<option value="${k}"${k === sel ? " selected" : ""}>${escapeHtml(f.label)}</option>`).join("");
  box.innerHTML = rules.length ? rules.map((r, i) => {
    const f = ALERT_FIELDS[r.field];
    const list = f.list ? f.list() : [];
    return `<div class="alert-rule ${r.level}" data-i="${i}">
      <select class="select" data-k="level" aria-label="Alert level">
        <option value="yellow"${r.level === "yellow" ? " selected" : ""}>Yellow</option>
        <option value="red"${r.level === "red" ? " selected" : ""}>Red</option></select>
      <span class="ar-when">when</span>
      <select class="select" data-k="field" aria-label="Field">${fieldOpts(r.field)}</select>
      <span class="ar-op">${ALERT_OP_LABEL[f.op]}</span>
      <input class="input" data-k="value" value="${escapeHtml(r.value)}" aria-label="Value"
        ${list.length ? `list="alert-list-${i}"` : ""} placeholder="${f.op === "gte" ? "minutes" : f.op === "is" ? "value, value" : "word, prefix*"}">
      ${list.length ? `<datalist id="alert-list-${i}">${list.map((v) => `<option value="${escapeHtml(v)}">`).join("")}</datalist>` : ""}
      ${f.unit ? `<span class="ar-unit">${f.unit}</span>` : ""}
      <button type="button" class="icon-btn" data-ar-del aria-label="Remove condition" title="Remove">&times;</button>
    </div>`;
  }).join("") : `<div class="settings-hint">No conditions - no alerts will fire. Add one, or reset to the defaults.</div>`;
}

function initAlerts() {
  const box = $("alert-rules");
  if (box) {
    const read = () => [...box.querySelectorAll(".alert-rule")].map((row) => ({
      level: row.querySelector('[data-k="level"]').value,
      field: row.querySelector('[data-k="field"]').value,
      value: row.querySelector('[data-k="value"]').value,
    }));
    box.addEventListener("input", (e) => {
      if (e.target.matches('[data-k="value"]')) { saveAlertRules(read()); evaluateAlerts(); }
    });
    box.addEventListener("change", (e) => {
      if (e.target.matches('[data-k="field"]')) {
        const row = e.target.closest(".alert-rule");
        const rules = read(); const i = Number(row.dataset.i);
        rules[i].value = "";       // a value for one field means nothing for another
        saveAlertRules(rules); renderAlertRules(); evaluateAlerts();
      } else if (e.target.matches('[data-k="level"]')) {
        saveAlertRules(read()); renderAlertRules(); evaluateAlerts();
      }
    });
    box.addEventListener("click", (e) => {
      const del = e.target.closest("[data-ar-del]");
      if (!del) return;
      const rules = read(); rules.splice(Number(del.closest(".alert-rule").dataset.i), 1);
      saveAlertRules(rules); renderAlertRules(); evaluateAlerts();
    });
  }
  on("btn-alert-add", "click", () => {
    const rules = loadAlertRules();
    rules.push({ level: "yellow", field: "anyText", value: "" });
    saveAlertRules(rules); renderAlertRules();
  });
  on("btn-alert-reset", "click", () => {
    saveAlertRules(ALERT_DEFAULTS.map((r) => ({ ...r })));
    renderAlertRules(); evaluateAlerts();
    showToast("Alert conditions reset to the defaults", "indigo");
  });
  on("btn-alert-test-y", "click", () => previewAlert("yellow"));
  on("btn-alert-test-r", "click", () => previewAlert("red"));
  renderAlertRules();
  setInterval(evaluateAlerts, 1000);
  document.querySelectorAll(".form-panel input, .form-panel textarea, .form-panel select")
    .forEach((el) => { el.addEventListener("input", evaluateAlerts); el.addEventListener("change", evaluateAlerts); });
  evaluateAlerts();
}

// Called when the theme changes: tear down whatever the old theme left up.
function lcarsThemeChanged() {
  if (!isLcars() && callCard) { callCard.el.remove(); callCard = null; }
  alertAck = "";
  evaluateAlerts();
  renderAlertRules();
}

function initLcarsExtras() { initCallCard(); initAlerts(); }

/* ---- Settings sub-tabs ---------------------------------------------------- */
const SETTINGS_TAB_KEY = "tickassist_settings_tab";
const SETTINGS_TABS = ["general", "lists"];

function setSettingsTab(name, focus = false) {
  if (!SETTINGS_TABS.includes(name)) name = "general";
  SETTINGS_TABS.forEach((t) => {
    const tab = $(`settings-tab-${t}`);
    const pane = $(`settings-pane-${t}`);
    if (!tab || !pane) return;
    const on = t === name;
    tab.setAttribute("aria-selected", on ? "true" : "false");
    tab.tabIndex = on ? 0 : -1;
    pane.classList.toggle("hidden", !on);
    if (on && focus) tab.focus();
  });
  try { localStorage.setItem(SETTINGS_TAB_KEY, name); } catch (e) { /* private mode */ }
}

function initSettingsTabs() {
  let saved = "general";
  try { saved = localStorage.getItem(SETTINGS_TAB_KEY) || "general"; } catch (e) {}
  setSettingsTab(saved);
  on("settings-tabs", "click", (e) => {
    const b = e.target.closest("[data-settings-tab]");
    if (b) setSettingsTab(b.dataset.settingsTab);
  });
  // Left / Right / Home / End move between tabs, as on any tab strip.
  on("settings-tabs", "keydown", (e) => {
    const i = SETTINGS_TABS.findIndex((t) => $(`settings-tab-${t}`) === document.activeElement);
    if (i < 0) return;
    const n = SETTINGS_TABS.length;
    const to = e.key === "ArrowRight" ? (i + 1) % n : e.key === "ArrowLeft" ? (i + n - 1) % n
      : e.key === "Home" ? 0 : e.key === "End" ? n - 1 : -1;
    if (to < 0) return;
    e.preventDefault();
    setSettingsTab(SETTINGS_TABS[to], true);
  });
}

/* ---- Call transfer --------------------------------------------------------- */
// Ported from the Call Triage page. The call's ContactID arrives with the
// screen pop (/call?phone={ANI}&contactId={CONTACTID}); the contact name and
// case number are the Note Generator's own fields. Sending goes through the
// server (POST /api/transfer), which posts to the address set under Transfer
// setup. A transfer moves a live caller, so it always asks first, and warns
// when the call ID belongs to a different number than the note shows.
let transferCall = null;          // { contactId, digits, phone }
let transferEquip = [];           // from /api/transfer/config
let transferConfigured = false;
const TRANSFER_GUESS = [
  [/pro\s*one/i, "proone"], [/pro\s*sensor/i, "prosensor"], [/pro\s*max/i, "promax"],
  [/viso/i, "viso"], [/cad\s*cam|cerec|primescan/i, "cadcam"],
];

function noteTransferCall(ev) {
  if (ev && ev.contact_id && ev.source !== "test") {
    transferCall = { contactId: ev.contact_id, digits: ev.digits, phone: ev.phone };
    if (openDrawerName === "transfer") renderTransfer();
  }
}

async function loadTransferConfig() {
  try {
    const c = await api("GET", "/api/transfer/config");
    transferEquip = c.equipment || [];
    transferConfigured = !!c.configured;
    const sel = $("tr-equip");
    const keep = sel.value;
    sel.innerHTML = '<option value="">-- Select Equipment / Category --</option>' +
      transferEquip.map((e) => `<option value="${escapeHtml(e.key)}">${escapeHtml(e.label)}</option>`).join("");
    sel.value = keep;
  } catch (e) { /* feature off or server restarting */ }
}

function renderTransfer() {
  const digits = getVal("phone").replace(/\D/g, "");
  $("tr-ani").textContent = getVal("phone") || "--";
  const callEl = $("tr-call");
  if (transferCall) {
    callEl.textContent = `…${transferCall.contactId.slice(-6)} (${transferCall.phone})`;
    callEl.classList.remove("bad");
  } else {
    callEl.textContent = "None captured";
    callEl.classList.add("bad");
  }
  $("tr-contact").textContent = getVal("contact") || "(none)";
  const cas = getVal("caseNumber").toUpperCase();
  const caseOk = /^CAS\d{7}$/.test(cas) && parseInt(cas.slice(3), 10) >= 450000;
  $("tr-case").textContent = cas && cas !== "CAS" ? cas : "--";
  $("tr-case").classList.toggle("bad", !caseOk);
  const warn = $("tr-warn");
  let msg = "";
  if (!transferCall) msg = "No call ID has been captured, so a transfer can't be sent. The call ID is read from the browser address bar of the CXone call page (transfer_pop2.html?contactId=…), or from a screen pop with &contactId={CONTACTID}.";
  else if (digits && !digits.endsWith(transferCall.digits) && !transferCall.digits.endsWith(digits))
    msg = `The active call is ${transferCall.phone}, but this note's phone number is different. Check you are transferring the right call.`;
  warn.textContent = msg;
  warn.hidden = !msg;

  const sel = $("tr-equip");
  const guess = $("tr-guess");
  if (!sel.value) {
    const dt = getVal("deviceType");
    const hit = TRANSFER_GUESS.find(([re]) => re.test(dt));
    if (hit && transferEquip.some((e) => e.key === hit[1])) {
      sel.value = hit[1];
      guess.textContent = `Suggested from Device Type "${dt}".`;
      guess.hidden = false;
    } else guess.hidden = true;
  }
  renderTransferQueues();
  if (!transferConfigured) $("tr-setup").open = true;
}

function renderTransferQueues() {
  const box = $("tr-queues");
  const eq = transferEquip.find((e) => e.key === $("tr-equip").value);
  box.innerHTML = "";
  $("tr-prompt").hidden = !!eq;
  if (!eq) return;
  const dealer = getVal("contactType") === "Dealer";
  const queues = [...eq.queues].sort((a, b) =>
    (dealer ? (b.kind === "Dealer") - (a.kind === "Dealer") : (a.kind === "Dealer") - (b.kind === "Dealer")));
  queues.forEach((q, i) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "btn indigo tr-q";
    b.disabled = !transferConfigured || !transferCall;
    const hint = i === 0 && eq.queues.length > 1 ? " \u2022 suggested" : "";
    b.innerHTML = `<span>Transfer to ${escapeHtml(q.name)}</span><span class="tr-badge">${escapeHtml(q.kind)}${hint}</span>`;
    b.addEventListener("click", () => runTransfer(eq, q));
    box.appendChild(b);
  });
}

async function runTransfer(eq, q) {
  const cas = getVal("caseNumber").toUpperCase();
  if (!/^CAS\d{7}$/.test(cas) || parseInt(cas.slice(3), 10) < 450000) {
    showToast("Case ID must be CAS plus 7 digits, CAS0450000 or higher", "red");
    $("caseNumber").focus();
    return;
  }
  if (!transferCall) return showToast("No active call ID captured from MAX", "red");
  const ok = await confirmModal("Transfer this call?",
    `Destination: ${q.name}\nCase: ${cas}\nContact: ${getVal("contact") || "(none entered)"}\nCall: ${transferCall.phone}`,
    "Transfer");
  if (!ok) return;
  $("tr-queues").querySelectorAll("button").forEach((b) => { b.disabled = true; });
  $("tr-error").hidden = true;
  try {
    const r = await api("POST", "/api/transfer", {
      contactId: transferCall.contactId, targetSkill: q.skill, caseNumber: cas,
      contactName: getVal("contact"), equipment: eq.key,
    });
    $("tr-done-queue").textContent = r.queue;
    $("tr-done-case").textContent = r.case;
    $("tr-done-reply").textContent = `Transfer service replied HTTP ${r.status}` +
      (r.reply ? `: ${r.reply}` : " with no message.");
    $("tr-main").hidden = true;
    $("tr-done").hidden = false;
    transferCall = null;      // that call is gone; never reuse its id
    showToast(`Call transferred to ${r.queue}`, "green");
  } catch (err) {
    // Stays until dismissed or the next attempt: a toast vanishes too fast.
    $("tr-error-text").textContent = err.message;
    $("tr-error").hidden = false;
    renderTransferQueues();
  }
}

function initTransfer() {
  loadTransferConfig();
  on("btn-tr-error-close", "click", () => { $("tr-error").hidden = true; });
  on("tr-equip", "change", () => { $("tr-guess").hidden = true; renderTransferQueues(); });
  on("btn-tr-again", "click", () => { $("tr-done").hidden = true; $("tr-main").hidden = false; $("tr-equip").value = ""; renderTransfer(); });
  on("btn-save-transfer", "click", async () => {
    try {
      await api("POST", "/api/settings", { transfer_url: getVal("tr-url") });
      markDrawerClean("transfer");
      showToast("Transfer address saved", "green");
      await loadSettings();
      await loadTransferConfig();
      renderTransfer();
    } catch (err) { showToast(err.message, "red"); }
  });
  // Open the drawer on a fresh view of the note.
  document.addEventListener("click", (e) => {
    if (e.target.closest('[data-open-drawer="transfer"]')) {
      $("tr-done").hidden = true; $("tr-main").hidden = false;
      loadTransferConfig().then(renderTransfer);
    }
  });
}

document.addEventListener("DOMContentLoaded", init);

/* ---- required fields ------------------------------------------------------- */
// Rules (Settings > Lists & Macros) name fields that must be filled before Save,
// depending on the Device Type or Contact Type. Shift+Click on Save skips them,
// as it does the Case ID check. Rules and the software-device list are server
// settings, so an office install shares them.
const REQ_FIELDS = [
  ["serialNumber", "Serial Number"], ["osVersion", "OS Version"],
  ["deviceFirmware", "Device Firmware"], ["deviceToolVersion", "Device Tool Ver"],
  ["deviceType", "Device Type"], ["recoPc", "Reco Unit"], ["contact", "Contact Name"],
  ["phone", "Phone Number"], ["dealerName", "Dealer Company"], ["problem", "Problem / Request"],
];
const REQ_LABEL = Object.fromEntries(REQ_FIELDS);
const REQ_KIND_LABEL = {
  always: "any device (always)", hardware: "Device Type is hardware (not software)", software: "Device Type is software",
  device: "Device Type contains", contact: "Contact Type is",
};
const REQ_DEFAULT_RULES = [
  { during: "First Impressions", kind: "always", value: "", fields: ["contact", "phone", "deviceType"] },
  { during: "First Impressions", kind: "hardware", value: "", fields: ["serialNumber"] },
  { during: "Troubleshooting", kind: "hardware", value: "", fields: ["serialNumber", "osVersion", "deviceFirmware"] },
];
const REQ_DEFAULT_SOFTWARE = "Workstation, Server, Romexis";
let reqRulesDraft = null;   // being edited in Settings, not yet saved

function reqRules() {
  const raw = settingsCache && settingsCache.required_rules;
  if (raw == null) return REQ_DEFAULT_RULES;
  try {
    const v = JSON.parse(raw || "[]");
    return Array.isArray(v) ? v : [];
  } catch (e) { return REQ_DEFAULT_RULES; }
}

function reqSoftwareList(text) {
  const raw = text != null ? text
    : (settingsCache && settingsCache.software_devices != null ? settingsCache.software_devices : REQ_DEFAULT_SOFTWARE);
  return String(raw).split(/[,;\n]/).map((s) => s.trim().toLowerCase()).filter(Boolean);
}

// "" no device entered, else "software" or "hardware".
function deviceKind(name) {
  const n = (name || "").trim().toLowerCase();
  if (!n) return "";
  return (n.includes("software") || reqSoftwareList().includes(n)) ? "software" : "hardware";
}

function reqRuleApplies(rule) {
  if (rule.during && rule.during !== callType) return false;
  if (rule.kind === "always") return true;
  const device = getVal("deviceType");
  if (rule.kind === "hardware" || rule.kind === "software") return deviceKind(device) === rule.kind;
  if (rule.kind === "device") return !!rule.value && device.toLowerCase().includes(String(rule.value).toLowerCase());
  if (rule.kind === "contact") return !!rule.value && getVal("contactType") === rule.value;
  return false;
}

function requiredFieldIds() {
  const ids = new Set();
  reqRules().forEach((r) => { if (reqRuleApplies(r)) (r.fields || []).forEach((f) => ids.add(f)); });
  return ids;
}

function missingRequired() {
  return [...requiredFieldIds()].filter((id) => $(id) && !getVal(id).trim());
}

// Amber mark on the fields still needed; follows the note as it changes.
function applyRequiredMarks() {
  const needed = requiredFieldIds();
  REQ_FIELDS.forEach(([id]) => {
    const el = $(id);
    if (!el) return;
    const need = needed.has(id) && !getVal(id).trim();
    el.classList.toggle("req-needed", need);
    if (!need) el.classList.remove("req-missing");
    if (needed.has(id)) el.setAttribute("aria-required", "true"); else el.removeAttribute("aria-required");
  });
}

function reportMissingRequired(missing) {
  if (typeof setEnvCollapsed === "function" && $("env-section") &&
      $("env-section").classList.contains("collapsed")) setEnvCollapsed(false, false);
  missing.forEach((id) => { const s = $(id).closest("[data-fi-step]"); if (s) fiFolded[s.dataset.fiStep] = false; });
  renderFiSteps();
  missing.forEach((id) => $(id).classList.add("req-missing"));
  showToast("Required: " + missing.map((id) => REQ_LABEL[id] || id).join(", "), "red");
  const first = $(missing[0]);
  if (first) { first.focus(); first.scrollIntoView({ block: "center", behavior: "smooth" }); }
}

// ---- the Settings panel
function readReqRules() {
  return [...document.querySelectorAll("#req-rules [data-req-row]")].map((row) => {
    const v = row.querySelector("[data-req-value]");
    return {
      during: row.querySelector("[data-req-during]").value,
      kind: row.querySelector("[data-req-kind]").value,
      value: v ? v.value.trim() : "",
      fields: [...row.querySelectorAll("[data-req-field]:checked")].map((c) => c.dataset.reqField),
    };
  });
}

function renderReqPanel() {
  const box = $("req-rules");
  if (!box) return;
  const rules = reqRulesDraft || reqRules();
  if (document.activeElement !== $("req-software")) {
    $("req-software").value = settingsCache && settingsCache.software_devices != null
      ? settingsCache.software_devices : REQ_DEFAULT_SOFTWARE;
  }
  const contactTypes = selectValues("contactType");
  box.innerHTML = rules.length ? rules.map((r, i) => {
    const durings = [["", "any call type"], [FIRST_IMPRESSIONS, FIRST_IMPRESSIONS], [TROUBLESHOOTING, TROUBLESHOOTING]]
      .map(([v, l]) => `<option value="${v}"${(r.during || "") === v ? " selected" : ""}>${escapeHtml(l)}</option>`).join("");
    const kinds = Object.entries(REQ_KIND_LABEL).map(([k, label]) =>
      `<option value="${k}"${r.kind === k ? " selected" : ""}>${escapeHtml(label)}</option>`).join("");
    let value = "";
    if (r.kind === "device") {
      value = `<input class="input" type="text" data-req-value value="${escapeHtml(r.value || "")}" placeholder="e.g. Promax" autocomplete="off">`;
    } else if (r.kind === "contact") {
      value = `<select class="select" data-req-value>` + contactTypes.map((t) =>
        `<option${r.value === t ? " selected" : ""}>${escapeHtml(t)}</option>`).join("") + `</select>`;
    }
    const checks = REQ_FIELDS.map(([id, label]) =>
      `<label class="req-check"><input type="checkbox" data-req-field="${id}"${(r.fields || []).includes(id) ? " checked" : ""}> ${escapeHtml(label)}</label>`).join("");
    return `<div class="req-rule" data-req-row="${i}">` +
      `<div class="req-rule-when"><span>During</span><select class="select" data-req-during>${durings}</select><span>when</span><select class="select" data-req-kind>${kinds}</select>${value}` +
      `<button type="button" class="btn small red" data-req-del title="Remove this rule">Remove</button></div>` +
      `<div class="req-rule-fields"><span>require</span>${checks}</div></div>`;
  }).join("") : '<p class="field-help">No rules: nothing is required.</p>';
}

async function saveReqRules() {
  try {
    await api("POST", "/api/settings", {
      required_rules: JSON.stringify(readReqRules()),
      software_devices: getVal("req-software"),
    });
    reqRulesDraft = null;
    await loadSettings();
    update();
    showToast("Required fields saved", "green");
  } catch (err) { showToast(err.message, "red"); }
}

function initRequired() {
  const box = $("req-rules");
  if (!box) return;
  on("btn-req-add", "click", () => {
    reqRulesDraft = readReqRules();
    reqRulesDraft.push({ during: "", kind: "hardware", value: "", fields: [] });
    renderReqPanel();
  });
  on("btn-req-reset", "click", () => {
    reqRulesDraft = JSON.parse(JSON.stringify(REQ_DEFAULT_RULES));
    $("req-software").value = REQ_DEFAULT_SOFTWARE;
    renderReqPanel();
  });
  on("btn-req-save", "click", saveReqRules);
  box.addEventListener("change", (e) => {
    if (e.target.matches("[data-req-during]")) { reqRulesDraft = readReqRules(); renderReqPanel(); return; }
    if (e.target.matches("[data-req-kind]")) {   // the value control changes with the condition
      reqRulesDraft = readReqRules();
      reqRulesDraft.forEach((r, i) => { if (i === +e.target.closest("[data-req-row]").dataset.reqRow) r.value = ""; });
      renderReqPanel();
    }
  });
  box.addEventListener("click", (e) => {
    const del = e.target.closest("[data-req-del]");
    if (!del) return;
    reqRulesDraft = readReqRules();
    reqRulesDraft.splice(+del.closest("[data-req-row]").dataset.reqRow, 1);
    renderReqPanel();
  });
  // A field that was blocked loses its red outline as soon as it is touched.
  document.addEventListener("input", (e) => {
    if (e.target.classList && e.target.classList.contains("req-missing")) e.target.classList.remove("req-missing");
  });
}

/* ---- sheet cross-check ------------------------------------------------------ */
// With a sheet row found for the Imaging Package, the system-environment values
// typed in the note are compared with that row; any that disagree get a red
// outline and a line under the package fields. Empty fields are not a mismatch
// (the lookup fills them); Serial Number is per unit, so it is never compared.
let sheetRow = null;   // { key, section, values } for the package in the note
const SHEET_CHECK_FIELDS = ["os_version", "device_type", "device_firmware",
  "device_tool_version", "didapi", "romexis", "reco_os", "reco_pc", "reco_firmware"];
let sheetDiffSig = "";

const sheetCheckOn = () => !(settingsCache && settingsCache.sheet_check === false);

function sheetTokens(text) {
  return String(text).toLowerCase().replace(/\bv(?=\d)/g, "").split(/[^a-z0-9.]+/).filter(Boolean);
}

// A sheet cell may offer several values ("Windows 10/11"); any one fits. "11"
// fits "Windows 11", but "1.2" does not fit "11.2".
function sheetValueMatches(have, want) {
  const a = sheetTokens(have);
  return String(want).split(/[;|,\/]/).some((alt) => {
    const b = sheetTokens(alt);
    if (!b.length) return true;
    return a.every((t) => b.includes(t)) || b.every((t) => a.includes(t));
  });
}

function sheetMismatches() {
  if (!sheetRow || !featureOn("sheet") || !sheetCheckOn()) return [];
  const out = [];
  SHEET_CHECK_FIELDS.forEach((field) => {
    const want = (sheetRow.values || {})[field];
    const id = FIELD_MAP[field];
    const have = getVal(id);
    if (want && have && !sheetValueMatches(have, want)) out.push({ field, id, want, have });
  });
  return out;
}

function applySheetCheck() {
  document.querySelectorAll(".sheet-diff").forEach((el) => {
    el.classList.remove("sheet-diff");
    el.removeAttribute("title");
  });
  const note = $("sheet-check");
  if (!note) return;
  const bad = sheetMismatches();
  note.textContent = "";
  note.classList.toggle("hidden", !bad.length);
  if (!bad.length) { sheetDiffSig = ""; return; }
  bad.forEach((m) => {
    const el = $(m.id);
    el.classList.add("sheet-diff");
    el.title = `The sheet says: ${m.want}`;
  });
  const label = (m) => `${$(m.id).placeholder || m.id} (sheet: ${m.want})`;
  note.append(`${bad.length === 1 ? "1 value differs" : bad.length + " values differ"} from the sheet row ` +
    `for ${sheetRow.key} (${sheetRow.section}): ${bad.map(label).join(", ")}. `);
  const btn = document.createElement("button");
  btn.type = "button"; btn.className = "btn small"; btn.dataset.sheetFix = "1";
  btn.textContent = "Use sheet values";
  note.append(btn);
  // A newly found mismatch must be seen: open the environment section if shut.
  const sig = bad.map((m) => m.field + "=" + m.have).join("|");
  if (sig !== sheetDiffSig && $("env-section") && $("env-section").classList.contains("collapsed")) {
    setEnvCollapsed(false, false);
  }
  sheetDiffSig = sig;
}

// Which system a version name belongs to ("" when it can't be told).
function osOfVersion(name) {
  const n = String(name).trim().toLowerCase();
  if (/ventura|sonoma|sequoia|tahoe|monterey|big sur|catalina|mojave|macos/.test(n)) return "macOS";
  if (/server|^20(08|12|16|19|22|25)\b/.test(n)) return "Windows Server";
  if (/^(7|8|8\.1|10|11)\b/.test(n) || /windows/.test(n)) return "Windows";
  return "";
}
function osVersionsForChecked(items) {
  const on = [...document.querySelectorAll('input[name="os"]:checked')].map((c) => c.value);
  if (!on.length) return items;
  return items.filter((it) => { const o = osOfVersion(it.name); return !o || on.includes(o); });
}

/* ---- First Impressions: step by step ------------------------------------------ */
// On First Impressions the form works one section at a time. A section whose
// required fields (Settings > Required Fields) are filled folds into a summary
// line when you leave it, and the next one opens; a section stays locked until
// the ones above it are filled in. Nothing is cleared. "Open all sections", or
// Shift+click on a locked section, lifts the order; Troubleshooting and editing
// a saved ticket never use it.
const FI_STEPS = [
  { key: "caller", title: "Caller", summary: () => [getVal("contact"), getVal("phone"), getVal("contactType") === "Dealer" ? getVal("dealerName") : ""].filter(Boolean).join(" \u00b7 ") },
  { key: "env", title: "System Environment", summary: () => [getVal("deviceType"), getVal("serialNumber"), [getOsLabel(), getVal("osVersion")].filter(Boolean).join(" ")].filter(Boolean).join(" \u00b7 ") },
  { key: "diag", title: "Diagnostics", summary: () => [getVal("errorInfo"), getVal("partRec")].filter(Boolean).join(" \u00b7 ") },
  { key: "details", title: "Case Details", summary: () => getVal("problem") || getVal("workflow") },
  { key: "resolution", title: "Resolution", summary: () => getVal("resStatus") },
];
let fiKeyAt = 0;     // when Tab was last pressed
let fiFolded = {};   // step key -> folded by leaving it (or by its header)

const fiStepEl = (key) => document.querySelector(`[data-fi-step="${key}"]`);
const fiStepIds = (key) => [...fiStepEl(key).querySelectorAll("input[id], textarea[id], select[id]")].map((e) => e.id);
const fiActive = () => callType === FIRST_IMPRESSIONS && !editing && document.body.dataset.fiMore !== "1";
function fiStepMissing(key) {
  const ids = new Set(fiStepIds(key));
  return missingRequired().filter((id) => ids.has(id));
}
const clip = (s, n = 70) => (s.length > n ? s.slice(0, n - 1) + "\u2026" : s);

function renderFiSteps() {
  const btn = $("fi-more");
  if (btn) {
    const all = document.body.dataset.fiMore === "1";
    btn.textContent = all ? "Back to step by step" : "Open all sections";
    btn.setAttribute("aria-pressed", String(all));
  }
  const active = fiActive();
  let unlocked = true;
  FI_STEPS.forEach((s, i) => {
    const el = fiStepEl(s.key);
    if (!el) return;
    const head = el.querySelector(".fi-step-head");
    const status = head.querySelector(".fi-step-status");
    if (!active) { el.dataset.state = "open"; status.textContent = ""; return; }
    const missing = fiStepMissing(s.key);
    let state = !unlocked ? "locked" : (fiFolded[s.key] && !missing.length ? "folded" : "open");
    el.dataset.state = state;
    head.setAttribute("aria-expanded", String(state === "open"));
    status.classList.toggle("need", state === "open" && missing.length > 0);
    if (state === "locked") status.textContent = "Locked";
    else if (state === "folded") status.textContent = clip(s.summary()) || "Done";
    else status.textContent = missing.length ? "Needs: " + missing.map((id) => REQ_LABEL[id] || id).join(", ") : "";
    if (missing.length) unlocked = false;
  });
}
const renderFiMore = renderFiSteps;   // update() and the rotation toggle call this

function initFiMore() {
  on("fi-more", "click", () => {
    document.body.dataset.fiMore = document.body.dataset.fiMore === "1" ? "" : "1";
    renderFiSteps();
  });
  document.querySelectorAll("[data-fi-head]").forEach((head) => head.addEventListener("click", (e) => {
    if (!fiActive()) return;
    const key = head.dataset.fiHead;
    const state = fiStepEl(key).dataset.state;
    if (state === "locked") {
      if (e.shiftKey) { document.body.dataset.fiMore = "1"; renderFiSteps(); return; }
      const i = FI_STEPS.findIndex((s) => s.key === key);
      const blocker = FI_STEPS.slice(0, i).find((s) => fiStepMissing(s.key).length);
      showToast(blocker ? `Fill in ${fiStepMissing(blocker.key).map((id) => REQ_LABEL[id] || id).join(", ")} first` : "Fill in the sections above first", "amber");
      return;
    }
    fiFolded[key] = state === "open";
    renderFiSteps();
    if (!fiFolded[key]) { const f = fiStepEl(key).querySelector("input:not([readonly]):not([type=checkbox]), textarea"); if (f) f.focus(); }
  }));
  // Leaving a finished section with Tab folds it and moves on to the next.
  document.addEventListener("keydown", (e) => { if (e.key === "Tab" && !e.shiftKey) fiKeyAt = Date.now(); }, true);
  document.addEventListener("focusout", (e) => {
    if (!fiActive()) return;
    const body = e.target.closest && e.target.closest(".fi-step-body");
    if (!body) return;
    const stepEl = body.parentElement, key = stepEl.dataset.fiStep;
    const to = e.relatedTarget;
    if (to && body.contains(to)) return;
    // Only fold when the user moved on with the keyboard (Tab/Enter). Folding
    // on a mouse click shifted the layout under the pointer and swallowed the click.
    if (Date.now() - fiKeyAt > 400) return;
    const hasRules = missingRequired().length || [...requiredFieldIds()].some((id) => fiStepIds(key).includes(id));
    if (!hasRules || fiStepMissing(key).length || fiFolded[key]) return;
    fiFolded[key] = true;
    renderFiSteps();
    const nextEl = [...document.querySelectorAll("[data-fi-step]")].find((el) => el.dataset.state === "open" && el !== stepEl && FI_STEPS.findIndex((s) => s.key === el.dataset.fiStep) > FI_STEPS.findIndex((s) => s.key === key));
    if (nextEl && (!to || to.closest("[data-fi-step]") === nextEl || !to.closest("[data-fi-step]"))) {
      setTimeout(() => {
        const need = missingRequired().find((id) => nextEl.contains($(id)));
        const f = need ? $(need) : nextEl.querySelector("input:not([readonly]):not([type=checkbox]), textarea");
        if (f) f.focus();
      }, 0);
    }
  });
}
