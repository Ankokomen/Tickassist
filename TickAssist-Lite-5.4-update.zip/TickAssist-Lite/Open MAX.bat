@echo off
REM Opens MAX in Chrome or Edge in a window TickAssist can read even when it is
REM minimized or behind other windows. Sign in to MAX there once.
setlocal
cd /d "%~dp0"
if exist "%~dp0installed.txt" set "TICKASSIST_DATA=%APPDATA%\TickAssist"
if exist "%~dp0runtime\python.exe" (
    "%~dp0runtime\python.exe" "%~dp0app\cdp.py"
) else (
    where py >nul 2>nul && (py -3 "%~dp0app\cdp.py") || (python "%~dp0app\cdp.py")
)
if errorlevel 1 pause
