"""Incoming-call detection for TickAssist.

Watches the CXone MAX agent window (RingCentral Contact Center runs on NICE
CXone) and Windows toast notifications for a caller's phone number, and hands
each new one to the Note Generator so the Phone Number field fills itself.

How it reads another window
---------------------------
MAX runs in a browser, so there is no API to ask for the caller. Instead this
uses Windows UI Automation - the same accessibility interface screen readers
use - which can read the text of any window on the desktop without admin
rights and without installing anything. Python's standard library cannot talk
to UI Automation directly, so a small PowerShell helper does the reading (both
PowerShell and the UI Automation assemblies ship with every Windows 10/11
install) and streams what it sees back here as one JSON line per scan. All the
deciding - which number is the caller - happens in Python, in CallDetector,
which has no Windows dependency and is unit-testable anywhere.

Two places are read:
  * windows whose title matches the configured keywords (the MAX window), and
  * Windows toast notifications whose text matches them (MAX's "New Contact"
    desktop notification, which Chrome shows as a native toast).

Why "a number that has just appeared" and not "any number on screen"
-------------------------------------------------------------------
MAX shows other numbers too - contact history, the dialled line, skill
numbers. So a window is first read as a baseline, and only a number that shows
up afterwards counts as an incoming caller. If several new numbers appear at
once (a page load, a tab switch) it is ambiguous and nothing is filled; the
Settings page shows what was skipped so a stray number can be added to the
ignore list. A toast is new by definition, so its number counts immediately.

Caller type
-----------
Text that appears together with the number - MAX's skill, such as
"FI-Dealer Support" - is matched against the caller-type rules
("Dealer = Dealer") to choose Contact Type. Only text new with the call is
used, never the whole window, and if MAX draws the skill a moment after the
number, a follow-up event types the call when it lands.

There is also a push route, /call?phone=..., for a CXone admin who would rather
configure a screen pop than rely on reading the screen. See server.py.
"""

import base64
import json
from collections import Counter
import os
import re
import subprocess
import threading
import time

import cdp

DEFAULT_MATCH = "MAX, niceincontact, CXone, Mpower"

# NANP numbers: area code and exchange both start 2-9, which keeps timestamps,
# durations, and most IDs out. Separators are optional.
_PHONE_RE = re.compile(
    r"(?<!\d)(?:\+?1[\s.\-]?)?\(?([2-9]\d{2})\)?[\s.\-]?([2-9]\d{2})[\s.\-]?(\d{4})(?!\d)"
)

# The same number arriving from two routes (toast + window, or a screen pop
# as well) within this window is one call, not two.
DEDUPE_SECONDS = 45

# The page CXone opens when a call is answered carries the call's own id:
#   .../transfer_pop2.html?contactId=...&ani=...&caseNumber=CAS...
# TickAssist reads it from the browser's address bar (see _PS_SCRIPT).
URL_MATCH = r"transfer_pop2[^?\s]*\?"


def parse_call_url(text):
    """{contact_id, ani, case, name} from a call-page address, or None."""
    from urllib.parse import parse_qs
    m = re.search(r"transfer_pop2[^?\s]*\?(\S+)", text or "")
    if not m:
        return None
    q = parse_qs(m.group(1).replace("&amp;", "&"))

    def one(key):
        return (q.get(key) or [""])[0].strip()
    cid = one("contactId")
    if not re.match(r"^\d{1,32}$", cid):
        return None
    return {"contact_id": cid, "ani": normalize_phone(one("ani")),
            "case": one("caseNumber"), "name": one("contactName")}

# MAX may draw the skill ("FI-Dealer Support") a moment before or after the
# number. Text that appeared within this window either side of the number is
# read as belonging to that call.
CONTEXT_SECONDS = 8

# A D365 case number shown with the call - e.g. "Inbound Case Reference:
# CAS0490097" in the Call Triage panel MAX pops. That panel can load when the
# call is answered rather than when it rings, so it is looked for longer than
# the skill; the CAS + 7 digits shape is distinctive enough to allow that.
CASE_SECONDS = 120
CASE_RE = re.compile(r"(?<![A-Za-z0-9])CAS-?(\d{7})(?!\d)", re.IGNORECASE)


def find_cases(lines):
    """Distinct case numbers in the lines, normalised to CAS0490097."""
    out = []
    for ln in lines:
        for m in CASE_RE.finditer(ln or ""):
            num = "CAS" + m.group(1)
            if num not in out:
                out.append(num)
    return out


def _one_case(lines):
    found = find_cases(lines)
    return found[0] if len(found) == 1 else None

# Caller-type rules: "text in MAX = Contact Type", first match wins. Matched
# against text that appeared with the call (the skill, the queue), never the
# whole window, so a skill in the call history cannot classify a new call.
DEFAULT_RULES = """Dealer = Dealer
IT = IT
Sales = Sales
Military = Military
End User = End User"""


def digits_of(value):
    return re.sub(r"\D", "", value or "")


def normalize_phone(value):
    """Return the 10-digit NANP number in `value`, or None."""
    d = digits_of(value)
    if len(d) == 11 and d.startswith("1"):
        d = d[1:]
    if len(d) == 10 and d[0] in "23456789" and d[3] in "23456789":
        return d
    return None


def find_phones(text):
    """Every distinct 10-digit phone number in `text`, in order of appearance."""
    found = []
    for m in _PHONE_RE.finditer(text or ""):
        raw = m.group(0)
        # An unbroken run of 11 digits is far more often a CXone contact ID
        # than a number written as 1XXXXXXXXXX; insist on a separator or "+".
        if len(digits_of(raw)) == 11 and raw.isdigit():
            continue
        num = "".join(m.groups())
        if num not in found:
            found.append(num)
    return found


def format_phone(d):
    return f"{d[:3]}-{d[3:6]}-{d[6:]}"


def keyword_regex(keywords, anchored=False):
    """Comma/newline separated keywords -> a case-insensitive whole-word regex.

    anchored=True is for window titles: the keyword must START the title
    (after any "(3) " unread counter). "MAX" anywhere would also catch a
    Dynamics tab titled "Promax 3D MAX - E61 error", and a new number typed
    into that page would then look like a caller. Notification text is
    matched anywhere, since Chrome puts the site name on its second line.
    """
    words = [w.strip() for w in re.split(r"[,\n]", keywords or "") if w.strip()]
    if not words:
        return None
    alt = "(?:" + "|".join(re.escape(w) for w in words) + ")"
    if anchored:
        return r"(?i)^\W*(?:\(\d+\)\s*)?" + alt + r"\b"
    return r"(?i)\b" + alt + r"\b"


def parse_rules(text):
    """'keyword = Contact Type' lines -> [(regex, contact_type, keyword)].

    Case-insensitive, except a keyword written entirely in capitals ("IT")
    matches only in capitals - so it never fires on the word "it". Matches
    whole words, where hyphens count as a break: "FI-Dealer Support" has the
    word "Dealer" in it.
    """
    rules = []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        sep = "=" if "=" in line else ("->" if "->" in line else None)
        if not sep:
            continue
        key, value = (part.strip() for part in line.split(sep, 1))
        if not key or not value:
            continue
        flags = 0 if (key.isupper() and any(c.isalpha() for c in key)) else re.IGNORECASE
        rx = re.compile(r"(?<![A-Za-z0-9])" + re.escape(key) + r"(?![A-Za-z0-9])", flags)
        rules.append((rx, value, key))
    return rules


def classify(rules, lines):
    """First rule (in order) that matches any line -> (contact_type, line)."""
    for rx, value, _key in rules:
        for line in lines:
            if rx.search(line):
                return value, line
    return None


def lines_for_call(lines, num, ignore=()):
    """(own, neutral): the lines that can describe the call from `num`.

    A line that names a different phone number is that other call's - in
    practice a row of MAX's contact history ("3174305321FI - Dealer
    Support08:01"), which MAX redraws as a new call arrives, so it turns up
    beside the new number. Reading the skill off such a row typed an FI - IT
    Support call as Dealer, because the Dealer rule comes first. Those lines are
    dropped. `own` names this caller's number (its own row), `neutral` names
    none (a skill label, the Call Triage panel). Numbers on the ignore list -
    your own lines - do not make a line another call's.
    """
    own, neutral = [], []
    for line in lines:
        nums = {n for n in find_phones(line) if n not in ignore}
        if not nums:
            neutral.append(line)
        elif nums == {num}:
            own.append(line)
    return own, neutral


def _lines(text):
    return [ln.strip() for ln in (text or "").splitlines() if ln.strip()]


class CallDetector:
    """Turns successive screen snapshots into "this is the new caller" events.

    Platform-independent: feed it snapshots and it returns the numbers to use.
    A snapshot is a list of sources: {"k": "window"|"toast", "id", "title",
    "text"}.
    """

    def __init__(self, ignore=(), clock=time.time, rules=None):
        self.ignore = set(ignore)
        self.clock = clock
        self.rules = parse_rules(DEFAULT_RULES) if rules is None else rules
        self._seen = {}          # source key -> (title, set(numbers), Counter(lines))
        self._fresh = {}         # source key -> [(time, line)] recently appeared
        # source key -> {"num", "at", "type": bool, "case": bool}: a call still
        # missing its skill (for CONTEXT_SECONDS) or case number (CASE_SECONDS).
        self._awaiting = {}
        self._recent = {}        # number -> time it was last reported
        self.last_ambiguous = None
        self.last_call = None

    def set_ignore(self, ignore):
        self.ignore = set(ignore)

    def set_rules(self, rules):
        self.rules = rules

    def _record_call(self, num, kind, context, hit, case=None):
        self.last_call = {
            "phone": format_phone(num), "source": kind, "at": self.clock(),
            "contact_type": hit[0] if hit else None,
            "matched": hit[1][:120] if hit else None,
            "case_number": case,
            # What arrived with the call, for writing a rule when none matched.
            "context": [ln[:80] for ln in context if not find_phones(ln)][:8],
        }

    def _details(self, num, lines, want_type=True, want_case=True):
        """(type hit, case number, lines used) for the call from `num`. The
        caller's own row is read before text naming no number, and text about
        another call is not read at all (see lines_for_call)."""
        own, neutral = lines_for_call(lines, num, self.ignore)
        hit = (classify(self.rules, own) or classify(self.rules, neutral)) if want_type else None
        case = _one_case(own + neutral) if want_case else None
        return hit, case, own + neutral

    def _late_details(self, key, kind, lines, recent, now, whole=False):
        """A call already reported may get its skill or case number drawn a
        moment later. Returns the update event, if this scan brought one."""
        w = self._awaiting.get(key)
        if not w:
            return None
        type_open = not w["type"] and now - w["at"] <= CONTEXT_SECONDS
        case_open = not w["case"] and now - w["at"] <= CASE_SECONDS
        if not type_open and not case_open:
            del self._awaiting[key]
            return None
        # A whole re-read page is only trusted for the distinctive case number.
        want_type, want_case = type_open and not whole, case_open
        hit, case = None, None
        if lines:
            hit, case, _ = self._details(w["num"], lines, want_type, want_case)
        if not hit and not case:
            return None
        w["type"] = w["type"] or bool(hit)
        w["case"] = w["case"] or bool(case)
        last = self.last_call if self.last_call and self.last_call.get("phone") == format_phone(w["num"]) else None
        if last is None:
            self._record_call(w["num"], kind, recent, hit, case)
        else:
            if hit:
                last["contact_type"], last["matched"] = hit[0], hit[1][:120]
            if case:
                last["case_number"] = case
        if w["type"] and w["case"]:
            del self._awaiting[key]
        return {"phone": w["num"], "source": kind,
                "contact_type": hit[0] if hit else None,
                "matched": hit[1] if hit else None,
                "case_number": case, "update": True}

    def feed(self, sources):
        now = self.clock()
        events = []
        present = set()
        for src in sources or []:
            kind = src.get("k") or "window"
            key = f"{kind}:{src.get('id')}"
            title = src.get("title") or ""
            present.add(key)
            text = src.get("text") or ""
            numbers = [n for n in find_phones(f"{title}\n{text}")
                       if n not in self.ignore]
            counts = Counter(_lines(text))
            prev = self._seen.get(key)
            self._seen[key] = (title, set(numbers), counts)

            if kind == "window" and (prev is None or prev[0] != title):
                # First look at this window, or it now shows a different page
                # (title changed): whatever is on it is the baseline. MAX may
                # retitle itself as the call is answered, just as the case
                # panel loads - so a call still waiting for its case number
                # takes one if the new page shows exactly one.
                self._fresh[key] = []
                if prev is not None:
                    ev = self._late_details(key, kind, list(counts), [], now, whole=True)
                    if ev:
                        events.append(ev)
                continue

            # Lines that were not there last scan (a toast is all new). Counted,
            # so a second "FI-Dealer Support" next to one already in the
            # history still registers as new.
            fresh = list((counts - prev[2]).elements()) if prev else list(counts.elements())
            recent = [(t, ln) for t, ln in self._fresh.get(key, [])
                      if now - t <= CONTEXT_SECONDS]
            recent.extend((now, ln) for ln in fresh)
            self._fresh[key] = recent

            # A call already reported without a type: the skill may be drawn
            # just after the number, so keep looking for a few seconds.
            ev = self._late_details(key, kind, fresh, [ln for _, ln in recent], now)
            if ev:
                events.append(ev)

            new = [n for n in numbers if prev is None or n not in prev[1]]
            if not new:
                continue
            if len(new) > 1:
                self.last_ambiguous = {"numbers": [format_phone(n) for n in new],
                                       "source": kind, "at": now}
                continue
            num = new[0]
            if now - self._recent.get(num, 0) < DEDUPE_SECONDS:
                continue
            self._recent[num] = now
            hit, case, context = self._details(num, [ln for _, ln in recent])
            self._record_call(num, kind, context, hit, case)
            if hit and case:
                self._awaiting.pop(key, None)
            else:
                self._awaiting[key] = {"num": num, "at": now,
                                       "type": bool(hit), "case": bool(case)}
            events.append({"phone": num, "source": kind,
                           "contact_type": hit[0] if hit else None,
                           "matched": hit[1] if hit else None,
                           "case_number": case})

        # Forget closed windows / dismissed toasts so a repeat caller later
        # in the shift is detected again rather than suppressed as "seen".
        for key in list(self._seen):
            if key not in present:
                del self._seen[key]
                self._fresh.pop(key, None)
                self._awaiting.pop(key, None)
        for num, at in list(self._recent.items()):
            if now - at > DEDUPE_SECONDS:
                del self._recent[num]
        return events

    def note_external(self, num):
        """A number arrived by another route; suppress an echo from the screen."""
        self._recent[num] = self.clock()


class IncomingCalls:
    """The latest incoming number, with a sequence the browser long-polls on."""

    def __init__(self):
        self._cond = threading.Condition()
        self.seq = 0
        self.event = None

    case_enabled = True  # off when "Case number from MAX" is switched off

    def publish(self, num, source, contact_type=None, matched=None, update=False,
                case_number=None, contact_id=None):
        with self._cond:
            self.seq += 1
            self.event = {"seq": self.seq, "phone": format_phone(num),
                          "digits": num, "source": source, "at": time.time(),
                          "contact_type": contact_type, "matched": matched,
                          "case_number": case_number if self.case_enabled else None,
                          # update: same call, its type found a moment later.
                          "update": bool(update),
                          # CXone's id for this call; only a screen pop has it.
                          "contact_id": contact_id}
            self._cond.notify_all()
            return self.event

    def wait(self, since, timeout):
        """Block until there is an event newer than `since` or the timeout."""
        with self._cond:
            if since is not None and self.seq <= since:
                self._cond.wait_for(lambda: self.seq > since, timeout=timeout)
            return self.seq, (self.event if since is not None and self.seq > since
                              else None)


# ---- the Windows reader -------------------------------------------------
# Lists top-level windows each scan; reads full text only of those that match,
# so the cost scales with the MAX window, not the whole desktop. Settings come
# in through environment variables, never by splicing text into the script.
_PS_SCRIPT = r"""
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
$AE = [System.Windows.Automation.AutomationElement]
$Scope = [System.Windows.Automation.TreeScope]
$All = [System.Windows.Automation.Condition]::TrueCondition
$match = New-Object System.Text.RegularExpressions.Regex($env:TA_MATCH)
$toastMatch = New-Object System.Text.RegularExpressions.Regex($env:TA_TOAST)
$urlMatch = New-Object System.Text.RegularExpressions.Regex($env:TA_URL)
$tick = 0
Add-Type -Namespace TA -Name W -MemberDefinition '[DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);'
$editCond = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::Edit)
$interval = [int]$env:TA_INTERVAL_MS
$cap = 4000
[Console]::Out.WriteLine('{"t":"ready"}')
[Console]::Out.Flush()
while ($true) {
  $found = New-Object System.Collections.ArrayList
  $titles = New-Object System.Collections.ArrayList
  $urls = New-Object System.Collections.ArrayList
  $bars = 0
  $addrs = New-Object System.Collections.ArrayList
  $tick++
  $err = $null
  try {
    $wins = $AE::RootElement.FindAll($Scope::Children, $All)
    foreach ($w in $wins) {
      try { $name = [string]$w.Current.Name; $cls = [string]$w.Current.ClassName }
      catch { continue }
      if ($name -and $titles.Count -lt 12) { [void]$titles.Add($name) }
      # The call page's address (browser windows only, every other scan): it
      # carries the CXone call id, which MAX never shows.
      if (($tick % 2) -eq 0 -and ($cls -eq 'Chrome_WidgetWin_1' -or $cls -eq 'MozillaWindowClass')) {
        try {
          $ec = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::Edit)
          $nc = New-Object System.Windows.Automation.PropertyCondition($AE::NameProperty, 'Address and search bar')
          $bar = $w.FindFirst($Scope::Descendants, (New-Object System.Windows.Automation.AndCondition($ec, $nc)))
          if (-not $bar) { $bar = $w.FindFirst($Scope::Descendants, $ec) }
          if ($bar) {
            $bars++
            $v = $bar.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
            if ($addrs.Count -lt 3) { $a = [string]$v; if ($a.Length -gt 110) { $a = $a.Substring(0, 110) }; [void]$addrs.Add($a) }
            if ($v -and $urlMatch.IsMatch($v)) { [void]$urls.Add([string]$v) }
          }
        } catch {}
      }
      $isToast = ($cls -eq 'Windows.UI.Core.CoreWindow' -and $name -match 'notification')
      if (-not $isToast -and -not $match.IsMatch($name)) { continue }
      # A minimized window hides its contents from readers; note it so the
      # status can say why nothing was read. Nothing is ever restored.
      $min = $false
      if (-not $isToast) {
        try { $min = [TA.W]::IsIconic([IntPtr][int]$w.Current.NativeWindowHandle) } catch {}
      }
      $sb = New-Object System.Text.StringBuilder
      $n = 0
      $named = 0
      try {
        foreach ($e in $w.FindAll($Scope::Descendants, $All)) {
          if ($n++ -ge $cap) { break }
          try { $t = $e.Current.Name; if ($t) { $named++; [void]$sb.Append($t).Append("`n") } } catch {}
        }
      } catch {}
      $text = $sb.ToString()
      # MAX shows the call page's address in a side panel: a text box keeps
      # it in its value, not its name, so read those too.
      if (-not $isToast -and ($tick % 2) -eq 0) {
        try {
          $k = 0
          foreach ($ed in $w.FindAll($Scope::Descendants, $editCond)) {
            if ($k++ -ge 12) { break }
            try {
              $ev = $ed.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value
              if ($ev -and $urlMatch.IsMatch($ev)) { [void]$urls.Add([string]$ev) }
            } catch {}
          }
        } catch {}
      }
      # Diagnostics only: does this window expose a web page (Document)?
      # 1 = yes, 0 = only the browser frame, -1 = could not tell.
      $doc = -1
      if (-not $isToast) {
        try {
          $docCond = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::Document)
          $doc = 0
          if ($w.FindFirst($Scope::Descendants, $docCond)) { $doc = 1 }
        } catch { $doc = -1 }
      }
      if ($isToast -and -not $toastMatch.IsMatch($text)) { continue }
      $kind = 'window'; if ($isToast) { $kind = 'toast' }
      [void]$found.Add(@{ k = $kind; id = [string]$w.Current.NativeWindowHandle;
                          title = $name; text = $text; n = $named; doc = $doc; min = $min })
    }
  } catch { $err = $_.Exception.Message }
  $snap = @{ t = 'snap'; w = $found.ToArray(); all = $titles.ToArray(); err = $err; urls = $urls.ToArray(); bars = $bars; addrs = $addrs.ToArray() }
  [Console]::Out.WriteLine((ConvertTo-Json -Compress -Depth 4 $snap))
  [Console]::Out.Flush()
  Start-Sleep -Milliseconds $interval
}
"""


class CallWatcher:
    """Runs the PowerShell reader and turns its snapshots into events."""

    SUPPORTED = os.name == "nt"
    INTERVAL_MS = 900

    def __init__(self, calls):
        self.calls = calls
        self.detector = CallDetector()
        self._last_contact_id = None   # last call id read from an address bar
        self._lock = threading.Lock()
        self._proc_lock = threading.RLock()
        self._cdp = cdp.CdpReader()
        self._ps_msg = None            # latest snapshots from the two readers
        self._cdp_msg = None
        self._proc = None
        self._thread = None
        self._generation = 0
        self.enabled = False
        self.match = DEFAULT_MATCH
        self.status = {"state": "off", "message": "", "windows": 0,
                       "last_scan": None}

    # ---- control ---------------------------------------------------------
    def configure(self, enabled, match, ignore, rules=None,
                  off_message="Turned off in Settings."):
        """Apply settings; (re)start or stop the reader as needed."""
        if rules is not None:
            self.detector.set_rules(parse_rules(rules))
        ignore_set = set()
        for part in re.split(r"[,\n;]", ignore or ""):
            num = normalize_phone(part)
            if num:
                ignore_set.add(num)
        self.detector.set_ignore(ignore_set)

        match = match or ""
        changed = (bool(enabled) != self.enabled) or (match != self.match)
        if not enabled:
            self._off_message = off_message
        self.enabled, self.match = bool(enabled), match
        # Saving Settings again after a failure is the natural "try again".
        failed = self.status.get("state") == "error"
        if not changed and not failed and (self._thread or not self.enabled):
            if not self.enabled:
                self._set(state="off", message=self._off_message)
            return
        self.stop()
        if not self.enabled:
            self._set(state="off", message=getattr(self, "_off_message", "Turned off in Settings."))
            return
        pattern = keyword_regex(match, anchored=True)
        if not self.SUPPORTED:
            self._set(state="unsupported",
                      message="Reading other windows needs Windows; the "
                              "/call?phone= screen-pop route still works.")
            if pattern:
                self._generation += 1
                self._start_cdp(self._generation, pattern)
            return
        if not pattern:
            self._set(state="error", message="Add at least one window keyword.")
            return
        self._generation += 1
        self._thread = threading.Thread(target=self._run,
                                        args=(self._generation, pattern),
                                        daemon=True, name="callwatch")
        self._thread.start()
        self._start_cdp(self._generation, pattern)

    def restart(self):
        """Stop the reader and start it again with a clean baseline.

        The Refresh button. Anything already on screen when it comes back up
        is the new baseline, so only a number that appears afterwards counts.
        Returns True if a reader was started.
        """
        if not self.enabled:
            return False
        if not self.SUPPORTED:
            self._set(state="unsupported",
                      message="Reading other windows needs Windows; the "
                              "/call?phone= screen-pop route still works.")
            return False
        pattern = keyword_regex(self.match, anchored=True)
        if not pattern:
            self._set(state="error", message="Add at least one window keyword.")
            return False
        self.stop()
        old = self.detector
        self.detector = CallDetector(ignore=old.ignore, rules=old.rules)
        self._set(state="starting", message="Restarting the window reader...",
                  windows=0, titles=[], scan=[], toasts=0, last_scan=None)
        self._ps_msg = self._cdp_msg = None
        self._generation += 1
        self._thread = threading.Thread(target=self._run,
                                        args=(self._generation, pattern),
                                        daemon=True, name="callwatch")
        self._thread.start()
        self._start_cdp(self._generation, pattern)
        return True

    def stop(self):
        with self._lock:
            self._generation += 1
            proc, self._proc = self._proc, None
            self._thread = None
        if proc and proc.poll() is None:
            try:
                proc.kill()
            except OSError:
                pass

    # ---- the browser reader (MAX opened with "Open MAX") -------------------
    def _start_cdp(self, gen, pattern):
        try:
            title_regex = re.compile(pattern)
        except re.error:
            title_regex = None
        threading.Thread(target=self._cdp_run, args=(gen, title_regex),
                         daemon=True, name="callwatch-cdp").start()

    def _cdp_run(self, gen, title_regex):
        was = None
        while gen == self._generation:
            try:
                msg = self._cdp.poll(title_regex)
            except Exception as err:        # never let this thread die quietly
                msg = {"state": "off", "message": "", "sources": [], "urls": [],
                       "titles": [], "error": str(err)[:120]}
            if gen != self._generation:
                break
            self._cdp_msg = msg
            self._set(browser=msg["state"], browser_message=msg["message"])
            if msg["state"] == "connected" or was == "connected":
                self._process()             # also once when it goes away
            was = msg["state"]
            time.sleep(self.INTERVAL_MS / 1000.0 if msg["state"] == "connected" else 3.0)
        self._cdp.close()

    def snapshot_status(self):
        s = dict(self.status)
        s["supported"] = self.SUPPORTED
        s["ambiguous"] = self.detector.last_ambiguous
        s["last_call"] = self.detector.last_call
        return s

    def classify_text(self, text):
        """Contact type for text that came with a screen pop (?skill=)."""
        return classify(self.detector.rules, _lines(text))

    def note_external(self, num):
        self.detector.note_external(num)

    # ---- internals -------------------------------------------------------
    def _set(self, **kw):
        self.status.update(kw)

    def _spawn(self, pattern):
        encoded = base64.b64encode(_PS_SCRIPT.encode("utf-16-le")).decode("ascii")
        env = dict(os.environ, TA_MATCH=pattern,
                   TA_TOAST=keyword_regex(self.match) or "(?!)",
                   TA_URL=URL_MATCH,
                   TA_INTERVAL_MS=str(self.INTERVAL_MS))
        return subprocess.Popen(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive",
             "-ExecutionPolicy", "Bypass", "-EncodedCommand", encoded],
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, env=env,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))

    def _run(self, gen, pattern):
        backoff = 2
        while gen == self._generation:
            self._set(state="starting", message="Starting the window reader...")
            try:
                proc = self._spawn(pattern)
            except OSError as err:
                self._set(state="error", message=f"Could not start PowerShell: {err}")
                return
            with self._lock:
                if gen != self._generation:
                    proc.kill()
                    return
                self._proc = proc
            started = time.time()
            for raw in proc.stdout:
                if gen != self._generation:
                    break
                self._handle_line(raw.decode("utf-8", "replace").strip())
            if gen != self._generation:
                return
            tail = ""
            try:
                tail = proc.stderr.read().decode("utf-8", "replace").strip()
            except Exception:
                pass
            proc.wait()
            # Constrained Language Mode or a blocked PowerShell fails instantly
            # and every time; say so instead of silently retrying forever.
            msg = tail.splitlines()[-1] if tail else f"exited with code {proc.returncode}"
            self._set(state="error", message=f"Window reader stopped: {msg[:300]}")
            if time.time() - started > 60:
                backoff = 2
            time.sleep(backoff)
            backoff = min(backoff * 2, 60)

    @staticmethod
    def _no_match_message(titles):
        # The fastest way to find MAX's real title is to see the list.
        if isinstance(titles, str):
            titles = [titles]
        shown = [t[:60] for t in (titles or []) if t and t != "Program Manager"][:8]
        base = "Running - no window title starts with a keyword yet."
        if shown:
            base += " Open windows: " + "; ".join(f'"{t}"' for t in shown) + "."
        return base

    @staticmethod
    def _scan_hint(items, doc, minimized=False):
        """A plain-English pointer when a window is found but can't be read."""
        if minimized and isinstance(items, int) and items < 15:
            return ("This window is minimized, and Windows hides a minimized "
                    "window's contents from TickAssist. Start MAX with the Open "
                    "MAX button (or the desktop shortcut) and it can be read "
                    "even when minimized.")
        if doc == 0:
            return ("Only the browser frame is readable, not the page itself. In "
                    "Chrome open chrome://accessibility, turn on Native "
                    "accessibility API support, restart Chrome, then press "
                    "Refresh. If MAX runs in a remote desktop or Citrix session "
                    "it cannot be read from this PC.")
        if doc == 1 and isinstance(items, int) and items < 15:
            return ("The page is readable but nearly empty - MAX may still be "
                    "loading or signed out.")
        return None

    def _scan_info(self, sources):
        """What the reader can see right now, for the Settings page."""
        scan = []
        for s in sources:
            if s.get("k") != "window":
                continue
            text = f"{s.get('title') or ''}\n{s.get('text') or ''}"
            nums = [format_phone(n) for n in find_phones(text)
                    if n not in self.detector.ignore]
            items, doc = s.get("n"), s.get("doc")
            scan.append({"title": (s.get("title") or "")[:80], "items": items,
                         "doc": doc, "numbers": nums[:6], "minimized": bool(s.get("min")),
                         "hint": self._scan_hint(items, doc, bool(s.get("min")))})
        return scan[:5]

    def _handle_url(self, url):
        """A call page's address names the call: publish its id once."""
        info = parse_call_url(url)
        if not info:
            return
        # Still on screen: remember the call, so a page opened (or a Transfer
        # drawer used) after the call began can still pick its id up from
        # the status. It is dropped a minute after the page goes away.
        self._set(call_page_id=info["contact_id"], call_page_at=time.time(),
                  call_page_phone=info["ani"] or None)
        if info["contact_id"] == self._last_contact_id:
            return
        self._last_contact_id = info["contact_id"]
        num = info["ani"]
        if not num or num in self.detector.ignore:
            return
        case = _one_case([info["case"]]) if info["case"] else None
        last = self.detector.last_call
        # MAX usually reported this caller first: then this only adds the id.
        same = bool(last and last.get("phone") == format_phone(num) and
                    self.detector.clock() - last.get("at", 0) < 300)
        if not same:
            self.detector.note_external(num)
        self.calls.publish(num, "address-bar", update=same, case_number=case,
                           contact_id=info["contact_id"])

    def _handle_line(self, line):
        if not line.startswith("{"):
            return
        try:
            msg = json.loads(line)
        except ValueError:
            return
        if msg.get("t") == "ready":
            self._set(state="running", message="Waiting for a matching window.")
            return
        if msg.get("t") != "snap":
            return
        self._ps_msg = msg
        self._process()

    @staticmethod
    def _listed(value):
        if isinstance(value, dict):     # PowerShell unwraps one-item arrays
            return [value]
        if isinstance(value, str):
            return [value]
        return list(value or [])

    def _process(self):
        """Combine the newest window-reader and browser-reader snapshots."""
        with self._proc_lock:
            ps = self._ps_msg or {}
            web = self._cdp_msg or {}
            msg = dict(ps, t="snap")
            msg["w"] = self._listed(ps.get("w")) + list(web.get("sources") or [])
            msg["all"] = self._listed(ps.get("all")) + list(web.get("titles") or [])
            msg["urls"] = self._listed(ps.get("urls")) + list(web.get("urls") or [])
            if not ps and not web.get("sources") and not web.get("urls"):
                return
            self._apply(msg)

    def _apply(self, msg):
        sources = msg.get("w") or []
        if isinstance(sources, dict):
            sources = [sources]
        windows = [s for s in sources if s.get("k") == "window"]
        self._set(scan=self._scan_info(sources),
                  toasts=len([s for s in sources if s.get("k") == "toast"]))
        self._set(state="running", windows=len(windows), last_scan=time.time(),
                  titles=[s.get("title", "")[:80] for s in windows][:5],
                  message=(f"Reading {len(windows)} matching window"
                           f"{'' if len(windows) == 1 else 's'}." if windows
                           else self._no_match_message(msg.get("all"))))
        if msg.get("err"):
            self._set(message=f"Scan problem: {msg['err'][:200]}")
        at = self.status.get("call_page_at")
        if at and time.time() - at > 60:
            self._set(call_page_id=None, call_page_at=None, call_page_phone=None,
                      page_text=None)
        urls = msg.get("urls") or []
        if isinstance(urls, str):
            urls = [urls]
        if msg.get("bars") is not None and (msg.get("bars") or urls):
            addrs = msg.get("addrs") or []
            if isinstance(addrs, str):
                addrs = [addrs]
            self._set(address_bars=msg.get("bars") or 0,
                      addresses=[str(a)[:110] for a in addrs][:3])
        for url in urls:
            self._handle_url(url)
        # MAX's side panel prints the call page's address as plain text.
        for s in windows:
            blob = s.get("text") or ""
            if "transfer_pop2" not in blob:
                continue
            line = next((ln for ln in blob.splitlines() if "transfer_pop2" in ln), "")
            self._set(page_text=line[:110])
            self._handle_url(blob)
        for ev in self.detector.feed(sources):
            self.calls.publish(ev["phone"], ev["source"], ev.get("contact_type"),
                               ev.get("matched"), ev.get("update", False),
                               ev.get("case_number"))
