# TickAssist

A fully portable, local ticket-handling tool. It turns the original single-file
"Pro Technical Note Generator" into a local web app backed by SQLite, with a side
navbar for **Note Generator**, **Database**, and **Settings**.

No installation. No administrator rights. No external CDNs, fonts, or packages —
everything (including the Python runtime) is vendored in this folder.

## Quick start

1. Double-click **`run.bat`**.
2. Your browser opens to `http://localhost:8765/`.
3. To stop the server, close the console window (or press `Ctrl+C` in it).

That's it. The first run creates a `data\tickassist.db` SQLite database next to
the app and seeds the default dealer / device-type / Reco-unit lists.
Launching `run.bat` while TickAssist is already running simply opens a browser
tab to the existing instance instead of starting a second server.

## What's inside

```
TickAssist\
  run.bat              Launcher (finds the runtime, starts the server)
  VERSION              The version number, on one line - edit to bump it
  runtime\             Vendored Python 3.11 (embeddable build, no installer)
  data\                SQLite database lives here (created on first run)
  app\
    server.py          Stdlib HTTP server + JSON API + routing
    database.py        SQLite layer (settings, lists, macros, tickets)
    llm.py             Server-side AI-Polish proxy (Gemini / Anthropic)
    callwatch.py       Incoming-call detection (reads CXone MAX)
    d365.py            Dynamics 365 sign-in, cases and notes (Dataverse Web API)
    sheets.py          Google Sheet lookup for Imaging Package numbers
    features.py        Owner-controlled feature switches
    owner.json         Owner password hash and office defaults (office build)
    templates\
      index.html       Single-page app shell with the side navbar
    static\
      styles.css       Pure CSS theme (dark / light / high-contrast / LCARS)
      app.js           Frontend logic (vanilla JS, no dependencies)
```

The whole backend uses only the Python standard library (`http.server`,
`sqlite3`, `urllib`, `json`) — there is nothing to `pip install`.

## Version number

The badge in the top right comes from the **`VERSION`** file next to `run.bat`.
It holds the number and nothing else — edit that one line and reload the page;
no code change and no restart. The same value feeds `/api/health` and the HTTP
`Server` header, so there is only ever one place to change. If the file goes
missing, the app falls back to `FALLBACK_VERSION` in `server.py`.

## The rotation toggle

Top right, on every page: **First Impressions** or **Troubleshooting**. It is a
standing setting, not a per-note field — every note you save is stamped with it,
and it stays put across saves, Clear, and restarts until you switch it back, so
a whole shift gets tagged without touching it. On the First Impressions
rotation the whole topbar takes a rose tint, so which rotation you are logging
is answerable from any page at a glance.

Opening a saved ticket shows the rotation that ticket was taken on, and a second
copy of the toggle appears in the **Case Entry** header, right-aligned and
labelled *This ticket* — the rotation belongs with the ticket you are editing,
not with the app chrome. Flipping either copy retags just that ticket; the
rotation your next blank form starts from only moves when you flip the topbar
one with no ticket open. The Case Entry copy disappears when the edit session
ends.

The rotation is stored with the ticket and shown in the note preview, but it is
**stripped from the D365 copy** — it is internal bookkeeping, not case content
(the same treatment TITLE and DATE already get).

## The four sections

- **Note Generator** — the original form + live D365 preview. The **System
  Environment** block folds away (click its heading) to keep the form on one
  screen; collapsing only hides it — every field keeps its value, still saves
  and still restores — and the heading shows a summary of what is filled in.
  The choice is remembered, and the section springs open by itself if an
  import or an opened ticket puts something in it. Auto-formats the
  case title, builds the copy-ready service note, runs **AI Polish**, and
  **Save to Database** stores the ticket. Typing a phone number that has called
  before raises a **repeat-caller line** across the width beneath Contact Type
  and Phone Number — who they are, what they last called about, how many
  tickets in total and when the most recent was, plus **View** to open that
  caller's history. It matches on digits, so any formatting finds it; it is a
  line of text rather than a dialog, so it cannot interrupt typing with someone
  on the line; it can be dismissed, and stays dismissed for that number until
  you enter a different one or clear the form; and the note you are editing is
  never counted as its own previous call.
  `Ctrl+S` saves, `Ctrl+Enter` copies
  the note (with its photos, same as **Copy Note**), and `Ctrl+P` prints just
  the note. An unsaved draft survives
  browser restarts and is restored automatically. **New D365 Case** opens a
  fresh case form in Dynamics with the title and description prefilled (uses
  your existing browser sign-in — no API key) and seeds the Windows clipboard
  history: Ctrl+V pastes the phone into the Customer lookup, and Win+V holds
  the contact name, serial number, and the full note for the Timeline
  (requires Windows clipboard history, Settings > System > Clipboard). Saved
  tickets offer **Open in D365**, which looks their case number up in
  Dynamics search.
- **Database** — a searchable, sortable repository of saved tickets. The filter
  box searches case number, title, contact, phone, dealer, call type, and
  status, with dropdowns to narrow by status, contact type, or call type; a
  phone-shaped query matches on digits alone, so `4104986464` finds a number
  saved as `410-498-6464` (and the other way round). Click a row to preview its
  note; Open loads it back into the generator **in edit mode**, so saving
  updates the same ticket instead of creating a duplicate (a banner offers
  "Save as new" for forking it instead). Export CSV downloads every ticket for
  Excel.
- **Dashboard** — Insights, computed live from your saved tickets in SQL;
  nothing extra is tracked. KPI tiles (tickets, resolution and escalation
  rates, average per working day, busiest day) read over a window you pick —
  **1d / 7d / 30d / All** — chosen above the tiles and remembered. Every panel
  below carries the same selector in its own header, right-aligned, and each
  remembers its own window independently: you can leave Top dealers on All
  while Resolution status sits on 7d. All four windows are computed in one
  query and ship in the same response, so switching any of them is instant and
  costs no round trip. Two panels keep fixed spans on purpose — the volume
  chart states its own in its title, and the day-of-week pattern needs several
  weeks before it means anything. Then a 30-day volume
  chart whose columns are **split by call type** — rose for First Impressions,
  brand blue for Troubleshooting, with weekends banded grey so a gap reads as
  "not a working day" rather than a quiet one. **How your week runs**, at the
  bottom, states the day-of-week pattern in plain sentences instead of a chart.
  Three corrections are applied before those days are comparable: averages
  count only the days each weekday was actually worked (a weekday that has come
  round more often would otherwise look busier), **today is left out** until it
  is finished (a part-done day averaged in with finished ones drags its weekday
  down), and each troubleshooting call counts as **three** first impressions,
  since an intake rotation wins on raw volume by its nature. Totals, the 30-day
  chart, and the busiest-day tile all still include today — the exclusion
  applies only where a figure is divided by a number of days, which is also why
  the panel's note count sits below the all-time total. Each line reads `~N calls per day (weighted score: N.NN)` —
  the call count is what happened and stays whole, while the score is only what
  orders the list and carries two decimals, since it is an index rather than a
  tally. That is why two days showing the same call count can still rank
  differently. The exchange rate
  is `TROUBLESHOOTING_WEIGHT` in `database.py`; if a build ever serves stats
  without the weighted fields, the panel drops the score and falls back to
  plain call volume rather than showing a figure it cannot back.
  **Where escalations go** is colour-coded by the rotation each escalation came
  from, which is worth a look: First Impressions almost only hands off *for
  troubleshooting*, while troubleshooting calls are what actually go out to
  dealers, IT, and third parties — the combined bars hid that entirely.
  Resolution statuses are outcome categories, not a severity scale: green
  is closed in-house, amber is pending on the customer, and blue is correctly
  routed onward — an escalation is never a failure. The two call-type hues are
  deliberately outside that status set and were checked for colour-blind
  separation against each theme surface.
- **Settings** — one page, one scroll, no tabs. **Integrations** sits at the
  top as a row of tiles, one per connection to another system (Incoming calls
  from CXone MAX, Dynamics 365, Google Sheet), each showing its live status.
  Clicking a tile slides that integration's setup in as a drawer from the right,
  over the page, so nothing on the page moves and the rest of Settings keeps
  its layout: Appearance, Merge Databases, AI Polish, the three managed lists
  and macros. A drawer saves only its own fields (**Save**, or `Ctrl+S` while
  it is open), and closing one with unsaved changes asks before discarding
  them. **Features** (top right of the page, see below) opens the same way.
  The sidebar's **Connections** list, below the nav, shows the integrations
  that are set up on this PC with a status dot - green live, amber needs a
  look - from every page, and a click opens that integration's drawer without
  leaving the page you are on. Nothing is listed there until something is set
  up. If D365 says your sign-in has lapsed while you are creating a case,
  **Sign in again** under the error opens the D365 drawer over the note.
- **Merge Databases** (Settings): **Choose a database…**
  opens a file dialog, **Choose a folder…** opens a folder dialog and finds the
  database inside it (a path can still be typed instead, under the fold). A
  browser never reveals a file's path, so a picked database is uploaded to this
  local server and merged from a temp copy which is deleted afterwards. It
  reports what it found before writing anything. Both ticket
  layouts are recognised and mapped — the desktop app's `prob` / `reso` /
  `img_pkg` columns land in the right places, its split `win` / `mac` columns
  become one OS field, and its queue is kept in the case title rather than
  dropped. Rows already present are matched on full content and skipped, so
  merging the same source twice is a no-op. Photos come along with their tickets (onto the
  matching ticket when the ticket itself is already here, skipping any it
  already has), and dealers, device types, Reco units and macros that are
  missing are added — where both databases have a macro with the same
  trigger, yours is kept. Settings, the D365 sign-in and the features password
  never come across. The current database is snapshotted
  to `data\tickassist-premerge-<timestamp>.db` before anything is added.
  Merging from another PC: close TickAssist there first, then copy its
  `data\tickassist.db` — closing it writes any pending changes into that file.
  Transfer call (button above the note preview) sends the active call to a
  troubleshooting queue: it uses the Contact Name and Case ID fields, asks you
  to confirm, and posts to the address under Transfer setup (the old Call
  Triage page's signal.php). The call's ID is read from the address bar of the
  CXone call page (transfer_pop2.html?contactId=...) by the window reader, or
  arrives by screen pop: `/call?phone={ANI}&contactId={CONTACTID}`.
  AI Polish never drops detail: if the rewrite loses steps, numbers or error codes
  it is retried once, then your own text is kept; "Undo Polish" restores the
  fields from before the last polish.
  Settings has two tabs: General, and Lists & Macros (dealers, device types,
  Reco units, required-field rules, shorthand macros). Required fields: rules
  such as "Device Type is hardware -> Serial Number, OS Version, Firmware" block
  Save until filled (Shift+Click on Save skips, as for the Case ID).
  Sheet cross-check: with a sheet row found for the Imaging Package, system
  environment values that differ from that row get a red outline and a line
  under the package fields ("Use sheet values" copies the sheet's in).
  First Impressions works step by step: Caller, System Environment, Diagnostics,
  Case Details, Resolution. A step folds into a summary when you leave it with
  its required fields filled (Required Fields rules, per call type), the next
  opens, and later steps stay locked until then ("Open all sections" or
  Shift+click a locked step lifts that). Troubleshooting shows everything. The OS is a
  set of check boxes (several systems per call), and every System Environment
  field is a typable dropdown fed by saved tickets (Settings > Lists & Macros).
  Also: theme (Auto follows the Windows light/dark setting; dark,
  light, high-contrast, and LCARS can be pinned — the topbar button
  quick-toggles light/dark; LCARS is the Star Trek console look, whose elbow
  and rail turn lavender on the First Impressions rotation, and a scanner
  highlight sweeps the top strip, speeding up with a scan band over the note
  and pulsing fields while AI Polish is working — all off if Windows is set
  to reduce motion). On LCARS an incoming call also opens a transmission
  card (the caller's name, class, dealer, last device, last issue and status
  from the database, or "no prior record"), and yellow / red alert effects run
  when conditions you set in Settings > Alert Conditions are met (by default:
  handle time reaching 10 / 15 minutes, and safety words such as smoke or
  fire in the note), the AI Polish provider, model, and API key, plus the managed
  lists (dealers, device types, Reco units) and shorthand macros. List entries
  typed directly into ticket fields are auto-registered on save.

## Incoming calls (CXone MAX)

When a call comes in on CXone MAX (RingCentral Contact Center), TickAssist
reads the caller's number and puts it in **Phone Number**, which also brings up
the repeat-caller line. It only fills an **empty** field with no saved ticket
open. If you are still writing the last note, the number is offered on a line
under the field (**Use this number**), and it fills in by itself when that
note is saved or cleared, as long as that happens within 10 minutes.

It also sets **Contact Type** from the skill MAX shows with the call, so
`FI-Dealer Support` comes in as **Dealer**. That is set by **Caller type
rules** in Settings, one per line as `text in MAX = Contact Type`, with the top
rule winning:

```
Dealer = Dealer
IT = IT
Sales = Sales
Military = Military
End User = End User
```

A rule matches whole words (`FI-Dealer` contains the word `Dealer`), and a
keyword written in capitals, like `IT`, only matches capitals. Only text that
appears with the call is used, and text naming a different phone number is
skipped: MAX redraws rows of its call history as a new call arrives, and one
of those (`3174305321FI - Dealer Support08:01`) once typed an FI - IT Support
call as Dealer. The caller's own row is read first, then text naming no number
at all; numbers on the never-use list don't count as another caller. The same
goes for case numbers. If no rule matches, Contact Type is left alone, and the status
line in Settings shows the text that came with the call so you can write a
rule for it. The Contact Type is only set together with a number TickAssist
filled itself, never on a number you typed.

**Case number.** If a case number shows up in MAX with the call - such as
**Inbound Case Reference: CAS0490097** in the Call Triage & Transfer panel -
TickAssist puts it in **Case ID**. That panel can load when the call is
answered rather than when it rings, so a case number appearing up to two
minutes after the call still counts. It only fills a blank Case ID (never
replaces one already there, and tells you if MAX shows a different one), only
for a number TickAssist filled itself, and skips it if two different case
numbers appear at once. The screen-pop route takes it as `&case=CAS0490097`
too.

**Known callers.** When a number already in your database lands in Phone
Number - from MAX, or typed by hand - TickAssist fills **Contact Name** and
**Contact Type** from that caller's most recent ticket that has a name, and
for a dealer **Dealer Company** too, so 828-430-1927 comes in as Keith,
Dealer, Henry Schein. It only fills empty fields: Contact Type counts as empty
while it still says End User and you have not picked it yourself on this note.
A typed number fills once all 10 digits are in, so a half-typed one cannot
match a stranger, and if you then change the number, whatever the old one
filled goes back out (unless you have edited it since). A skill MAX shows
with the call still decides Contact Type; if it says the caller is not a
dealer, the copied dealer is taken back out. Nothing is filled while a saved
ticket is open. If the same number has been used by different people (a
dealer's main line, say), the toast names the others so you can correct it.

How it reads MAX: it uses Windows UI Automation, the accessibility interface
screen readers use, through a hidden PowerShell helper. Nothing to install and
no admin rights. Every ~1 s it looks at:

- windows whose **title starts with** one of the keywords (default `MAX`,
  `niceincontact`, `CXone`, `Mpower`), and
- Windows notifications whose text contains one, which covers MAX's
  "New Contact" desktop notification.

When it first sees a window, it records the numbers already showing (history,
your own line) and ignores them. Only a number that appears after that counts
as a caller. If several new numbers appear at once, nothing is filled and
Settings shows which ones it skipped.

Setup and troubleshooting (Settings > Integrations > Incoming calls, or the
**CXone MAX** row under Connections):

- Run MAX in its **own window** (it pops out of CXone that way). If MAX is
  just a tab, its title only shows while that tab is active.
- In MAX, Settings > Visual, turn on **New Contact** notifications (Chrome
  or Firefox; MAX does not offer them in Edge).
- The status line shows what it is reading. If nothing matches, it lists
  your open window titles, so you can copy MAX's real title start into
  **Window keywords**.
- Add your own team lines (anything MAX shows that is not the caller) to
  **Never use these numbers**.
- If it reports that PowerShell is blocked (some locked-down PCs run it in
  Constrained Language Mode), use the screen pop below instead.

**Screen pop (more reliable, needs a CXone admin):** a Studio `POPURL` /
`RUNAPP` action pointed at `http://localhost:8765/call?phone={ANI}` sends the
caller's number straight to TickAssist, without reading the screen. Adding
`&skill=` with the skill-name variable sets Contact Type through the same rules.

## Photos

Under the Note Preview is a **Photos** area. Paste a screenshot anywhere on
the Note Generator (Ctrl+V), drop image files on it, or use **Add Photos**.
Photos are kept in the local database with the ticket: an unsaved form's
photos are saved with it, reopening a ticket brings them back, Clear discards
unsaved ones, and deleting a ticket deletes its photos. The repository shows a
camera and count next to tickets that have them.

Large photos are scaled to 2000 px on the long side as they come in (small
ones and screenshots are kept as they are), which keeps the database small and
each file well under D365's default 5 MB attachment limit. iPhone HEIC files
can't be opened by the browser; share them as JPEG.

Getting them into D365 without an integration:

- **Copy** puts the image on the clipboard; Ctrl+V pastes it into a D365
  timeline note's text.
- **Save** downloads it as `CAS0485494-1.jpg` for the note's attachment
  button. Dragging a photo to the desktop or a folder saves it the same way.
- **Copy All** and **Save All** do every photo at once - after Copy All, Win+V
  lists them. **New D365 Case** also loads them into clipboard history,
  below the phone, contact, serial and note.


**Photos paste with the note.** When the ticket has photos, **Copy** puts the
note and its photos on the clipboard together, so one Ctrl+V in the D365 note
brings the text with the pictures below it (D365's rich-text notes keep pasted
images with the note). Large photos are scaled to 1280 px for the paste; the
stored originals are unchanged. **New D365 Case** does the same for the note
it loads into Win+V. Pasting somewhere that only takes text gets just the
text. If your D365 notes are plain text (no formatting toolbar), the images
won't come across - use **Copy All** or **Save All** as before.

## Dynamics 365

TickAssist can create cases and add notes in D365 itself, signed in as you
(Settings > Integrations > **Dynamics 365**). Signed out, the buttons work as before: **New
D365 Case** opens a prefilled form and the note goes via the clipboard.

**One-time setup (IT).** In Microsoft Entra ID > App registrations, register
an app (single tenant), then:

1. **Authentication** > Add a platform > **Mobile and desktop applications**,
   redirect URI `http://localhost/d365/callback`.
2. Same page: **Allow public client flows** = Yes.
3. **API permissions** > Add > Dynamics CRM > Delegated > `user_impersonation`,
   with admin consent if users can't consent themselves.

No client secret is used. Enter the **Directory (tenant) ID** and
**Application (client) ID** from the app's Overview page, press **Sign in**,
and finish the Microsoft sign-in in the tab that opens. **Test** confirms the
connection and loads your org's Case Type and Origin choices, and lists any
other fields your case form requires; put those in **Other case fields** as
JSON (for example `{"prioritycode": 2}`, or
`{"new_product@odata.bind": "/new_products(<id>)"}` for a lookup).

**New D365 Case** (signed in) opens a dialog with the title, the description,
and the customer: it searches D365 contacts and accounts by the phone number
(any format) and preselects a single match, or you search by name or account
number. **Create Case** creates it, puts the case number in **Case ID**, adds
the note to the timeline, attaches the photos (one note each, since a D365
note holds one file), and opens the case in a new tab. By default the customer
is the contact's account with the contact as Primary Contact; Settings can
make it the contact instead.

**Send to D365** adds the note (and any photos not sent yet) to the case in
**Case ID**, after showing which case that is.

The sign-in is kept in the local database (`d365_refresh_token`, never shown
in the page); **Sign out** removes it. Changing the URL, tenant or client ID
also signs out. TickAssist can only do what your own D365 role allows.

## Google Sheet lookup

Type an **Imaging Package** number in the Note Generator and TickAssist looks it
up in a Google Sheet and fills the other fields from that row (OS, Romexis,
DIDAPI, firmware, Reco details, and so on). It only fills **empty** fields
unless Settings says otherwise, so nothing you typed is overwritten. A match
fills in quietly while you type; "isn't in the sheet" is only reported once you
leave the field.

Setup (Settings > Integrations > Google Sheet):

1. Share the sheet as **Anyone with the link can view** (or File > Share >
   Publish to web). TickAssist only reads it; nothing is written to Google.
2. Paste the sheet's link. A link to a particular tab keeps that tab (`gid`).
3. Set the **key column** (default `Imaging Package`).
4. Columns whose header already reads like a field map by themselves (`OS`,
   `Romexis Ver`, `DIDAPI`, `Device Firmware`, `Reco Unit`, ...). For any
   other, add a line to **Column mapping**: `Sheet column = TickAssist field`.
5. Press **Test**: it shows the row count and how every column mapped.

**Several tables in one column.** If the same column also holds another block
lower down (e.g. a "Viso Package" heading with its own package numbers), the
lookup sees each block as a section. A number found in more than one section
fills from the section whose name matches the ticket's **Device Type** (a Device
Type containing "Viso" prefers the Viso block); otherwise from the first one.
The other matches show as "Use ..." buttons under the Imaging Package field.

The sheet is fetched by the server (`app\sheets.py`) and cached for a minute;
if Google can't be reached, the last copy is used. Needs internet. It is a
feature (**Google Sheet lookup**) the owner can switch off like the others.

## Features (owner-controlled)

**Settings → Features** (the button at the top right of Settings) shows which add-ons this copy offers: incoming calls
from MAX, Contact Type from the MAX skill, known caller details, case number
from MAX, photos, the Dynamics 365 integration, Merge Databases, Google Sheet lookup and AI Polish.
A feature that is off is hidden on the page and its server routes are refused
(with D365 off, **New D365 Case** opens the browser form as it did before the
integration).

Only the owner can change them. The owner password's salted hash lives in
`app\owner.json`, which ships with the office build. It is not in the
database, and nothing in the app can set, change or reset it. Entering it in
Settings → Features lets the owner set one PC differently, or return that PC
to the office defaults.

The hash is one-way: a forgotten owner password cannot be read back, only
replaced. `tools\set-owner-password.bat` does that - it asks for a new one
twice and writes its hash into `app\owner.json`, keeping the office defaults.
It does not need the old password, so like the rest of `tools\` it stays on
the owner's PC.

### For the owner: tools\owner-tools.bat

Keep the `tools` folder on your own PC — anyone with it could set their own
owner password. Run `tools\owner-tools.bat`:

1. **Set or change the owner password** (the current one is needed to change it).
2. **Choose the office default features** — what every PC gets unless you set
   it differently there.
3. **Build the office packages** — in `tools\packages`:
   `TickAssist-<version>-office-install.zip` (full app with its Python, for a
   new PC) and `TickAssist-<version>-office-update.zip` (for unzipping over an
   existing install). Both carry your owner password and defaults, and leave
   out `data\` and `tools\`, so nobody's tickets are overwritten and the
   tools never leave your PC.

4. **Copy this PC's settings into the office build** — your Incoming Calls
   window keywords, never-use numbers and caller type rules, your D365 setup
   (URL, tenant and client IDs, case type and origin) and the AI Polish
   provider and model; optionally your AI Polish API key. Settings live in each
   PC's own database, so without this a new PC starts from the built-in ones.
   A PC uses the office value unless someone changed that setting on it.
5. **Push to every PC** — the next time each PC starts an update built after
   this, it forgets its own feature choices and its own copies of the office
   settings, once, and follows the office build. Use it when PCs have drifted.

Changing features on a PC: open Settings → Features, tick the ones you
want, enter the owner password and **Save Features**. The page reloads so
every feature starts up properly. If it says TickAssist was updated while it
was running, close the TickAssist window and start it again with `run.bat`
first - an update unzipped over a running copy is not live until then.

Ticket history is per PC too: **Known caller details** only fills a name and
company from tickets in that PC's own database. Merge your database into a
new PC (Settings → Merge Databases) to give it your history.

Give the office only those zips — not your own TickAssist folder, and not the
plain update zips you receive while developing.

This stops anyone using TickAssist from changing features. It is not
tamper-proofing: someone who edits the program files themselves could get
round it.

## Shorthand macros

Define a trigger like `\rem` on the Settings page, then type it in any
generator field followed by space / Enter / Tab to expand it — multi-line
expansions included. `Ctrl+Z` undoes an expansion.

## AI Polish

The API key is stored locally in the SQLite database and used **server-side**,
so it never leaves the machine except toward the provider. Two providers are
supported:

- **Google Gemini** (default) — model e.g. `gemini-2.5-flash`
- **Anthropic Claude** — model e.g. `claude-haiku-4-5-20251001`

Set the provider, model, and key on the Settings page. AI Polish needs internet
access to reach the provider; everything else works fully offline.

## Browser autofill

TickAssist turns off the browser's autofill on every field, and its secret
fields (the AI API key, the owner password) are drawn as dots without being
password fields - so the browser never mistakes the page for a login and
offers to save or fill one. Before 4.11 it could: the browser saved the AI
model name as a "username" for localhost and then filled it into **Part
Recommendation**. If that happened to you, delete the saved password for
`localhost` in the browser (Edge: Settings → Passwords; Chrome: Settings →
Autofill and passwords → Google Password Manager) - it also holds your API key.

## Portability notes

- `run.bat` prefers the vendored `runtime\python.exe`. If that folder is ever
  removed, it falls back to a system Python (`py -3` or `python` on PATH),
  skipping the Microsoft Store stub.
- To restore the vendored runtime, download the **Windows embeddable package
  (64-bit)** for Python 3.11 from python.org and extract it into a folder named
  `runtime` next to `run.bat`. (It already includes `sqlite3` and TLS support.)
- The server binds to localhost only, so it is not reachable from the network.

## Moving / backing up

Copy the whole `TickAssist` folder anywhere (USB stick, network drive, another
PC) and run it — it is self-contained. Your tickets and settings live in
`data\tickassist.db`; back up that file (or use **Export CSV** on the Database
page) to keep your data.

- **4.37** - New D365 Case with a Case ID already entered now opens D365's search for that case (note loaded on the clipboard for the timeline) instead of a blank duplicate form. Shift+click still forces a new case.
- **4.38** - First Impressions sections no longer fold when you click away (that shifted the page under the mouse and ate clicks); they fold only when you Tab out, or via the header. Typable dropdowns: Enter now picks the highlighted suggestion, else the exact/first match.
- **4.39** - Several Google Sheets (each looked up by its own field, e.g. Imaging Package or Serial Number, filling its own fields); TickAssist Lite (no database: settings, lists and macros are JSON files, history is session-only); a per-user installer; and one-click updates from a web address or GitHub release (Settings > Updates).

## TickAssist Lite, the installer and updates (4.39)

**Lite** is the same program without the ticket database. Settings, the dropdown
lists and macros are plain JSON files (`settings.json`, `lists.json`, `macros.json`)
in the data folder; the Ticket Repository, call card and photos still work, but
only for the current session and are gone when TickAssist closes. Merge
Databases is switched off. A Lite build is marked by `app/edition.txt` (the text
`lite`); without that file it is the full edition.

**Installing on a PC** (no administrator rights needed): unzip `TickAssist-Lite-Setup-<ver>.zip` and
double-click **Install TickAssist.bat**. It installs for the current Windows user into
`%LOCALAPPDATA%\Programs\TickAssist`, adds Start menu and desktop shortcuts and an entry in
Settings > Apps, and another program can start it with `%LOCALAPPDATA%\Programs\TickAssist\run.bat`.
With an administrator available, **Install TickAssist (Program Files).bat** installs to
`C:\Program Files\TickAssist` for everyone on the PC instead (it asks Windows for permission and lets
all users run the one-click update). Settings and lists live in `%APPDATA%\TickAssist`, so
reinstalling, updating or uninstalling never loses them (the uninstaller asks before deleting them).
Scripted installs: `powershell -File install.ps1 -Quiet` (add `-ProgramFiles` from an elevated prompt).

**Updating a PC**: Settings > General > Updates. Paste the update address once;
TickAssist checks it whenever it opens and shows an *Update x.y available* button
in the top bar. One click downloads the update, replaces the program files
(never the data, `app/owner.json` or the bundled Python), keeps the previous
version in `<data>/updates/backup`, restarts itself and reloads the page. If
anything fails halfway, the old files are put back. The owner can push the address
to every PC with the office settings (`update_url`).

**Publishing an update** (owner): bump `VERSION`, add a `- **x.y** - what changed`
line below, then run `python tools/make_release.py`. In `dist/` you get
`TickAssist-Lite-Setup-x.y.zip` (new PCs), `TickAssist-Lite-x.y-update.zip` plus
`latest.json` (upload both to one web folder - that folder's `latest.json` address
is the update address), and the same for the full edition (`latest-full.json`).
A GitHub repository or releases address also works as the update address: attach
the `-update.zip` to a release tagged with the version. `latest.json` carries a
SHA-256 checksum, which the PC verifies before installing.

## Several Google Sheets (4.39)

Settings > Integrations > Google Sheets now takes a list of sheets. Each has its
own link, the TickAssist field it is looked up by (Imaging Package, Serial Number,
Device Type, Case ID, Phone, Dealer or Contact), the sheet column holding that
value, an optional column mapping and its own "replace filled fields" choice.
Typing a value in a lookup field reads every sheet keyed by it and fills the
mapped fields; a filled field can in turn trigger another sheet (a serial number
can fill the Imaging Package, which then fills the OS and Romexis from the package
sheet). Old single-sheet settings are carried over automatically.
- **4.40** - Lite gets Incoming calls from MAX, Contact Type and Case number from MAX, and Call transfer switched on (an update patches the office defaults once). Device Types (Promax, ProOne, ProSensor, Server, Workstation, Romexis) and Reco Units (5810, 3600, 3620, 3630, 3650, 3660, T2 2250) are now fixed lists that only an update changes. Device Type, Reco Unit and the System Environment fields only take values from their list: a near miss such as 23 vs 23.1.0 offers a short pick list, and an environment value can join a list only if a linked Google Sheet has it (Settings > Lists > Import values from my sheets). Romexis counts as a software device for required fields.
- **4.41** - Reco OS is a fixed list (CentOS, Ubuntu); the old Windows 10 / Windows 11 entries are removed. A GitHub repository address in Settings > Updates now also finds a latest.json (or Latest.json) in the repository itself, not only a published release.
- **5.0** - TickAssist 5. Lite can export the day's session (tickets, photos, lists, macros) as a .db file for the full edition's Merge Databases (Ticket Repository > Export for full TickAssist). The update address defaults to https://github.com/Ankokomen/Tickassist-Updates. Romexis versions are exempt from sheet verification (free text with suggestions, added on save, left out of Import from sheets). A fresh copy starts with the Imaging Package sheet and its column mapping already set.
- **5.1** - The call-transfer address (https://planmecawiki.com/tools/signal.php) is built in, so it no longer has to be entered. Every transfer is logged to transfer-log.txt in the data folder with what the service replied, and the Transfer drawer has an "Open the transfer page in my browser instead" button.
- **5.2** - A minimized MAX window can't be read by Windows, so the call watcher now says so on its status line. New option "Also read MAX while it is minimized" (Settings > Incoming calls, off by default) briefly shows the minimized window without taking focus, reads it, and minimizes it again.
- **5.3** - Read MAX in the background. "Open MAX" (Settings > Incoming calls, and a "TickAssist - Open MAX" desktop/Start shortcut made by the installer) opens MAX in Chrome or Edge in its own profile with a local-only debugging port. TickAssist then reads the MAX tab and the call page's address straight from the browser, so MAX can be minimized, behind other windows or on another screen. The old window reader still runs alongside. New settings: MAX address and browser.
- **5.4** - Removed "Also read MAX while it is minimized" (it briefly popped the window up). Use Open MAX instead to read MAX in the background. The Features page no longer asks for an owner password: switch features on or off and press Save.
