"""TickAssist - a portable native ticket-handling tool.

A self-contained local web server built on the Python standard library only.
Serves a single-page app (Note Generator / Database / Settings) and a small
JSON API backed by SQLite.

Run with the vendored runtime via run.bat, or directly:
    python app/server.py
"""

import csv
import io
import os
import sys
import json
import re
import socket
import subprocess
import tempfile
import threading
import time
import urllib.request
import webbrowser
from email.utils import formatdate, parsedate_to_datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

# Make sibling modules importable under the embeddable runtime, whose ._pth
# does not auto-add the script directory to sys.path.
APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

import callwatch  # noqa: E402
import cdp  # noqa: E402
import d365  # noqa: E402
import features  # noqa: E402
import database  # noqa: E402
import llm  # noqa: E402
import sheets  # noqa: E402
import transfer  # noqa: E402
import updater  # noqa: E402

ROOT_DIR = os.path.dirname(APP_DIR)


def _edition():
    """"lite" (no database, JSON files only) or "full". A Lite build ships an
    app/edition.txt that says so; TICKASSIST_EDITION overrides it for testing."""
    env = os.environ.get("TICKASSIST_EDITION", "").strip().lower()
    if env in ("lite", "full"):
        return env
    try:
        with open(os.path.join(APP_DIR, "edition.txt"), encoding="utf-8") as fh:
            return "lite" if fh.read().strip().lower() == "lite" else "full"
    except OSError:
        return "full"


EDITION = _edition()
# An installed copy keeps its data outside the program folder (so an update or
# an uninstall never touches it): the launcher sets TICKASSIST_DATA.
DATA_DIR = os.environ.get("TICKASSIST_DATA") or os.path.join(ROOT_DIR, "data")
STATIC_DIR = os.path.join(APP_DIR, "static")
TEMPLATE_DIR = os.path.join(APP_DIR, "templates")
DB_PATH = os.path.join(DATA_DIR, "tickassist.db")

HOST = "localhost"
PREFERRED_PORT = 8765

# A browser hands over the file itself, never its path, so a picked database
# arrives as an upload. Generous next to a ticket database of a few hundred KB,
# small enough that a mis-picked file cannot fill memory.
MAX_MERGE_UPLOAD = 4 * 1024 * 1024 * 1024  # photos make databases bigger
# Photos are resized in the browser before upload; this only stops a mistake.
MAX_PHOTO_UPLOAD = 25 * 1024 * 1024
PHOTO_TYPES = {"image/png", "image/jpeg", "image/gif", "image/webp", "image/bmp"}

# The app version lives in one place: the VERSION file next to run.bat. Edit
# that one line to bump it - it feeds the topbar badge, the health endpoint and
# the HTTP Server header. FALLBACK_VERSION only applies if the file is missing.
VERSION_FILE = os.path.join(ROOT_DIR, "VERSION")
FALLBACK_VERSION = "3.4"


def app_version():
    """Current version string, read fresh so an edit needs no code change."""
    try:
        with open(VERSION_FILE, "r", encoding="utf-8") as fh:
            return fh.read().strip().lstrip("vV") or FALLBACK_VERSION
    except OSError:
        return FALLBACK_VERSION

# The version this process started as. If the VERSION file says otherwise, an
# update was unzipped while TickAssist was running: the new pages are being
# served by the old program, and nothing behaves right until a restart.
STARTED_VERSION = app_version()


def restart_needed():
    return app_version() != STARTED_VERSION


CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".png": "image/png",
    ".woff2": "font/woff2",
    ".woff": "font/woff",
    ".json": "application/json; charset=utf-8",
}

if EDITION == "lite":
    import lite  # noqa: E402
    features.FORCED_OFF = {"merge"}
    db = lite.LiteStore(DATA_DIR)
    DB_PATH = db.path
else:
    db = database.Database(DB_PATH)

# Incoming calls: the screen reader and the /call push route both publish here;
# the Note Generator long-polls /api/incoming for the next one.
incoming = callwatch.IncomingCalls()
watcher = callwatch.CallWatcher(incoming)
crm = d365.D365Client(db)


DEFAULT_UPDATE_URL = "https://github.com/Ankokomen/Tickassist-Updates"
# The Call Triage page posts to a relative "signal.php", so from
# https://planmecawiki.com/tools/transfer_pop2.html it is this address. Built in,
# so nobody has to type it; a different address saved in Settings overrides it.
DEFAULT_TRANSFER_URL = "https://planmecawiki.com/tools/signal.php"


def _transfer_url(settings):
    return (settings.get("transfer_url") or "").strip() or DEFAULT_TRANSFER_URL


def _log_transfer(line):
    """One line per transfer attempt in <data>/transfer-log.txt, newest last,
    so what the service said is still there after the panel is closed."""
    path = os.path.join(DATA_DIR, "transfer-log.txt")
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        try:
            with open(path, encoding="utf-8") as fh:
                lines = fh.read().splitlines()[-199:]
        except OSError:
            lines = []
        lines.append(time.strftime("%Y-%m-%d %H:%M:%S ") + line)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
    except OSError:
        pass


def _update_url(settings):
    return (settings.get("update_url") or "").strip() or DEFAULT_UPDATE_URL


FIXED_MSG = "This list is fixed. New entries arrive with a TickAssist update."


def _check_update_url(value):
    if value is None:
        return None
    value = str(value).strip()
    if value and not updater._allowed(value):
        raise ValueError("The update address must start with https://")
    return value


def _restart_self():
    """Start a fresh copy of TickAssist, then end this one. The new copy waits
    for the port to come free (see main) and the page reloads itself."""
    launcher = os.path.join(ROOT_DIR, "run.bat")
    extra = "--no-browser --restarted"
    if os.name == "nt" and os.path.exists(launcher):
        subprocess.Popen('start "TickAssist" /min "%s" %s' % (launcher, extra), shell=True, cwd=ROOT_DIR)
    else:
        subprocess.Popen([sys.executable] + [a for a in sys.argv if a != "--restarted"] +
                         ["--no-browser", "--restarted"], cwd=ROOT_DIR)
    threading.Timer(0.6, lambda: os._exit(0)).start()


def _strip(value):
    return None if value is None else str(value).strip()


REQ_FIELD_IDS = {"serialNumber", "osVersion", "deviceFirmware", "deviceToolVersion",
                 "deviceType", "recoPc", "contact", "phone", "dealerName", "problem"}
REQ_KINDS = {"always", "hardware", "software", "device", "contact"}
REQ_DURING = {"", "First Impressions", "Troubleshooting"}


def _check_required_rules(raw):
    """Validate the Required Fields rules; return them as clean JSON text."""
    try:
        rules = json.loads(raw) if isinstance(raw, str) else raw
    except ValueError:
        raise ValueError("The required-field rules are not valid.")
    if not isinstance(rules, list) or len(rules) > 30:
        raise ValueError("The required-field rules are not valid.")
    clean = []
    for r in rules:
        if not isinstance(r, dict) or r.get("kind") not in REQ_KINDS:
            raise ValueError("A required-field rule has an unknown condition.")
        fields = [f for f in (r.get("fields") or []) if f in REQ_FIELD_IDS]
        during = r.get("during") or ""
        if during not in REQ_DURING:
            raise ValueError("A required-field rule has an unknown call type.")
        clean.append({"kind": r["kind"], "value": str(r.get("value") or "").strip()[:80],
                      "fields": list(dict.fromkeys(fields)), "during": during})
    return json.dumps(clean, separators=(",", ":"))


# How long one /api/incoming request is held open waiting for a call. Short
# enough to stay well inside any browser or proxy timeout.
INCOMING_HOLD_SECONDS = 25

# The made-up number the Settings > Test button sends (555-01xx is reserved
# for fiction, so it can never be a real caller).
TEST_CALL_DIGITS = "8005550100"


def apply_call_watch_settings(settings):
    # Switched-off features: no reading MAX at all, no caller-type rules, or no
    # case numbers passed on to the page.
    incoming.case_enabled = features.enabled(settings, "case_from_max")
    rules = settings.get("call_watch_rules", callwatch.DEFAULT_RULES)
    if not features.enabled(settings, "caller_type"):
        rules = ""
    feature_on = features.enabled(settings, "calls")
    watcher.configure(
        off_message=("Turned off with the checkbox above." if feature_on else
                     "Switched off in Settings > Features for this PC (or by the office defaults)."),
        enabled=(str(settings.get("call_watch_enabled", "1")) == "1" and feature_on),
        match=settings.get("call_watch_match", callwatch.DEFAULT_MATCH),
        ignore=settings.get("call_watch_ignore", ""),
        rules=rules,
        peek=str(settings.get("call_watch_peek", "0")) == "1",
    )


class Handler(BaseHTTPRequestHandler):
    server_version = "TickAssist/" + app_version()

    # ---- low-level helpers ---------------------------------------------
    def _send_json(self, payload, status=200):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_bytes(self, body, content_type, status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _error(self, message, status=400):
        self._send_json({"error": message}, status=status)

    def _read_json(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise ValueError("Request body was not valid JSON.")
        if not isinstance(data, dict):
            raise ValueError("Request body must be a JSON object.")
        return data

    # ---- routing --------------------------------------------------------
    # Routes that belong to a feature that can be switched off.
    FEATURE_ROUTES = [
        ("/call", "calls"), ("/api/callwatch", "calls"), ("/api/photos", "photos"), ("/d365/", "d365"),
        ("/api/d365/", "d365"), ("/api/merge", "merge"), ("/api/polish", "polish"),
        ("/api/sheet", "sheet"), ("/api/transfer", "transfer"),
    ]

    def _feature_blocked(self, path):
        for prefix, key in self.FEATURE_ROUTES:
            base = prefix.rstrip("/")
            if path == base or path.startswith(base + "/"):
                if not features.enabled(db.get_settings(), key):
                    label = next(l for k, l, _ in features.FEATURES if k == key)
                    self._error(f"{label} is turned off in Settings > Features.", 403)
                    return True
        return False

    def do_GET(self):
        path = urlparse(self.path).path
        query = parse_qs(urlparse(self.path).query)
        if self._feature_blocked(path):
            return
        if path == "/api/features":
            result = features.public(db.get_settings())
            result["restart_needed"] = restart_needed()
            result["running_version"] = STARTED_VERSION
            return self._send_json(result)

        if path == "/" or path == "/index.html":
            return self._serve_template("index.html")
        if path == "/favicon.ico":
            return self._serve_static("favicon.ico")
        if path.startswith("/static/"):
            return self._serve_static(path[len("/static/"):])
        if path == "/api/health":
            # app/db let a second launch recognise this exact instance.
            return self._send_json({"status": "ok", "app": "TickAssist",
                                    "version": app_version(), "running_version": STARTED_VERSION,
                                    "db": DB_PATH})
        if path == "/api/settings":
            return self._send_json(self._public_settings())
        if path == "/api/incoming":
            return self._incoming_poll(query)
        if path == "/api/transfer/config":
            return self._send_json({
                "equipment": transfer.config(),
                "configured": bool(_transfer_url(db.get_settings()))})
        if path == "/call":
            return self._incoming_push(query)
        match = re.match(r"^/api/lists/([a-z_]+)/verify$", path)
        if match:
            return self._verify_list_value(match.group(1), (query.get("value") or [""])[0])
        match = re.match(r"^/api/lists/([a-z_]+)$", path)
        if match:
            key = match.group(1)
            try:
                return self._send_json({"items": db.list_items(key),
                                        "fixed": key in database.FIXED_LISTS,
                                        "verified": key in database.ENV_LIST_COLUMNS and key not in database.FIXED_LISTS
                                                    and key not in database.FREE_ENV_LISTS,
                                        "free": key in database.FREE_ENV_LISTS})
            except KeyError:
                return self._error("Unknown list.", 404)
        if path == "/api/update/check":
            return self._update_check()
        if path == "/api/macros":
            return self._send_json({"macros": db.list_macros()})
        if path == "/api/stats":
            return self._send_json(db.dashboard_stats())
        if path == "/api/tickets/export":
            return self._export_csv()
        if path == "/api/export/database":
            return self._export_database()
        if path == "/api/sheet/lookup":
            return self._sheet_lookup((query.get("key") or [""])[0],
                                      (query.get("prefer") or [""])[0],
                                      (query.get("field") or ["imaging_package"])[0])
        if path == "/api/tickets/lookup":
            phone = (query.get("phone") or [""])[0]
            return self._send_json({"matches": db.tickets_by_phone(phone)})
        if path == "/api/tickets/callcard":
            phone = (query.get("phone") or [""])[0]
            return self._send_json(db.caller_card(phone))
        if path == "/api/tickets":
            search = (query.get("q") or [None])[0]
            return self._send_json({"tickets": db.list_tickets(search)})

        if path == "/d365/login":
            return self._d365_login()
        if path == d365.CALLBACK_PATH:
            return self._d365_callback(query)
        if path.startswith("/api/d365/"):
            return self._d365_get(path[len("/api/d365/"):], query)
        if path == "/api/photos":
            return self._list_photos(query)
        match = re.match(r"^/api/photos/(\d+)$", path)
        if match:
            return self._send_photo(int(match.group(1)), query)

        match = re.match(r"^/api/tickets/(\d+)$", path)
        if match:
            ticket = db.get_ticket(int(match.group(1)))
            if not ticket:
                return self._error("Ticket not found.", 404)
            return self._send_json({"ticket": ticket})

        return self._error("Not found.", 404)

    def do_POST(self):
        path = urlparse(self.path).path
        if self._feature_blocked(path):
            return
        try:
            if path == "/api/features":
                return self._update_features()
            if path == "/api/settings":
                return self._update_settings()
            if path == "/api/update/apply":
                return self._update_apply()
            if path == "/api/update/restart":
                self._send_json({"restarting": True})
                return _restart_self()
            if path == "/api/transfer":
                return self._transfer_do()
            if path == "/api/callwatch/open-max":
                return self._callwatch_open_max()
            if path == "/api/callwatch/refresh":
                return self._callwatch_refresh()
            if path == "/api/callwatch/test":
                return self._callwatch_test()
            if path == "/api/lists/sync":
                return self._sync_lists_from_sheets()
            match = re.match(r"^/api/lists/([a-z_]+)$", path)
            if match:
                return self._add_list_item(match.group(1))
            if path == "/api/macros":
                return self._add_macro()
            if path == "/api/tickets":
                return self._save_ticket()
            if path == "/api/polish":
                return self._polish()
            if path == "/api/sheet/test":
                return self._sheet_test()
            if path == "/api/merge":
                return self._merge()
            if path == "/api/merge/upload":
                return self._merge_upload(parse_qs(urlparse(self.path).query))
            if path == "/api/photos":
                return self._add_photo(parse_qs(urlparse(self.path).query))
            if path == "/api/photos/claim":
                data = self._read_json()
                return self._send_json({"claimed": db.claim_draft_photos(int(data.get("ticket_id") or 0))})
            if path == "/api/photos/copy":
                data = self._read_json()
                return self._send_json({"copied": db.copy_photos(
                    int(data.get("from") or 0), int(data.get("to") or 0))})
            if path == "/api/photos/discard-drafts":
                return self._send_json({"deleted": db.discard_draft_photos()})
            if path.startswith("/api/d365/"):
                return self._d365_post(path[len("/api/d365/"):])
        except ValueError as err:
            return self._error(str(err), 400)
        return self._error("Not found.", 404)

    def do_PUT(self):
        path = urlparse(self.path).path
        match = re.match(r"^/api/tickets/(\d+)$", path)
        if match:
            try:
                data = self._read_json()
            except ValueError as err:
                return self._error(str(err), 400)
            ticket = db.update_ticket(int(match.group(1)), data)
            if not ticket:
                return self._error("Ticket not found.", 404)
            return self._send_json({"ticket": ticket})
        return self._error("Not found.", 404)

    def do_DELETE(self):
        path = urlparse(self.path).path
        if self._feature_blocked(path):
            return
        match = re.match(r"^/api/lists/([a-z_]+)/(\d+)$", path)
        if match:
            if match.group(1) in database.FIXED_LISTS:
                return self._error(FIXED_MSG, 403)
            try:
                ok = db.delete_item(match.group(1), int(match.group(2)))
            except KeyError:
                return self._error("Unknown list.", 404)
            if not ok:
                return self._error("Item not found.", 404)
            return self._send_json({"deleted": True})

        match = re.match(r"^/api/tickets/(\d+)$", path)
        if match:
            ok = db.delete_ticket(int(match.group(1)))
            if not ok:
                return self._error("Ticket not found.", 404)
            return self._send_json({"deleted": True})

        match = re.match(r"^/api/photos/(\d+)$", path)
        if match:
            if not db.delete_photo(int(match.group(1))):
                return self._error("Photo not found.", 404)
            return self._send_json({"deleted": True})

        match = re.match(r"^/api/macros/(\d+)$", path)
        if match:
            ok = db.delete_macro(int(match.group(1)))
            if not ok:
                return self._error("Macro not found.", 404)
            return self._send_json({"deleted": True})

        return self._error("Not found.", 404)

    # ---- handlers -------------------------------------------------------
    def _public_settings(self):
        settings = db.get_settings()
        # Local single-user tool bound to loopback: returning the key so the
        # field can be edited is acceptable and expected.
        return {
            "llm_provider": settings.get("llm_provider", "gemini"),
            "llm_model": settings.get("llm_model", ""),
            "llm_api_key": settings.get("llm_api_key", ""),
            "api_key_set": bool((settings.get("llm_api_key") or "").strip()),
            "call_watch_enabled": str(settings.get("call_watch_enabled", "1")) == "1",
            "call_watch_peek": str(settings.get("call_watch_peek", "0")) == "1",
            "max_url": (settings.get("max_url") or "").strip() or cdp.DEFAULT_MAX_URL,
            "max_browser": settings.get("max_browser", "auto"),
            "call_watch_match": settings.get("call_watch_match", ""),
            "call_watch_ignore": settings.get("call_watch_ignore", ""),
            "call_watch_rules": settings.get("call_watch_rules", ""),
            "transfer_url": _transfer_url(settings),
            "required_rules": settings.get("required_rules", ""),
            "software_devices": settings.get("software_devices", ""),
            "sheet_url": settings.get("sheet_url", ""),
            "sheet_sources": sheets.sources(settings),
            "edition": EDITION,
            "update_url": _update_url(settings),
            "version": app_version(),
            "sheet_key_column": settings.get("sheet_key_column", "Imaging Package"),
            "sheet_map": settings.get("sheet_map", ""),
            "sheet_overwrite": str(settings.get("sheet_overwrite", "0")) == "1",
            "sheet_check": str(settings.get("sheet_check", "1")) == "1",
            "call_watch": watcher.snapshot_status(),
            "d365_org_url": settings.get("d365_org_url", ""),
            "d365_tenant_id": settings.get("d365_tenant_id", ""),
            "d365_client_id": settings.get("d365_client_id", ""),
            "d365_case_type": settings.get("d365_case_type", ""),
            "d365_case_origin": settings.get("d365_case_origin", ""),
            "d365_case_extra": settings.get("d365_case_extra", ""),
            "d365_customer_mode": settings.get("d365_customer_mode", "account"),
            "d365_note_html": str(settings.get("d365_note_html", "1")) == "1",
            "d365": crm.status(),
            "features": features.state(settings),
        }

    def _sheet_settings(self, data=None):
        """The sheet settings in use: what the page sent (to test unsaved edits), else saved."""
        s = db.get_settings()
        data = data or {}
        pick = lambda k, d="": (data[k] if data.get(k) is not None else s.get(k, d))
        return (str(pick("sheet_url")).strip(),
                str(pick("sheet_key_column", "Imaging Package")).strip() or "Imaging Package",
                str(pick("sheet_map")))

    def _sheet_lookup(self, key, prefer="", field="imaging_package"):
        """Look the value up in every sheet that is keyed by `field`."""
        mine = [s for s in sheets.sources(db.get_settings())
                if s["key_field"] == field and s["url"]]
        if not mine:
            return self._send_json({"configured": False, "results": []})
        results, errors = [], []
        for src in mine:
            try:
                r = sheets.lookup(src["url"], src["key_column"], src["map"], key, prefer)
            except sheets.SheetError as err:
                errors.append("%s: %s" % (src["name"], err))
                results.append({"source": src["name"], "found": False, "values": {}, "error": str(err)})
                continue
            r.update({"source": src["name"], "overwrite": src["overwrite"]})
            results.append(r)
        if errors and len(errors) == len(mine):
            return self._error("; ".join(errors), 502)
        return self._send_json({"configured": True, "results": results})

    # ---- updates ---------------------------------------------------------
    def _update_check(self):
        try:
            info = updater.check(_update_url(db.get_settings()), app_version(), EDITION)
        except updater.UpdateError as err:
            return self._error(str(err), 502)
        info.pop("zip_url", None)
        info["restart_needed"] = restart_needed()
        return self._send_json(info)

    def _update_apply(self):
        if restart_needed():
            return self._error("An update is already installed - restart TickAssist to use it.", 409)
        try:
            info = updater.check(_update_url(db.get_settings()), app_version(), EDITION)
            if not info["newer"]:
                return self._error(f"Already up to date (version {info['current']}).", 409)
            result = updater.apply(info, ROOT_DIR, DATA_DIR, app_version(), EDITION)
        except updater.UpdateError as err:
            return self._error(str(err), 502)
        return self._send_json(result)

    def _sheet_test(self):
        url, key_col, map_text = self._sheet_settings(self._read_json())
        try:
            return self._send_json(sheets.test(url, key_col, map_text))
        except sheets.SheetError as err:
            return self._error(str(err), 400)

    def _update_features(self):
        """Switch features on or off for this PC - owner password required.

        The password comes from app/owner.json (set with the owner's tools);
        nothing here can set, change or reset it. reset=true returns this PC
        to the office defaults in that file.
        """
        data = self._read_json()
        if restart_needed():
            return self._error(
                f"TickAssist was updated to {app_version()} while it was running "
                f"(still running {STARTED_VERSION}). Close the TickAssist window, "
                "start it again with run.bat, then save the features.", 409)
        if not features.load_owner().get("password"):
            return self._error("This copy has no owner password, so its features "
                               "can't be changed. The owner sets one with owner-tools.", 403)
        if not features.verify_owner(data.get("password") or ""):
            time.sleep(1.5)  # slows guessing
            return self._error("Wrong owner password.", 403)
        settings = db.get_settings()
        if data.get("reset"):
            value = features.USE_DEFAULTS
        else:
            wanted = data.get("features")
            if not isinstance(wanted, dict):
                raise ValueError("No feature switches sent.")
            current = features.state(settings)
            current.update({k: bool(v) for k, v in wanted.items() if k in features.KEYS})
            value = features.encode_off(current)
        updated = db.update_settings({features.OFF_SETTING: value})
        apply_call_watch_settings(updated)
        result = features.public(updated)
        result["call_watch"] = watcher.snapshot_status()
        return self._send_json(result)

    def _update_settings(self):
        data = self._read_json()
        enabled = data.get("call_watch_enabled")
        peek = data.get("call_watch_peek")
        before = db.get_settings()
        html = data.get("d365_note_html")
        org = data.get("d365_org_url")
        if org is not None:
            org = org.strip().rstrip("/")
            if org and not re.match(r"^https://[A-Za-z0-9.-]+$", org) \
                    and not os.environ.get("TA_D365_AUTHORITY"):
                raise ValueError("The D365 URL should look like https://yourorg.crm.dynamics.com")
        overwrite = data.get("sheet_overwrite")
        sources_json = None
        legacy = {}
        if data.get("sheet_sources") is not None:
            srcs = sheets.clean_sources(data.get("sheet_sources"))
            sources_json = json.dumps(srcs, separators=(",", ":"))
            # The first Imaging Package sheet is mirrored into the old settings.
            first = next((s for s in srcs if s["key_field"] == "imaging_package"), None)
            legacy = {"sheet_url": first["url"] if first else "",
                      "sheet_key_column": first["key_column"] if first else "Imaging Package",
                      "sheet_map": first["map"] if first else "",
                      "sheet_overwrite": "1" if first and first["overwrite"] else "0"}
        sheet_check = data.get("sheet_check")
        t_url = data.get("transfer_url")
        if t_url is not None:
            t_url = t_url.strip()
            if t_url:
                t_url = transfer.check_url(t_url)
        req_rules = data.get("required_rules")
        if req_rules is not None:
            req_rules = _check_required_rules(req_rules)
        software = data.get("software_devices")
        if software is not None:
            software = ", ".join(p.strip() for p in re.split(r"[,\n;]", str(software))
                                 if p.strip())[:500]
        mode = data.get("d365_customer_mode")
        if mode is not None and mode not in ("account", "contact"):
            raise ValueError("Unknown customer mode.")
        updated = db.update_settings({
            "llm_provider": data.get("llm_provider"),
            "llm_model": data.get("llm_model"),
            "llm_api_key": data.get("llm_api_key"),
            "call_watch_enabled": None if enabled is None else ("1" if enabled else "0"),
            "call_watch_peek": None if peek is None else ("1" if peek else "0"),
            "max_url": data.get("max_url"),
            "max_browser": data.get("max_browser") if data.get("max_browser") in ("auto", "chrome", "edge") else None,
            "call_watch_match": data.get("call_watch_match"),
            "call_watch_ignore": data.get("call_watch_ignore"),
            "call_watch_rules": data.get("call_watch_rules"),
            "transfer_url": t_url,
            "required_rules": req_rules,
            "software_devices": software,
            "sheet_url": _strip(data.get("sheet_url")),
            "sheet_key_column": _strip(data.get("sheet_key_column")),
            "sheet_map": data.get("sheet_map"),
            "sheet_overwrite": None if overwrite is None else ("1" if overwrite else "0"),
            "sheet_sources": sources_json,
            "update_url": _check_update_url(data.get("update_url")),
            "sheet_check": None if sheet_check is None else ("1" if sheet_check else "0"),
            "d365_org_url": org,
            "d365_tenant_id": _strip(data.get("d365_tenant_id")),
            "d365_client_id": _strip(data.get("d365_client_id")),
            "d365_case_type": _strip(data.get("d365_case_type")),
            "d365_case_origin": _strip(data.get("d365_case_origin")),
            "d365_case_extra": _strip(data.get("d365_case_extra")),
            "d365_customer_mode": mode,
            "d365_note_html": None if html is None else ("1" if html else "0"),
        })
        # A sign-in belongs to one org, tenant and app; changing any ends it.
        if any(k in data and (before.get(k) or "") != (updated.get(k) or "")
               for k in ("d365_org_url", "d365_tenant_id", "d365_client_id")):
            crm.sign_out()
        apply_call_watch_settings(updated)
        return self._send_json({
            "llm_provider": updated.get("llm_provider"),
            "llm_model": updated.get("llm_model"),
            "api_key_set": bool((updated.get("llm_api_key") or "").strip()),
            "call_watch": watcher.snapshot_status(),
            "d365": crm.status(),
        })

    # ---- incoming calls --------------------------------------------------
    def _incoming_poll(self, query):
        """Long-poll: answer as soon as a call newer than ?since= arrives.

        Without ?since= it answers at once with the current sequence, which is
        how a freshly loaded page learns where "now" is without replaying a
        call that rang before it opened.
        """
        raw = (query.get("since") or [""])[0]
        since = int(raw) if raw.isdigit() else None
        seq, event = incoming.wait(since, INCOMING_HOLD_SECONDS)
        return self._send_json({"seq": seq, "event": event,
                                "watch": watcher.snapshot_status()})

    def _transfer_do(self):
        """Transfer panel: send the active call to the chosen queue."""
        data = self._read_json()
        who = "call=%s skill=%s case=%s equip=%s" % (
            data.get("contactId"), data.get("targetSkill"), data.get("caseNumber"), data.get("equipment"))
        try:
            result = transfer.execute(_transfer_url(db.get_settings()), data)
        except transfer.TransferError as err:
            _log_transfer("FAILED %s -> %s" % (who, err))
            return self._error(str(err), err.status)
        _log_transfer("SENT %s -> HTTP %s from %s; service said: %s" % (
            who, result.get("status"), result.get("url"), result.get("reply") or "(nothing)"))
        return self._send_json(result)

    def _callwatch_open_max(self):
        """Settings > Open MAX: start Chrome/Edge on MAX with background reading on."""
        data = self._read_json()
        settings = db.get_settings()
        url = (data.get("max_url") or settings.get("max_url") or "").strip()
        prefer = data.get("max_browser") or settings.get("max_browser") or "auto"
        result = cdp.launch_max(url, DATA_DIR, prefer if prefer in ("auto", "chrome", "edge") else "auto")
        return self._send_json(result, 200 if result.get("ok") else 500)

    def _callwatch_refresh(self):
        """Settings > Refresh: restart the window reader with a clean baseline."""
        self._read_json()
        restarted = watcher.restart()
        return self._send_json({"restarted": restarted,
                                "watch": watcher.snapshot_status()})

    def _callwatch_test(self):
        """Settings > Test: publish a made-up call through the normal path.

        The page recognises source "test" and only reports that it arrived -
        it never fills Phone Number or any other field with it.
        """
        self._read_json()
        ev = incoming.publish(TEST_CALL_DIGITS, "test")
        return self._send_json({"event": ev, "watch": watcher.snapshot_status()})

    def _incoming_push(self, query):
        """Screen-pop route: GET /call?phone=... records an incoming caller.

        For a CXone Studio POPURL / RUNAPP action, e.g.
            http://localhost:8765/call?phone={ANI}&skill={SKILLNAME}
        ?skill= is optional; when given, the caller-type rules classify it.
        ?case= (or ?caseNumber=) is optional too: a CAS0490097 case number.
        The reply is a tiny page, since MAX may show it in a panel.
        """
        # ?ani= is what the CXone call page itself uses; accept both.
        num = callwatch.normalize_phone((query.get("phone") or query.get("ani") or [""])[0])
        if not num:
            body = ("<!doctype html><meta charset=utf-8><title>TickAssist</title>"
                    "<p style='font:14px sans-serif'>TickAssist: no usable phone "
                    "number in <code>?phone=</code>.</p>")
            return self._send_bytes(body.encode("utf-8"), CONTENT_TYPES[".html"], 400)
        watcher.note_external(num)
        skill = (query.get("skill") or [""])[0]
        hit = watcher.classify_text(skill) if skill else None
        raw_case = (query.get("case") or query.get("caseNumber") or [""])[0]
        if not incoming.case_enabled:
            raw_case = ""
        case = callwatch._one_case([raw_case]) if raw_case else None
        contact_id = ((query.get("contactId") or [""])[0]).strip()[:64]
        if contact_id.startswith("{") or not re.match(r"^[\w-]+$", contact_id):
            contact_id = ""     # an unfilled {CONTACTID} template, or junk
        ev = incoming.publish(num, "screen-pop", hit[0] if hit else None,
                              hit[1] if hit else None, case_number=case,
                              contact_id=contact_id or None)
        body = ("<!doctype html><meta charset=utf-8><title>TickAssist</title>"
                "<p style='font:14px sans-serif'>Sent <b>%s</b> to TickAssist.</p>"
                % ev["phone"])
        return self._send_bytes(body.encode("utf-8"), CONTENT_TYPES[".html"])

    def _sheet_field_values(self, key):
        """{norm: value} the sheets hold for an environment list, or (None, message)."""
        field = database.ENV_LIST_COLUMNS[key]
        if not [s for s in sheets.sources(db.get_settings()) if s["url"]]:
            return None, ("This list only takes values found in your Google Sheets, and none is linked "
                          "yet. Add one in Settings > Integrations > Google Sheets.")
        try:
            return sheets.field_values(db.get_settings(), field), ""
        except sheets.SheetError as err:
            return None, "Couldn't read the sheets to check that value: %s" % err

    def _verify_list_value(self, key, value):
        if key not in database.ENV_LIST_COLUMNS or key in database.FIXED_LISTS or key in database.FREE_ENV_LISTS:
            return self._error("That list isn't checked against the sheets.", 404)
        found, problem = self._sheet_field_values(key)
        if found is None:
            return self._send_json({"verified": False, "checked": False, "message": problem})
        hit = found.get(sheets.norm(value))
        return self._send_json({"verified": bool(hit), "checked": True, "value": hit or ""})

    def _sync_lists_from_sheets(self):
        """Add every value the sheets hold to its System Environment list."""
        added, problems = {}, []
        for key in database.ENV_LIST_COLUMNS:
            if key in database.FIXED_LISTS or key in database.FREE_ENV_LISTS:
                continue
            found, problem = self._sheet_field_values(key)
            if found is None:
                problems.append(problem)
                continue
            have = {sheets.norm(i["name"]) for i in db.list_items(key)}
            for n, value in found.items():
                if n not in have:
                    try:
                        db.add_item(key, value)
                        added[key] = added.get(key, 0) + 1
                    except (database.ListItemExistsError, ValueError):
                        pass
        if problems and not added:
            return self._error(problems[0], 400)
        return self._send_json({"added": added, "total": sum(added.values())})

    def _add_list_item(self, key):
        data = self._read_json()
        if key in database.FIXED_LISTS:
            return self._error(FIXED_MSG, 403)
        if key in database.ENV_LIST_COLUMNS and key not in database.FREE_ENV_LISTS:
            found, problem = self._sheet_field_values(key)
            if found is None:
                return self._error(problem, 400)
            name = found.get(sheets.norm(data.get("name", "")))
            if not name:
                return self._error("'%s' isn't in any of your linked sheets, so it can't be added. "
                                   "Add it to the sheet first." % (data.get("name") or "").strip(), 400)
            data = dict(data, name=name)
        try:
            item = db.add_item(key, data.get("name", ""))
        except KeyError:
            return self._error("Unknown list.", 404)
        except database.ListItemExistsError as err:
            return self._error(str(err), 409)
        except ValueError as err:
            return self._error(str(err), 400)
        return self._send_json({"item": item}, status=201)

    def _add_macro(self):
        data = self._read_json()
        try:
            macro = db.add_macro(data.get("trigger", ""), data.get("expansion", ""))
        except database.MacroExistsError as err:
            return self._error(str(err), 409)
        except ValueError as err:
            return self._error(str(err), 400)
        return self._send_json({"macro": macro}, status=201)

    def _save_ticket(self):
        data = self._read_json()
        ticket = db.save_ticket(data)
        return self._send_json({"ticket": ticket}, status=201)

    def _export_database(self):
        """Lite: this session's tickets as a TickAssist database file for the full edition."""
        if EDITION != "lite":
            return self._error("Only TickAssist Lite exports its session this way.", 404)
        if not db.list_tickets():
            return self._error("There are no tickets in this session yet.", 409)
        fd, tmp = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        try:
            db.export_to(tmp)
            with open(tmp, "rb") as fh:
                body = fh.read()
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
        filename = f"TickAssist-Lite-{time.strftime('%Y-%m-%d')}.db"
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _export_csv(self):
        buf = io.StringIO()
        writer = csv.writer(buf, lineterminator="\r\n")
        writer.writerow(["id", "created_at"] + database.TICKET_FIELDS)
        for t in db.all_tickets():
            writer.writerow([t.get("id"), t.get("created_at")] +
                            [t.get(f, "") for f in database.TICKET_FIELDS])
        # utf-8-sig: the BOM makes Excel detect UTF-8 instead of mangling it.
        body = buf.getvalue().encode("utf-8-sig")
        filename = f"tickassist-tickets-{time.strftime('%Y%m%d')}.csv"
        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8")
        self.send_header("Content-Disposition",
                         f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _merge(self):
        """Preview or run a merge from an older database.

        Preview is the default; the caller has to ask for the write explicitly,
        so nothing lands in the live database without being seen first.
        """
        data = self._read_json()
        source = data.get("path", "")
        try:
            if data.get("apply"):
                result = db.merge_apply(source)
            else:
                result = db.merge_preview(source)
                result.pop("_rows", None)
        except database.MergeError as err:
            return self._error(str(err), 400)
        except OSError as err:
            return self._error("Could not read that database: %s" % err, 400)
        return self._send_json(result)

    # ---- Dynamics 365 -----------------------------------------------------
    def _redirect_uri(self):
        # Always "localhost": that is what the app registration lists, and
        # Entra ignores a localhost redirect's port, so 8766 works too.
        return "http://localhost:%d%s" % (self.server.server_address[1], d365.CALLBACK_PATH)

    def _send_html(self, title, message, ok=True):
        color = "#059669" if ok else "#dc2626"
        esc = lambda t: (t or "").replace("&", "&amp;").replace("<", "&lt;")
        page = (
            "<!doctype html><meta charset=utf-8><title>TickAssist - %s</title>"
            "<body style=\"font:15px system-ui,sans-serif;background:#0f172a;color:#e2e8f0;"
            "display:grid;place-items:center;height:100vh;margin:0\">"
            "<div style=\"max-width:520px;padding:28px;border:1px solid #334155;border-radius:12px\">"
            "<h2 style=\"margin:0 0 10px;color:%s\">%s</h2><p>%s</p>"
            "<p style=\"color:#94a3b8\">You can close this tab and go back to TickAssist.</p>"
            "</div><script>%s</script>"
            % (esc(title), color, esc(title), esc(message),
               "setTimeout(function(){window.close()},2500)" if ok else ""))
        self._send_bytes(page.encode("utf-8"), "text/html; charset=utf-8", 200 if ok else 400)

    def _d365_login(self):
        try:
            url = crm.begin_login(self._redirect_uri())
        except d365.D365Error as err:
            return self._send_html("Can't sign in yet", str(err), ok=False)
        self.send_response(302)
        self.send_header("Location", url)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _d365_callback(self, query):
        flat = {k: v[0] for k, v in query.items()}
        try:
            name = crm.finish_login(flat)
        except d365.D365Error as err:
            return self._send_html("D365 sign-in failed", str(err), ok=False)
        return self._send_html("Signed in to Dynamics 365",
                               "TickAssist is connected%s." % (" as " + name if name else ""))

    def _d365_error(self, err):
        payload = {"error": str(err)}
        if getattr(err, "signed_out", False):
            payload["signed_out"] = True
        return self._send_json(payload, status=getattr(err, "status", 400))

    def _d365_get(self, action, query):
        q = lambda k: (query.get(k) or [""])[0]
        try:
            if action == "status":
                return self._send_json(crm.status())
            if action == "customers":
                return self._send_json({"matches": crm.find_customers(q("phone"), q("name"))})
            if action == "case":
                return self._send_json({"case": crm.find_case(q("number"))})
        except d365.D365Error as err:
            return self._d365_error(err)
        return self._error("Not found.", 404)

    def _photos_for_d365(self, ids, number):
        out = []
        for i, pid in enumerate(ids):
            photo = db.get_photo(int(pid))
            if not photo:
                raise d365.D365Error("A photo was removed before it could be sent.")
            ext = {"image/jpeg": "jpg", "image/png": "png", "image/gif": "gif",
                   "image/webp": "webp", "image/bmp": "bmp"}.get(photo["mime"], "img")
            base = re.sub(r"[^\w-]+", "", number or "") or "photo"
            out.append({"id": photo["id"], "mime": photo["mime"], "data": bytes(photo["data"]),
                        "filename": "%s-%d.%s" % (base, i + 1, ext)})
        return out

    def _d365_post(self, action):
        try:
            data = self._read_json()
            if action == "signout":
                crm.sign_out()
                return self._send_json(crm.status())
            if action == "test":
                who = crm.whoami()
                return self._send_json({"user": who, "form": crm.case_form_info()})
            if action == "case":
                # Create the case, then (optionally) its note and photos. The
                # case number is returned even if the note fails, so the form
                # always learns about the case that now exists.
                case = crm.create_case(data.get("title"), data.get("description"),
                                       data.get("customer"), data.get("contact_id"))
                result = {"case": case}
                note = data.get("note") or {}
                ids = [int(i) for i in (data.get("photo_ids") or [])]
                if ((note.get("text") or "").strip() or ids) and case.get("id"):
                    try:
                        photos = self._photos_for_d365(ids, case.get("number"))
                        result["note"] = crm.add_note(case["id"], note.get("subject"),
                                                      note.get("text"), photos)
                        db.mark_photos_sent(ids)
                    except d365.D365Error as err:
                        result["note_error"] = str(err)
                return self._send_json(result, status=201)
            if action == "note":
                ids = [int(i) for i in (data.get("photo_ids") or [])]
                case = crm.find_case(data.get("number"))
                if data.get("incident_id") and data["incident_id"] != case["id"]:
                    raise d365.D365Error("The case changed - check the Case ID and try again.")
                photos = self._photos_for_d365(ids, case["number"])
                res = crm.add_note(case["id"], data.get("subject"), data.get("text"), photos)
                db.mark_photos_sent(ids)
                return self._send_json({"case": case, "note": res}, status=201)
        except d365.D365Error as err:
            return self._d365_error(err)
        return self._error("Not found.", 404)

    # ---- photos -----------------------------------------------------------
    @staticmethod
    def _photo_ticket(query):
        """?ticket=ID for a saved ticket; anything else is the draft set."""
        raw = (query.get("ticket") or [""])[0]
        return int(raw) if raw.isdigit() else None

    def _list_photos(self, query):
        return self._send_json({"photos": db.list_photos(self._photo_ticket(query))})

    def _add_photo(self, query):
        mime = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if mime not in PHOTO_TYPES:
            return self._error("Photos must be PNG, JPEG, GIF, WebP or BMP.", 400)
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return self._error("No photo was uploaded.", 400)
        if length > MAX_PHOTO_UPLOAD:
            return self._error("That photo is %.1f MB, over the %d MB limit."
                               % (length / 1048576.0, MAX_PHOTO_UPLOAD // 1048576), 400)
        data = self.rfile.read(length)

        def num(key):
            raw = (query.get(key) or [""])[0]
            return int(raw) if raw.isdigit() else None

        photo = db.add_photo(self._photo_ticket(query),
                             (query.get("name") or [""])[0], mime, data,
                             num("w"), num("h"))
        if not photo:
            return self._error("Ticket not found.", 404)
        return self._send_json({"photo": photo})

    def _send_photo(self, photo_id, query):
        photo = db.get_photo(photo_id)
        if not photo:
            return self._error("Photo not found.", 404)
        body = bytes(photo["data"])
        self.send_response(200)
        self.send_header("Content-Type", photo["mime"])
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "private, max-age=86400")  # photos never change
        if (query.get("download") or ["0"])[0] == "1":
            name = (query.get("name") or [""])[0] or photo["name"] or "photo-%d" % photo_id
            safe = re.sub(r'[^A-Za-z0-9._ -]+', "_", name).strip() or "photo"
            self.send_header("Content-Disposition", 'attachment; filename="%s"' % safe)
        self.end_headers()
        self.wfile.write(body)

    def _merge_upload(self, query):
        """Merge from a database the user picked in a file dialog.

        The bytes are written to a temp file and fed to the same merge engine
        the typed-path route uses, then deleted - nothing is kept around.
        """
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return self._error("No file was uploaded.", 400)
        if length > MAX_MERGE_UPLOAD:
            return self._error(
                "That file is %.0f MB, over the %.0f MB limit for a merge."
                % (length / 1048576.0, MAX_MERGE_UPLOAD / 1048576.0), 400)

        name = (query.get("name") or ["the selected file"])[0]
        fd, temp = tempfile.mkstemp(prefix="tickassist-merge-", suffix=".db")
        try:
            # Streamed to disk: a database with photos can run to gigabytes.
            with os.fdopen(fd, "wb") as fh:
                left = length
                while left > 0:
                    chunk = self.rfile.read(min(left, 1024 * 1024))
                    if not chunk:
                        break
                    fh.write(chunk)
                    left -= len(chunk)
            apply_it = (query.get("apply") or ["0"])[0] == "1"
            result = db.merge_apply(temp) if apply_it else db.merge_preview(temp)
            result.pop("_rows", None)
            # Report the name the user recognises, not the temp file.
            result["source"] = name
            return self._send_json(result)
        except database.MergeError as err:
            return self._error(str(err), 400)
        except OSError as err:
            return self._error("Could not read that database: %s" % err, 400)
        finally:
            try:
                os.remove(temp)
            except OSError:
                pass

    def _polish(self):
        data = self._read_json()
        try:
            result = llm.polish(data, db.get_settings())
        except llm.LLMError as err:
            return self._error(str(err), 502)
        return self._send_json({"result": result})

    # ---- static / template ---------------------------------------------
    def _serve_template(self, name):
        """Serve the page shell, substituting {{VERSION}}.

        Conditional requests still work, but the freshness check spans both the
        template and the VERSION file - bumping the version alone would
        otherwise leave the browser holding a 304 and showing the old badge.
        """
        path = os.path.join(TEMPLATE_DIR, name)
        if not os.path.isfile(path):
            return self._error("Template missing.", 500)
        try:
            mtime = max(os.path.getmtime(path), os.path.getmtime(VERSION_FILE))
        except OSError:
            mtime = os.path.getmtime(path)

        last_modified = formatdate(mtime, usegmt=True)
        if self._not_modified(mtime):
            self.send_response(304)
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Last-Modified", last_modified)
            self.end_headers()
            return

        with open(path, "r", encoding="utf-8") as fh:
            html = fh.read()
        body = html.replace("{{VERSION}}", app_version()).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", CONTENT_TYPES[".html"])
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Last-Modified", last_modified)
        self.end_headers()
        self.wfile.write(body)

    def _serve_static(self, rel_path):
        rel_path = rel_path.replace("\\", "/").lstrip("/")
        full = os.path.normpath(os.path.join(STATIC_DIR, rel_path))
        if not full.startswith(os.path.normpath(STATIC_DIR) + os.sep):
            return self._error("Forbidden.", 403)
        if not os.path.isfile(full):
            return self._error("Not found.", 404)
        ext = os.path.splitext(full)[1].lower()
        self._send_file(full, CONTENT_TYPES.get(ext, "application/octet-stream"))

    def _send_file(self, full, content_type):
        """Serve a file with conditional-request support.

        Fonts are content-stable, so they get a far-future immutable cache;
        everything else is no-cache + Last-Modified, which turns repeat loads
        into cheap 304s while still picking up edits immediately.
        """
        try:
            stat = os.stat(full)
        except OSError:
            return self._error("Not found.", 404)
        ext = os.path.splitext(full)[1].lower()
        cache = ("public, max-age=31536000, immutable"
                 if ext in (".woff2", ".woff") else "no-cache")
        last_modified = formatdate(stat.st_mtime, usegmt=True)

        if self._not_modified(stat.st_mtime):
            self.send_response(304)
            self.send_header("Cache-Control", cache)
            self.send_header("Last-Modified", last_modified)
            self.end_headers()
            return

        with open(full, "rb") as fh:
            body = fh.read()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.send_header("Last-Modified", last_modified)
        self.end_headers()
        self.wfile.write(body)

    def _not_modified(self, mtime):
        ims = self.headers.get("If-Modified-Since")
        if not ims:
            return False
        try:
            since = parsedate_to_datetime(ims).timestamp()
        except (TypeError, ValueError):
            return False
        return int(mtime) <= since

    # Keep the console focused on API traffic; static-file chatter is noise.
    def log_request(self, code="-", size="-"):
        path = urlparse(getattr(self, "path", "")).path
        # /api/incoming is a long-poll that re-asks every 25 s all shift.
        if str(code) in ("200", "304", "201") and (
                path.startswith("/static/") or path == "/favicon.ico"
                or path == "/api/incoming"):
            return
        super().log_request(code, size)

    # Quieter, single-line request logging.
    def log_message(self, fmt, *args):
        sys.stdout.write("  %s - %s\n" % (self.address_string(), fmt % args))


# Bypass any corporate proxy for loopback probes.
_LOCAL_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def _existing_instance(host, port):
    """True if a TickAssist server using OUR database answers on this port."""
    try:
        with _LOCAL_OPENER.open(f"http://{host}:{port}/api/health",
                                timeout=0.5) as resp:
            info = json.loads(resp.read().decode("utf-8"))
        return info.get("app") == "TickAssist" and info.get("db") == DB_PATH
    except Exception:
        return False


def _find_port(host, preferred):
    """Return (port, already_running).

    already_running is True when this exact tool is already serving on the
    port, so the caller can just focus it instead of starting a duplicate.
    """
    for port in range(preferred, preferred + 50):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            if os.name != "nt":   # a just-closed port (TIME_WAIT) is still usable
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind((host, port))
                return port, False
            except OSError:
                pass
        if _existing_instance(host, port):
            return port, True
    raise SystemExit("Could not find a free port to bind to.")


def main():
    # Ensure the banner/log lines appear promptly even when stdout is piped.
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except (AttributeError, ValueError):
        pass

    if "--reset-features-password" in sys.argv:
        # 4.8 had a reset file; the owner password no longer lives here.
        print("The features password can only be changed by the owner of this "
              "TickAssist build. You can delete reset-features-password.bat.")
        return

    if "--restarted" in sys.argv:
        # Started by "Restart" after an update: the old copy is still closing.
        deadline = time.time() + 15
        while time.time() < deadline:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
                if os.name != "nt":   # (on Windows this would bind over a live listener)
                    probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    probe.bind((HOST, PREFERRED_PORT))
                    break
                except OSError:
                    time.sleep(0.3)

    port, already_running = _find_port(HOST, PREFERRED_PORT)
    url = f"http://{HOST}:{port}/"

    if already_running:
        print(f"TickAssist is already running at {url} - opening it.")
        if "--no-browser" not in sys.argv:
            webbrowser.open(url)
        return

    # Office build: its shared settings, and a pending owner "push".
    owner = features.load_owner()
    db.office_defaults = features.office_settings(owner)
    if features.apply_push(db, owner):
        print("  Applied the owner's office settings and features to this PC.")

    httpd = ThreadingHTTPServer((HOST, port), Handler)
    # Long-polls park a thread each; they must not keep the process alive.
    httpd.daemon_threads = True
    apply_call_watch_settings(db.get_settings())

    print("=" * 56)
    print("  TickAssist - portable ticket handling")
    print("=" * 56)
    print(f"  Database : {DB_PATH}")
    print(f"  Serving  : {url}")
    print("  Press Ctrl+C to stop.")
    print("=" * 56)

    # Open the browser shortly after the server starts accepting connections.
    if "--no-browser" not in sys.argv:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        watcher.stop()
        httpd.server_close()


if __name__ == "__main__":
    main()
