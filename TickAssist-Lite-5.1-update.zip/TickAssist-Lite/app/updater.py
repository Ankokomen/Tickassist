"""One-click updates for TickAssist.

The owner publishes two things at a web address (a folder on their own site,
or a GitHub release):

  latest.json   {"version": "4.40", "url": "TickAssist-Lite-4.40-update.zip",
                 "sha256": "<hex, optional>", "notes": "what changed"}
  the update zip that `url` names (relative to latest.json, or absolute)

Each PC checks that address, downloads the zip, checks it, and copies the new
program files over the installed ones. The data folder, the office settings
(app/owner.json), the edition marker and the bundled Python runtime are never
touched, so settings, lists and macros survive. The previous version is kept
in <data>/updates/backup and put back automatically if anything fails halfway.

A GitHub address also works: https://github.com/<owner>/<repo> (or its
/releases page, or the api.github.com .../releases/latest address). The newest
release's .zip asset is used; the tag is the version.

Standard library only.
"""

import hashlib
import io
import json
import os
import re
import shutil
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile

TIMEOUT = 20
MAX_ZIP = 200 * 1024 * 1024
# Never overwritten or deleted by an update (paths relative to the program folder).
PROTECTED = ("data/", "runtime/", "app/owner.json", "app/edition.txt", "installed.txt", "app/owner-patch.json")
_HEADERS = {"User-Agent": "TickAssist-updater", "Accept": "application/json, application/zip, */*"}


class UpdateError(Exception):
    """A problem the user can act on."""


def parse_version(text):
    return tuple(int(n) for n in re.findall(r"\d+", str(text or ""))[:4]) or (0,)


def is_newer(latest, current):
    a, b = parse_version(latest), parse_version(current)
    width = max(len(a), len(b))
    return a + (0,) * (width - len(a)) > b + (0,) * (width - len(b))


def _allowed(url):
    parts = urllib.parse.urlparse(url)
    if parts.scheme == "https":
        return True
    # Plain http only for this PC itself (testing an update before publishing it).
    return parts.scheme == "http" and parts.hostname in ("localhost", "127.0.0.1")


def _open(url):
    if not _allowed(url):
        raise UpdateError("The update address must start with https://")
    req = urllib.request.Request(url, headers=_HEADERS)
    try:
        return urllib.request.urlopen(req, timeout=TIMEOUT)
    except urllib.error.HTTPError as err:
        raise UpdateError(f"The update address answered {err.code}. Check it in Settings > Updates.")
    except (urllib.error.URLError, OSError) as err:
        raise UpdateError(f"Couldn't reach the update address ({getattr(err, 'reason', err)}).")


def _candidates(url):
    """The addresses to try for what was pasted, best first.

    A plain github.com repository address (or its /releases page) is tried as
    the newest release first, then as a latest.json file in the repository
    itself - GitHub's raw file addresses are case-sensitive, so latest.json and
    Latest.json are both tried. A github.com/.../blob/... page link becomes the
    raw file address. Anything else is used as written."""
    parts = urllib.parse.urlparse(url)
    host = parts.hostname or ""
    bits = [b for b in parts.path.split("/") if b]
    if host == "api.github.com":
        return [url]
    if host in ("github.com", "www.github.com") and len(bits) >= 2:
        owner, repo = bits[0], bits[1]
        if repo.endswith(".git"):
            repo = repo[:-4]
        if len(bits) >= 5 and bits[2] in ("blob", "raw"):
            return [f"https://raw.githubusercontent.com/{owner}/{repo}/{bits[3]}/{'/'.join(bits[4:])}"]
        branch = bits[3] if len(bits) >= 4 and bits[2] == "tree" else "HEAD"
        raw = f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/"
        return [f"https://api.github.com/repos/{owner}/{repo}/releases/latest",
                raw + "latest.json", raw + "Latest.json"]
    return [url]


def _fetch_manifest(address):
    with _open(address) as resp:
        raw = resp.read(2 * 1024 * 1024)
    try:
        info = json.loads(raw.decode("utf-8-sig"))
    except ValueError:
        raise UpdateError("That address didn't return a latest.json file.")
    if not isinstance(info, dict):
        raise UpdateError("The update file isn't in the expected format.")
    return info


def check(url, current, edition="full"):
    """What is published at `url`: {"latest", "current", "newer", "zip_url", "sha256", "notes"}."""
    url = (url or "").strip()
    if not url:
        raise UpdateError("No update address is set. Paste it in Settings > Updates.")
    info, base, first_err = None, url, None
    tried = _candidates(url)
    for address in tried:
        try:
            info, base = _fetch_manifest(address), address
            break
        except UpdateError as err:
            first_err = first_err or err
    if info is None:
        if len(tried) > 1:
            raise UpdateError("Found no release and no latest.json in that GitHub repository. "
                              "Upload latest.json (and the -update.zip next to it) to the repository's "
                              "main page - or attach the zip to a release - and make sure the repository is "
                              "public.")
        raise first_err
    if "tag_name" in info:                       # a GitHub release
        assets = [a for a in info.get("assets") or [] if str(a.get("name", "")).lower().endswith(".zip")]
        want_lite = edition == "lite"
        assets.sort(key=lambda a: ("lite" in a["name"].lower()) != want_lite)
        if not assets:
            raise UpdateError("The latest GitHub release has no .zip file attached.")
        version, zip_url = info["tag_name"], assets[0].get("browser_download_url")
        sha, notes = "", str(info.get("body") or "")
    else:
        version, sha, notes = info.get("version"), str(info.get("sha256") or "").lower(), str(info.get("notes") or "")
        zip_url = info.get("url")
        if zip_url:
            zip_url = urllib.parse.urljoin(base, zip_url)
    if not version or not zip_url:
        raise UpdateError("The update file needs a version and a url.")
    version = str(version).lstrip("vV")
    return {"latest": version, "current": current, "newer": is_newer(version, current),
            "zip_url": zip_url, "sha256": sha, "notes": notes[:2000]}


def _download(zip_url, sha256):
    buf = io.BytesIO()
    with _open(zip_url) as resp:
        while True:
            chunk = resp.read(256 * 1024)
            if not chunk:
                break
            buf.write(chunk)
            if buf.tell() > MAX_ZIP:
                raise UpdateError("The update file is larger than expected - not installing it.")
    data = buf.getvalue()
    if sha256 and hashlib.sha256(data).hexdigest() != sha256:
        raise UpdateError("The downloaded update doesn't match its checksum - not installing it.")
    return data


def _payload(zf):
    """{relative path: ZipInfo} for the program files inside the zip, with any
    wrapping folder (TickAssist-4.40/...) removed."""
    names = [i for i in zf.infolist() if not i.is_dir()]
    roots = [i.filename for i in names if i.filename.split("/")[-1] == "VERSION"]
    if not roots:
        raise UpdateError("That zip isn't a TickAssist update (no VERSION file).")
    root = min(roots, key=lambda n: n.count("/"))
    prefix = root[: -len("VERSION")]
    out = {}
    for info in names:
        if not info.filename.startswith(prefix):
            continue
        rel = info.filename[len(prefix):]
        if (not rel or rel.startswith("/") or ".." in rel.split("/") or ":" in rel
                or "\\" in rel):
            raise UpdateError("The update contains an unsafe file path - not installing it.")
        out[rel] = info
    if "app/server.py" not in out:
        raise UpdateError("That zip isn't a TickAssist update (no app/server.py).")
    return out


def apply_owner_patch(root, raw):
    """Merge an update's app/owner-patch.json into this PC's app/owner.json.

    owner.json (password, office switches and settings) is never replaced by an
    update, but an update may carry a patch such as
      {"id": "lite-calls-on", "defaults": {"calls": true}, "settings": {...}}
    Each patch id is applied once; applying one bumps the office "rev" so the
    new defaults reach PCs that had overridden them. No owner.json = no office
    build = nothing to patch."""
    path = os.path.join(root, "app", "owner.json")
    try:
        patch = json.loads(raw.decode("utf-8-sig"))
        with open(path, encoding="utf-8") as fh:
            owner = json.load(fh)
    except (ValueError, OSError):
        return False
    pid = str(patch.get("id") or "")
    done = owner.get("patches") if isinstance(owner.get("patches"), list) else []
    if not pid or pid in done:
        return False
    for section in ("defaults", "settings"):
        if isinstance(patch.get(section), dict):
            owner.setdefault(section, {}).update(patch[section])
    owner["patches"] = done + [pid]
    try:
        owner["rev"] = int(owner.get("rev") or 0) + 1
    except (TypeError, ValueError):
        owner["rev"] = 1
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(owner, fh, indent=2)
    os.replace(tmp, path)
    return True


def _protected(rel):
    return any(rel == p or (p.endswith("/") and rel.startswith(p)) for p in PROTECTED)


def _backup(root, data_dir):
    dest = os.path.join(data_dir, "updates", "backup")
    shutil.rmtree(dest, ignore_errors=True)
    os.makedirs(dest, exist_ok=True)
    for name in ("app", "VERSION", "run.bat", "README.md"):
        src = os.path.join(root, name)
        if os.path.isdir(src):
            shutil.copytree(src, os.path.join(dest, name),
                            ignore=shutil.ignore_patterns("__pycache__", "owner.json"))
        elif os.path.isfile(src):
            shutil.copy2(src, os.path.join(dest, name))
    return dest


def _restore(root, backup):
    for dirpath, _dirs, files in os.walk(backup):
        for fn in files:
            src = os.path.join(dirpath, fn)
            rel = os.path.relpath(src, backup).replace(os.sep, "/")
            if _protected(rel):
                continue
            dst = os.path.join(root, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)


def apply(info, root, data_dir, current, edition="full"):
    """Download and install the update described by check(). Returns
    {"old", "new", "files"}. The running program must be restarted afterwards."""
    data = _download(info["zip_url"], info.get("sha256") or "")
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise UpdateError("The downloaded update isn't a valid zip file.")
    with zf:
        payload = _payload(zf)
        marker = payload.get("app/edition.txt")
        theirs = zf.read(marker).decode("utf-8", "replace").strip().lower() if marker else "full"
        if theirs != ("lite" if edition == "lite" else "full"):
            raise UpdateError(f"That update is for the {theirs.title()} edition, "
                              f"but this is TickAssist {edition.title()}.")
        new_version = (zf.read(payload["VERSION"]).decode("utf-8-sig").strip().lstrip("vV")
                       if "VERSION" in payload else info.get("latest", ""))
        if new_version and not is_newer(new_version, current):
            raise UpdateError(f"Already on {current}; the download is {new_version}.")
        backup = _backup(root, data_dir)
        wanted = {r: i for r, i in payload.items() if not _protected(r)}
        written = []
        try:
            # VERSION goes last: the running program notices it changed.
            for rel in sorted(wanted, key=lambda r: (r == "VERSION", r)):
                dst = os.path.join(root, *rel.split("/"))
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                fd, tmp = tempfile.mkstemp(dir=os.path.dirname(dst), prefix=".upd-")
                with os.fdopen(fd, "wb") as fh:
                    fh.write(zf.read(wanted[rel]))
                os.replace(tmp, dst)
                written.append(rel)
            # Remove program files the new version no longer has.
            old_app = os.path.join(root, "app")
            for dirpath, dirs, files in os.walk(old_app):
                dirs[:] = [d for d in dirs if d != "__pycache__"]
                for fn in files:
                    rel = os.path.relpath(os.path.join(dirpath, fn), root).replace(os.sep, "/")
                    if rel not in payload and not _protected(rel) and not fn.startswith(".upd-"):
                        os.remove(os.path.join(dirpath, fn))
            if "app/owner-patch.json" in payload:
                apply_owner_patch(root, zf.read(payload["app/owner-patch.json"]))
        except Exception as err:            # put the old version back
            _restore(root, backup)
            if isinstance(err, PermissionError):
                raise UpdateError("TickAssist can't write to its own folder, so it can't update itself. "
                                  "Run the installer again instead (the installer keeps your settings).")
            raise UpdateError(f"The update failed and was undone: {err}")
    return {"old": current, "new": new_version, "files": len(written)}
