"""TickAssist Lite storage: no database file.

Settings, the managed dropdown lists and the shorthand macros are plain JSON
files in the data folder - readable, easy to back up, easy to copy to another
PC. Tickets and photos are not kept on disk at all: they live in a private
in-memory store that exists only while the program runs, so the history list,
call card and "attach photos" keep working for the session and everything is
gone when TickAssist closes.

LiteStore subclasses Database, so the server needs no changes: it only swaps
the object it creates (see server.py, EDITION).
"""

import json
import os
import sqlite3
import threading

import database
from database import (DEFAULT_SETTINGS, FIXED_LISTS, MANAGED_LISTS, ListItemExistsError,
                      MacroExistsError)


class LiteStore(database.Database):
    def __init__(self, data_dir):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        # Used by the "is TickAssist already running?" check.
        self.path = os.path.join(data_dir, "settings.json")
        self.office_defaults = {}
        self._lock = threading.RLock()
        self._uri = "file:tickassist_lite_%d?mode=memory&cache=shared" % os.getpid()
        # Shared-cache memory databases vanish when their last connection
        # closes; this one is kept open for the life of the process.
        self._anchor = sqlite3.connect(self._uri, uri=True, check_same_thread=False)
        self._init()          # builds the in-memory ticket/photo tables
        self._ensure_lists()

    # ---- the in-memory ticket and photo store ----------------------------
    def _connect(self):
        conn = sqlite3.connect(self._uri, uri=True, timeout=10, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA read_uncommitted = 1")
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    # ---- JSON files --------------------------------------------------------
    def _file(self, name):
        return os.path.join(self.data_dir, name)

    def _read(self, name, default):
        try:
            with open(self._file(name), "r", encoding="utf-8") as fh:
                data = json.load(fh)
            return data if isinstance(data, type(default)) else default
        except (OSError, ValueError):
            return default

    def _write(self, name, data):
        """Write atomically so a crash or a full disk never leaves half a file."""
        path = self._file(name)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False)
        os.replace(tmp, path)

    # ---- settings ----------------------------------------------------------
    def get_settings(self):
        with self._lock:
            saved = self._read("settings.json", {})
        settings = dict(DEFAULT_SETTINGS)
        settings.update(self.office_defaults)
        for key, value in saved.items():
            value = str(value)
            if key in self.office_defaults and value == DEFAULT_SETTINGS.get(key):
                continue
            settings[key] = value
        return settings

    def delete_settings(self, keys):
        with self._lock:
            saved = self._read("settings.json", {})
            for key in keys:
                saved.pop(key, None)
            self._write("settings.json", saved)

    def update_settings(self, values):
        allowed = set(DEFAULT_SETTINGS.keys())
        with self._lock:
            saved = self._read("settings.json", {})
            for key, value in values.items():
                if key not in allowed or value is None:
                    continue
                saved[key] = str(value)
            self._write("settings.json", saved)
        return self.get_settings()

    # ---- managed lists -------------------------------------------------------
    def _ensure_lists(self):
        with self._lock:
            lists = self._read("lists.json", {})
            changed = False
            for key, defaults in MANAGED_LISTS.items():
                if key not in lists:
                    lists[key] = [{"id": i + 1, "name": n} for i, n in enumerate(defaults)]
                    changed = True
            # Fixed lists always match the program exactly.
            for key, fixed in FIXED_LISTS.items():
                names = [i["name"] for i in lists.get(key, [])]
                if sorted(n.lower() for n in names) != sorted(f.lower() for f in fixed):
                    lists[key] = [{"id": i + 1, "name": n} for i, n in enumerate(fixed)]
                    changed = True
            if changed or not os.path.exists(self._file("lists.json")):
                self._write("lists.json", lists)
            saved = self._read("settings.json", {})
            if saved.get("software_devices") == "Workstation, Server":
                saved["software_devices"] = DEFAULT_SETTINGS["software_devices"]
                self._write("settings.json", saved)

    def list_items(self, key):
        self._list_table(key)
        with self._lock:
            items = self._read("lists.json", {}).get(key, [])
        return sorted(({"id": i["id"], "name": i["name"]} for i in items),
                      key=lambda i: i["name"].lower())

    def add_item(self, key, name):
        self._list_table(key)
        name = (name or "").strip()
        if not name:
            raise ValueError("Name cannot be empty.")
        with self._lock:
            lists = self._read("lists.json", {})
            items = lists.setdefault(key, [])
            if any(i["name"].lower() == name.lower() for i in items):
                raise ListItemExistsError(f"'{name}' already exists.")
            new_id = max([i["id"] for i in items] + [0]) + 1
            items.append({"id": new_id, "name": name})
            self._write("lists.json", lists)
        return {"id": new_id, "name": name}

    def delete_item(self, key, item_id):
        self._list_table(key)
        with self._lock:
            lists = self._read("lists.json", {})
            items = lists.get(key, [])
            kept = [i for i in items if i["id"] != item_id]
            if len(kept) == len(items):
                return False
            lists[key] = kept
            self._write("lists.json", lists)
        return True

    # ---- macros ----------------------------------------------------------------
    def list_macros(self):
        with self._lock:
            macros = self._read("macros.json", [])
        return sorted(({"id": m["id"], "trigger": m["trigger"], "expansion": m["expansion"]}
                       for m in macros), key=lambda m: m["trigger"].lower())

    def add_macro(self, trigger, expansion):
        trigger = self.normalize_trigger(trigger)
        expansion = expansion if expansion is not None else ""
        if not trigger:
            raise ValueError("Trigger cannot be empty.")
        if not trigger.isalnum():
            raise ValueError("Trigger may only contain letters and numbers.")
        if not expansion.strip():
            raise ValueError("Expansion cannot be empty.")
        with self._lock:
            macros = self._read("macros.json", [])
            if any(m["trigger"].lower() == trigger.lower() for m in macros):
                raise MacroExistsError(f"Macro '\\{trigger}' already exists.")
            new_id = max([m["id"] for m in macros] + [0]) + 1
            macros.append({"id": new_id, "trigger": trigger, "expansion": expansion})
            self._write("macros.json", macros)
        return {"id": new_id, "trigger": trigger, "expansion": expansion}

    def delete_macro(self, macro_id):
        with self._lock:
            macros = self._read("macros.json", [])
            kept = [m for m in macros if m["id"] != macro_id]
            if len(kept) == len(macros):
                return False
            self._write("macros.json", kept)
        return True

    # ---- export the session for the full edition ---------------------------------
    def export_to(self, path):
        """Write this session's tickets and photos - plus the JSON lists and
        macros - into a real TickAssist SQLite file at `path`. The full edition
        reads it with Settings > Merge Databases, which skips anything it has."""
        src = self._connect()
        dest = sqlite3.connect(path)
        try:
            src.backup(dest)
            dest.execute("DELETE FROM settings")
            for table in MANAGED_LISTS:
                dest.execute(f"DELETE FROM {table}")
                if table in FIXED_LISTS:
                    continue
                dest.executemany(f"INSERT OR IGNORE INTO {table} (name) VALUES (?)",
                                 [(i["name"],) for i in self.list_items(table)])
            dest.execute("DELETE FROM macros")
            dest.executemany("INSERT OR IGNORE INTO macros (trigger, expansion) VALUES (?, ?)",
                             [(m["trigger"], m["expansion"]) for m in self.list_macros()])
            dest.commit()
            dest.execute("VACUUM")
        finally:
            src.close()
            dest.close()

    # ---- not available without a database ------------------------------------
    def merge_preview(self, *args, **kwargs):
        raise database.MergeError("TickAssist Lite does not keep a ticket database, so there is nothing to merge into.")

    merge_apply = merge_preview
